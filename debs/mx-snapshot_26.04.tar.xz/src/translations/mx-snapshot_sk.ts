<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="sk">
<context>
    <name>Batchprocessing</name>
    <message>
        <location filename="../src/batchprocessing.cpp" line="54"/>
        <source>Error</source>
        <translation>Chyba</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="55"/>
        <source>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="80"/>
        <source>The program will pause the build and open the boot menu in your text editor.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="162"/>
        <source>No diff output available.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="200"/>
        <source>Default exclusion file not found at %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="212"/>
        <source>Could not backup existing exclusion file to %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="215"/>
        <source>Could not remove existing exclusion file at %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="222"/>
        <source>Could not copy default exclusion file from %1 to %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="238"/>
        <source>Detected newer exclusion file at %1 compared to %2. Prompting for action.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="244"/>
        <source>s</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'show diff'</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="245"/>
        <source>u</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'use updated default'</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="246"/>
        <source>k</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'keep custom (update timestamp)'</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="247"/>
        <source>q</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'quit'</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="249"/>
        <source>show diff</source>
        <comment>CLI excludes prompt option label</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="250"/>
        <source>use updated default</source>
        <comment>CLI excludes prompt option label</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="251"/>
        <source>keep custom (update timestamp)</source>
        <comment>CLI excludes prompt option label</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="252"/>
        <source>quit</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>Koniec</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="255"/>
        <source>[%1]%2  [%3]%4  [%5]%6  [%7]%8: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="260"/>
        <source>The exclusion file at %1 is newer than your configured file at %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="276"/>
        <source>Reverted to updated default exclusion file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="297"/>
        <source>Leaving custom exclusion file unchanged.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="308"/>
        <source>Invalid choice. Please select again.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="315"/>
        <source>This computer uses an NVIDIA graphics card. Are you planning to use the resulting ISO on the same computer or another computer with an NVIDIA card?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="325"/>
        <source>Note: If you use the resulting ISO on a computer without an NVIDIA card, you will likely need to remove &apos;xorg=nvidia&apos; from the boot options.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="328"/>
        <source>Note: If you use the resulting ISO on a computer with an NVIDIA card, you may need to add &apos;xorg=nvidia&apos; to the boot options.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="101"/>
        <source>No elevation tool found (pkexec/gksu/sudo).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="171"/>
        <source>Administrator Access Required</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="172"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <location filename="../src/mainwindow.cpp" line="447"/>
        <location filename="../src/mainwindow.cpp" line="834"/>
        <location filename="../src/ui_mainwindow.h" line="745"/>
        <source>MX Snapshot</source>
        <translation>MX Snapshot</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="33"/>
        <location filename="../src/ui_mainwindow.h" line="746"/>
        <source>Optional customization</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="65"/>
        <location filename="../src/ui_mainwindow.h" line="747"/>
        <source>Release version:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="79"/>
        <location filename="../src/ui_mainwindow.h" line="748"/>
        <source>Boot options:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="86"/>
        <location filename="../src/ui_mainwindow.h" line="749"/>
        <source>Live kernel:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="93"/>
        <location filename="../src/ui_mainwindow.h" line="750"/>
        <source>Project name:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="100"/>
        <location filename="../src/ui_mainwindow.h" line="751"/>
        <source>Release date:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="107"/>
        <location filename="../src/ui_mainwindow.h" line="752"/>
        <source>Release codename:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="133"/>
        <location filename="../src/ui_mainwindow.h" line="753"/>
        <source>Current date</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="172"/>
        <location filename="../src/ui_mainwindow.h" line="754"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Snapshot is a utility that creates a bootable image (ISO) of your working system that you can use for storage or distribution. You can continue working with undemanding applications while it is running.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Snapshot je aplikácia na tvorbu spustiteľných (ISO) obrazov vášho funkčného systému, ktoré môžete použiť pre zálohovanie alebo distribúciu. Počas tvorby zálohy môžete paralelne používať nemej náročné aplikácie.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="182"/>
        <location filename="../src/ui_mainwindow.h" line="755"/>
        <source>Used space on / (root) and /home partitions:</source>
        <translation>Použitý priestor na diskoch / (root) a /home:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="192"/>
        <location filename="../src/ui_mainwindow.h" line="756"/>
        <source>Location and ISO name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="219"/>
        <location filename="../src/ui_mainwindow.h" line="758"/>
        <source>Snapshot location:</source>
        <translation>Zložka obrazu:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="226"/>
        <location filename="../src/ui_mainwindow.h" line="759"/>
        <source>Select a different snapshot directory</source>
        <translation>Zvoľte inú zložku pre obraz</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="236"/>
        <location filename="../src/mainwindow.cpp" line="642"/>
        <location filename="../src/ui_mainwindow.h" line="760"/>
        <source>Snapshot name:</source>
        <translation>Názov obrazu:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="360"/>
        <location filename="../src/ui_mainwindow.h" line="764"/>
        <source>Type of snapshot:</source>
        <translation>Typ obrazu:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="367"/>
        <location filename="../src/ui_mainwindow.h" line="765"/>
        <source>Preserving accounts (for personal backup)</source>
        <translation>Zachovať kontá (pre vlastné zazálohovanie)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <location filename="../src/ui_mainwindow.h" line="767"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This option will reset &amp;quot;demo&amp;quot; and &amp;quot;root&amp;quot; passwords to the MX Linux defaults and will not copy any personal accounts created.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Táto voľba zresetuje heslá pre &amp;quot;demo&amp;quot; a &amp;quot;root&amp;quot; na MX Linux predvolené a neprenesie žiadne uživateľom vytvorené kontá.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="380"/>
        <location filename="../src/ui_mainwindow.h" line="769"/>
        <source>Resetting accounts (for distribution to others)</source>
        <translation>Resetovať kontá (distribúcia iným)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="451"/>
        <location filename="../src/ui_mainwindow.h" line="770"/>
        <source>You can also exclude certain directories by ticking the common choices below, or by clicking on the button to directly edit /etc/mx-snapshot-exclude.list.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="496"/>
        <location filename="../src/ui_mainwindow.h" line="771"/>
        <source>sha512</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="519"/>
        <location filename="../src/ui_mainwindow.h" line="773"/>
        <source>Throttle the I/O input rate by the given percentage.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="525"/>
        <location filename="../src/ui_mainwindow.h" line="775"/>
        <source>I/O throttle:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="532"/>
        <location filename="../src/ui_mainwindow.h" line="776"/>
        <source>Calculate checksums:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="539"/>
        <location filename="../src/ui_mainwindow.h" line="777"/>
        <source>ISO compression scheme:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="546"/>
        <location filename="../src/ui_mainwindow.h" line="778"/>
        <source>Number of CPU cores to use:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="553"/>
        <location filename="../src/ui_mainwindow.h" line="779"/>
        <source>md5</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="563"/>
        <location filename="../src/ui_mainwindow.h" line="780"/>
        <source>Options:</source>
        <translation>Nastavenia:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="610"/>
        <location filename="../src/ui_mainwindow.h" line="781"/>
        <source>Edit Exclusion File</source>
        <translation>Upraviť zoznam vynechaných</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="626"/>
        <location filename="../src/mainwindow.cpp" line="854"/>
        <location filename="../src/ui_mainwindow.h" line="782"/>
        <source>Remove Custom Exclusion File</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="679"/>
        <location filename="../src/ui_mainwindow.h" line="783"/>
        <source>Pictures</source>
        <translation>Obrázky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="686"/>
        <location filename="../src/ui_mainwindow.h" line="784"/>
        <source>Videos</source>
        <translation>Videá</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="693"/>
        <location filename="../src/ui_mainwindow.h" line="785"/>
        <source>All of the above</source>
        <translation>Všetko uvedené vyššie</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="700"/>
        <location filename="../src/ui_mainwindow.h" line="787"/>
        <source>exclude network configurations</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="703"/>
        <location filename="../src/ui_mainwindow.h" line="789"/>
        <source>Networks</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="710"/>
        <location filename="../src/ui_mainwindow.h" line="790"/>
        <source>Downloads</source>
        <translation>Stiahnuté</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="717"/>
        <location filename="../src/ui_mainwindow.h" line="791"/>
        <source>Desktop</source>
        <translation>Pracovná plocha</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="724"/>
        <location filename="../src/ui_mainwindow.h" line="792"/>
        <source>Documents</source>
        <translation>Dokumenty</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="731"/>
        <location filename="../src/ui_mainwindow.h" line="793"/>
        <source>Flatpaks</source>
        <translation>Flatpaky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="738"/>
        <location filename="../src/ui_mainwindow.h" line="794"/>
        <source>Music</source>
        <translation>Hudba</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="850"/>
        <location filename="../src/ui_mainwindow.h" line="797"/>
        <source>About this application</source>
        <translation>O tejto aplikácii</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="853"/>
        <location filename="../src/ui_mainwindow.h" line="799"/>
        <source>About...</source>
        <translation>O Programe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="859"/>
        <location filename="../src/ui_mainwindow.h" line="801"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="875"/>
        <location filename="../src/ui_mainwindow.h" line="803"/>
        <source>Next</source>
        <translation>Nasledujúce</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="900"/>
        <location filename="../src/ui_mainwindow.h" line="808"/>
        <source>Display help </source>
        <translation>Zobraziť nápovedu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="903"/>
        <location filename="../src/ui_mainwindow.h" line="810"/>
        <source>Help</source>
        <translation>Pomocník</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="909"/>
        <location filename="../src/ui_mainwindow.h" line="812"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="922"/>
        <location filename="../src/ui_mainwindow.h" line="815"/>
        <source>Quit application</source>
        <translation>Zatvoriť aplikáciu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="925"/>
        <location filename="../src/ui_mainwindow.h" line="817"/>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="931"/>
        <location filename="../src/ui_mainwindow.h" line="819"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="985"/>
        <location filename="../src/ui_mainwindow.h" line="822"/>
        <source>Back</source>
        <translation>Späť</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="409"/>
        <source>Select Release Date</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="453"/>
        <source>fastest, worst compression</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="453"/>
        <source>fast, worse compression</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="454"/>
        <source>slow, better compression</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="454"/>
        <source>best compromise</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="455"/>
        <source>slowest, best compression</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="484"/>
        <source>Free space on %1, where snapshot folder is placed: </source>
        <translation>Voľné miesto na disku %1, na ktorom je obraz umiestnený: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="487"/>
        <source>The free space should be sufficient to hold the compressed data from / and /home

      If necessary, you can create more available space by removing previous snapshots and saved copies: %1 snapshots are taking up %2 of disk space.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="499"/>
        <location filename="../src/mainwindow.cpp" line="500"/>
        <source>Installing </source>
        <translation>Inštalácia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="585"/>
        <source>Please wait.</source>
        <translation>Čakajte prosím...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="587"/>
        <source>Please wait. Calculating used disk space...</source>
        <translation>Čakajte prosím, vypočítava sa použité miesto na disku...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="314"/>
        <location filename="../src/mainwindow.cpp" line="331"/>
        <location filename="../src/mainwindow.cpp" line="338"/>
        <location filename="../src/mainwindow.cpp" line="621"/>
        <location filename="../src/mainwindow.cpp" line="628"/>
        <location filename="../src/mainwindow.cpp" line="710"/>
        <location filename="../src/mainwindow.cpp" line="729"/>
        <location filename="../src/mainwindow.cpp" line="967"/>
        <source>Error</source>
        <translation>Chyba</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="178"/>
        <source>No diff output available.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="211"/>
        <location filename="../src/mainwindow.cpp" line="247"/>
        <source>Updated Exclusion List</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="214"/>
        <source>The exclusion file at %1 is newer than your configured file at %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="216"/>
        <source>Review the changes below. Keep your custom file or replace it with the updated default.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="222"/>
        <source>Show Differences</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="228"/>
        <source>Keep Custom</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="234"/>
        <source>Use Updated Default</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="315"/>
        <source>Default exclusion file not found at %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="327"/>
        <source>Warning</source>
        <translation>Upozornenie</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="328"/>
        <source>Could not backup existing exclusion file to %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="332"/>
        <source>Could not remove existing exclusion file at %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="339"/>
        <source>Could not copy default exclusion file from %1 to %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="622"/>
        <source>Output file %1 already exists. Please use another file name, or delete the existent file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="629"/>
        <source>Insufficient free space. Please select a different snapshot directory or free up space.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="633"/>
        <source>Settings</source>
        <translation>Nastavenia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="639"/>
        <source>Snapshot will use the following settings:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="641"/>
        <source>- Snapshot directory:</source>
        <translation>- Zložka pre umiestnenie obrazu:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="642"/>
        <source>- Kernel to be used:</source>
        <translation>- Linuxové jadro:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="666"/>
        <location filename="../src/mainwindow.cpp" line="675"/>
        <source>NVIDIA Detected</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="667"/>
        <source>This computer uses an NVIDIA graphics card. Are you planning to use the resulting ISO on the same computer or another computer with an NVIDIA card?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="671"/>
        <source>NVIDIA Selected</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="672"/>
        <source>Note: If you use the resulting ISO on a computer without an NVIDIA card, you will likely need to remove &apos;xorg=nvidia&apos; from the boot options.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="676"/>
        <source>Note: If you use the resulting ISO on a computer with an NVIDIA card, you may need to add &apos;xorg=nvidia&apos; to the boot options.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="711"/>
        <source>Could not replace the exclusion file with the updated default.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="730"/>
        <source>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="753"/>
        <source>Final chance</source>
        <translation>Posledná šanca</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="755"/>
        <source>Snapshot now has all the information it needs to create an ISO from your running system.</source>
        <translation>Snapshot má všetky potrebné informácie k vytvoreniu súboru ISO z vášho funkčného systému.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="756"/>
        <source>It will take some time to finish, depending on the size of the installed system and the capacity of your computer.</source>
        <translation>Tvorba obrazu zaberie nejaký čas, v závislosti na veľkosti nainštalovaného systému a výkone vášho PC. </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="758"/>
        <source>OK to start?</source>
        <translation>Chcete začať?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="762"/>
        <source>Shutdown computer when done.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="795"/>
        <source>Output</source>
        <translation>Výstup</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="811"/>
        <source>Close</source>
        <translation>Zavrieť</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="818"/>
        <source>Edit Boot Menu</source>
        <translation>Upraviť štartovnú ponuku</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="819"/>
        <source>The program will now pause to allow you to edit any files in the work directory. Select Yes to edit the boot menu or select No to bypass this step and continue creating the snapshot.</source>
        <translation>Program sa pozastaví aby Vám umožnil upraviť súbory v pracovnej zložke. Zvoľte Ano pre editáciu štartovnej ponuky alebo Nie ak si prajete preskočiť tento krok a pokračovať v tvorbe obrazu.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="855"/>
        <source>Revert the exclusion list to the default file? This will overwrite your current exclusions.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="935"/>
        <source>About %1</source>
        <translation>Okolo %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="937"/>
        <source>Version: </source>
        <translation>Verzia:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="938"/>
        <source>Program for creating a live-CD from the running system for MX Linux</source>
        <translation>Program pre tvorbu Live-CD z funkčného operačného systému MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="940"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="942"/>
        <source>%1 License</source>
        <translation>%1 Licencia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="955"/>
        <source>%1 Help</source>
        <translation>%1 Pomoc</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="960"/>
        <source>Select Snapshot Directory</source>
        <translation>Zvoľte zložku pre snapshot</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="968"/>
        <source>Insufficient free space in the selected directory. Please choose a different location.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="988"/>
        <source>Confirmation</source>
        <translation>Potvrdenie</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="988"/>
        <source>Are you sure you want to quit the application?</source>
        <translation>Skutočne si prajete ukončiť program?</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/main.cpp" line="95"/>
        <source>Tool used for creating a live-CD from the running system</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="99"/>
        <source>Use CLI only</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="103"/>
        <source>Number of CPU cores to be used.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="104"/>
        <source>Output directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="105"/>
        <source>Output filename</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="107"/>
        <source>Name a different kernel to use other than the default running kernel, use format returned by &apos;uname -r&apos;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="109"/>
        <source>Or the full path: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="112"/>
        <source>Compression level options.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>Use quotes: &quot;-Xcompression-level &lt;level&gt;&quot;, or &quot;-Xalgorithm &lt;algorithm&gt;&quot;, or &quot;-Xhc&quot;, see mksquashfs man page</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="117"/>
        <source>Create a monthly snapshot, add &apos;Month&apos; name in the ISO name, skip used space calculation</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="118"/>
        <source>This option sets reset-accounts and compression to defaults, arguments changing those items will be ignored</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="120"/>
        <source>Optionally specify a suffix to add to the month name (e.g., &apos;1&apos; for &apos;July.1&apos;)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="121"/>
        <source>Don&apos;t calculate checksums for resulting ISO file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="122"/>
        <source>Skip calculating free space to see if the resulting ISO will fit</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="123"/>
        <source>Option to fix issue with calculating checksums on preempt_rt kernels</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="124"/>
        <source>Resetting accounts (for distribution to others)</source>
        <translation>Resetovať kontá (distribúcia iným)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="125"/>
        <source>Calculate checksums for resulting ISO file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="127"/>
        <source>Throttle the I/O input rate by the given percentage. This can be used to reduce the I/O and CPU consumption of Mksquashfs.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="130"/>
        <source>Work directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="132"/>
        <source>Exclude main folders, valid choices: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="134"/>
        <source>Use the option one time for each item you want to exclude</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="137"/>
        <source>Compression format, valid choices: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="139"/>
        <source>Shutdown computer when done.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="213"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="231"/>
        <source>version:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="225"/>
        <source>You must run this program with sudo or pkexec.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="208"/>
        <source>MX Snapshot</source>
        <translation>MX Snapshot</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="215"/>
        <location filename="../src/main.cpp" line="283"/>
        <location filename="../src/settings.cpp" line="524"/>
        <location filename="../src/settings.cpp" line="532"/>
        <location filename="../src/settings.cpp" line="1062"/>
        <location filename="../src/settings.cpp" line="1156"/>
        <source>Error</source>
        <translation>Chyba</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="282"/>
        <location filename="../src/settings.cpp" line="531"/>
        <source>Current kernel doesn&apos;t support Squashfs, cannot continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="97"/>
        <source>Failed to initialize configuration</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="131"/>
        <source>Configuration validation failed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="136"/>
        <source>Exception during initialization: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="139"/>
        <source>Unknown exception during initialization</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="170"/>
        <source>Could not create work directory. </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="197"/>
        <source>Could not create temp directory:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="198"/>
        <source>Please check that the parent directory exists and is writable:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="216"/>
        <source>Compression format &apos;%1&apos; is not supported by the current kernel</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="222"/>
        <source>Invalid cores setting: %1. Must be between 1 and %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="228"/>
        <source>Invalid throttle setting: %1. Must be between 0 and 20</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="234"/>
        <source>Snapshot directory cannot be empty</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="242"/>
        <source>Snapshot name cannot be empty</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="248"/>
        <source>Snapshot name contains invalid characters: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="254"/>
        <source>Kernel version cannot be empty</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="259"/>
        <source>Kernel file not found: /boot/vmlinuz-%1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="265"/>
        <source>Kernel %1 doesn&apos;t support Squashfs</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="296"/>
        <source>Exclusion file does not exist: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="305"/>
        <source>Unbalanced quotes in exclusion list</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="330"/>
        <source>Insufficient free space: %1 KiB available, minimum %2 KiB required</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="337"/>
        <source>Insufficient free space in work directory: %1 KiB available, minimum %2 KiB required</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="352"/>
        <source>Failed to determine number of CPU cores</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="358"/>
        <source>Configuration file does not exist: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="359"/>
        <source>Using default settings</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="361"/>
        <source>Cannot read configuration file: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="362"/>
        <source>Error: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="372"/>
        <source>Required tool not found: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="381"/>
        <source>Required directory not found: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="400"/>
        <source>Initialization Error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="401"/>
        <source>Failed to initialize application settings:

%1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="522"/>
        <source>Could not find a usable kernel</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="523"/>
        <source>Searched for kernel files in /boot/ but none were found or accessible.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="544"/>
        <source>No users found in the system</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="547"/>
        <source>Failed to determine system information</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="641"/>
        <source>Used space on / (root): </source>
        <translation>Použitý priestor na disku / (root):</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="644"/>
        <source>estimated</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="653"/>
        <source>Used space on /home: </source>
        <translation>Použitý priestor na disku /home:</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="709"/>
        <source>Free space on %1, where snapshot folder is placed: </source>
        <translation>Voľné miesto na disku %1, na ktorom je obraz umiestnený: </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="713"/>
        <source>The free space should be sufficient to hold the compressed data from / and /home

      If necessary, you can create more available space
      by removing previous snapshots and saved copies:
      %1 snapshots are taking up %2 of disk space.
</source>
        <translation>Voľné miesto musí byť dostatočné pre umiestnenie komprimovaných dát z diskov / a /home

Ak to bude nutné, môžete uvoľnit miesto
odstránením predošlých obrazov alebo kópií systému:
%1 obrazy zaberajú %2 diskového priestoru.
</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="727"/>
        <source>Desktop</source>
        <translation>Pracovná plocha</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="728"/>
        <source>Documents</source>
        <translation>Dokumenty</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="729"/>
        <source>Downloads</source>
        <translation>Stiahnuté</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="730"/>
        <source>Flatpaks</source>
        <translation>Flatpaky</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="731"/>
        <source>Music</source>
        <translation>Hudba</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="732"/>
        <source>Networks</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="733"/>
        <source>Pictures</source>
        <translation>Obrázky</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="735"/>
        <source>Videos</source>
        <translation>Videá</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="884"/>
        <source>Error reading system configuration file: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="892"/>
        <source>Error accessing user configuration</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="944"/>
        <source>Could not copy exclusion file from %1 to %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="969"/>
        <source>Invalid stored cores setting (%1). Using detected CPU count: %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1060"/>
        <location filename="../src/settings.cpp" line="1154"/>
        <source>Output file %1 already exists. Please use another file name, or delete the existent file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="73"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <location filename="../src/about.cpp" line="107"/>
        <source>Changelog</source>
        <translation>História zmien</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="98"/>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="119"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="53"/>
        <location filename="../src/about.cpp" line="122"/>
        <source>&amp;Close</source>
        <translation>&amp;Zatvoriť</translation>
    </message>
</context>
<context>
    <name>Work</name>
    <message>
        <location filename="../src/work.cpp" line="173"/>
        <source>Cleaning...</source>
        <translation>Čistenie...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="189"/>
        <location filename="../src/work.cpp" line="467"/>
        <source>Done</source>
        <translation>Hotovo</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="201"/>
        <source>Interrupted or failed to complete</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="237"/>
        <location filename="../src/work.cpp" line="419"/>
        <location filename="../src/work.cpp" line="447"/>
        <location filename="../src/work.cpp" line="485"/>
        <location filename="../src/work.cpp" line="626"/>
        <location filename="../src/work.cpp" line="660"/>
        <location filename="../src/work.cpp" line="673"/>
        <location filename="../src/work.cpp" line="681"/>
        <source>Error</source>
        <translation>Chyba</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="238"/>
        <source>There&apos;s not enough free space on your target disk, you need at least %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="241"/>
        <source>You have %1 free space on %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="244"/>
        <source>If you are sure you have enough free space rerun the program with -o/--override-size option</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="330"/>
        <source>Copying the new-iso filesystem...</source>
        <translation>Kopíruje sa nový ISO systém súborov....</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="348"/>
        <source>Could not create temp directory. </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="416"/>
        <source>Squashing filesystem...</source>
        <translation>Tvorba systému súborov...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="420"/>
        <source>Could not create linuxfs file, please check /var/log/%1.log</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="444"/>
        <source>Creating CD/DVD image file...</source>
        <translation>Vytváranie CD/DVD obrazu...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="448"/>
        <source>Could not create ISO file, please check whether you have enough space on the destination partition.</source>
        <translation>Nepodarilo sa vytvoriť ISO súbor, prosím skontrolujte, či máte v cieľom umiestnení dostatok voľného miesta.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="454"/>
        <source>Making hybrid iso</source>
        <translation>Tvorba hybridného ISO</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="472"/>
        <source>Success</source>
        <translation>Úspech</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="473"/>
        <source>MX Snapshot completed successfully!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="474"/>
        <source>Snapshot took %1 to finish.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="475"/>
        <source>Thanks for using MX Snapshot, run MX Live USB Maker next!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="482"/>
        <source>Installing </source>
        <translation>Inštalácia</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="485"/>
        <source>Could not install </source>
        <translation>Nepodarilo sa nainštalovať</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="495"/>
        <source>Calculating checksum...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="536"/>
        <source>Building new initrd...</source>
        <translation>Tvorba nového initrd...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="627"/>
        <source>Could not create working directory. </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="661"/>
        <source>Could not prepare a safe bind-root overlay. Snapshot cannot continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="674"/>
        <location filename="../src/work.cpp" line="682"/>
        <source>Could not prepare the snapshot bind-root environment.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="986"/>
        <source>Calculating total size of excluded files...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1012"/>
        <source>Calculating size of root...</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>