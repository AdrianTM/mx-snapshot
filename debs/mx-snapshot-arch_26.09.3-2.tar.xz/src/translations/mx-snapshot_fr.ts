<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="fr">
<context>
    <name>Batchprocessing</name>
    <message>
        <location filename="../src/batchprocessing.cpp" line="53"/>
        <source>Error</source>
        <translation>Erreur</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="54"/>
        <source>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</source>
        <translation>Le noyau actuel ne supporte pas l’algorithme de compression choisi, veuillez éditer le fichier de configuration et sélectionner un algorithme différent.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="101"/>
        <source>The program will pause the build and open the boot menu in your text editor.</source>
        <translation>Le programme mettra en pause la compilation et ouvrira le menu de démarrage dans votre éditeur de texte.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="114"/>
        <source>The boot-menu editor failed; the snapshot cannot continue with potentially unedited files.</source>
        <translation>L’éditeur du menu d’amorçage a échoué ; l’instantané ne peut pas continuer avec des fichiers potentiellement non modifiés.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="131"/>
        <source>Administrator access was not granted; the snapshot cannot continue.</source>
        <translation>L’accès administrateur n’a pas été accordé ; la création du snapshot ne peut pas continuer.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="258"/>
        <source>Detected newer exclusion file at %1 compared to %2. Prompting for action.</source>
        <translation>Le fichier d’exclusion situé à %1 est plus récent que celui de %2. Une action de votre part est nécessaire.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="264"/>
        <source>s</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'show diff'</comment>
        <translation>a</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="265"/>
        <source>u</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'use updated default'</comment>
        <translation>u</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="266"/>
        <source>k</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'keep custom (update timestamp)'</comment>
        <translation>c</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="267"/>
        <source>q</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'quit'</comment>
        <translation>q</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="269"/>
        <source>show diff</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>afficher commande diff</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="270"/>
        <source>use updated default</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>utiliser le fichier par défaut mis à jour</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="271"/>
        <source>keep custom (update timestamp)</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>conserver le réglage personnalisé (mise à jour de l’horodatage)</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="272"/>
        <source>quit</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>quitter</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="275"/>
        <source>[%1]%2  [%3]%4  [%5]%6  [%7]%8: </source>
        <translation>[%1]%2  [%3]%4  [%5]%6  [%7]%8 : </translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="280"/>
        <source>The exclusion file at %1 is newer than your configured file at %2.</source>
        <translation>Le fichier d’exclusion à %1 est plus récent que votre fichier configuré à %2.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="296"/>
        <source>Reverted to updated default exclusion file.</source>
        <translation>Rétablissement du fichier d’exclusion par défaut mis à jour.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="313"/>
        <source>No input available to answer the exclusion file prompt; aborting without creating a snapshot.</source>
        <translation>Aucune entrée disponible pour l’invite du fichier d’exclusion ; le snapshot n’a pas été créé.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="316"/>
        <source>Leaving custom exclusion file unchanged.</source>
        <translation>Maintien du fichier d’exclusion personnalisé sans modification.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="327"/>
        <source>Invalid choice. Please select again.</source>
        <translation>Choix incorrect. Veuillez refaire votre sélection.</translation>
    </message>
</context>
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="121"/>
        <source>No elevation tool found (pkexec/gksu/sudo).</source>
        <translation>Impossible de trouver un outil d’élévation de privilèges (pkexec/gksu/sudo).</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="212"/>
        <source>Failed to start command: %1</source>
        <translation>Impossible de démarrer la commande : %1</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="283"/>
        <source>Administrator access was not granted (authentication cancelled or denied).</source>
        <translation>L’accès administrateur n’a pas été accordé (authentification annulée ou refusée).</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <location filename="../src/mainwindow.cpp" line="396"/>
        <location filename="../src/mainwindow.cpp" line="944"/>
        <source>MX Snapshot</source>
        <translation>MX Instantané - MX Snapshot</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="33"/>
        <source>Optional customization</source>
        <translation>Personnalisation facultative</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="65"/>
        <source>Release version:</source>
        <translation>Version :</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="79"/>
        <source>Boot options:</source>
        <translation>Options de démarrage :</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="86"/>
        <source>Live kernel:</source>
        <translation>Noyau live :</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="93"/>
        <source>Project name:</source>
        <translation>Nom du projet :</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="100"/>
        <source>Release date:</source>
        <translation>Date de parution :</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="107"/>
        <source>Release codename:</source>
        <translation>Nom de code de la version :</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="133"/>
        <source>Current date</source>
        <translation>Date du jour</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="172"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Snapshot is a utility that creates a bootable image (ISO) of your working system that you can use for storage or distribution. You can continue working with undemanding applications while it is running.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Snapshot est un utilitaire qui crée une image amorçable (ISO) de votre système actuel pour que vous puissiez la conserver ou la distribuer. Vous pouvez utiliser d’autres applications légères pendant son fonctionnement.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="182"/>
        <source>Used space on / (root) and /home partitions:</source>
        <translation>Espace utilisé sur les partitions /(root) et /home :</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="192"/>
        <source>Location and ISO name</source>
        <translation>Emplacement et nom de l’ISO</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="219"/>
        <source>Snapshot location:</source>
        <translation>Emplacement de l’instantané :</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="226"/>
        <source>Select a different snapshot directory</source>
        <translation>Choisir un répertoire différent pour l’instantané</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="236"/>
        <location filename="../src/mainwindow.cpp" line="644"/>
        <source>Snapshot name:</source>
        <translation>Nom de l’instantané :</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="360"/>
        <source>Type of snapshot:</source>
        <translation>Type d’instantané :</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="367"/>
        <source>Preserving accounts (for personal backup)</source>
        <translation>Conservation des comptes (pour une sauvegarde personnelle)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This option will reset &amp;quot;demo&amp;quot; and &amp;quot;root&amp;quot; passwords to the MX Linux defaults and will not copy any personal accounts created.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Cette option réinitialisera les mots de passe &amp;quot;demo&amp;quot; et &amp;quot;root&amp;quot; aux valeurs par défauts de MX Linux et ne copiera pas les comptes personnels.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="380"/>
        <source>Resetting accounts (for distribution to others)</source>
        <translation>Réinitialisation des comptes (pour distribuer à d’autres personnes)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="451"/>
        <source>You can also exclude certain directories by ticking the common choices below, or by clicking on the button to directly edit /etc/mx-snapshot-exclude.list.</source>
        <translation>Vous pouvez aussi exclure certains répertoires en cochant les options courantes ci-dessous, ou en cliquant sur le bouton pour modifier directement  /etc/mx-snapshot-exclude.list.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="496"/>
        <source>sha512</source>
        <translation>sha512</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="519"/>
        <source>Throttle the I/O input rate by the given percentage.</source>
        <translation>Réduire le taux d’entrée des I/O - Entrées/Sorties - selon le pourcentage donné.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="525"/>
        <source>I/O throttle:</source>
        <translation>Limite des I/O - Entrées/Sorties :</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="532"/>
        <source>Calculate checksums:</source>
        <translation>Calcul des sommes de contrôle :</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="539"/>
        <source>ISO compression scheme:</source>
        <translation>Méthode de compression de l’ISO :</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="546"/>
        <source>Number of CPU cores to use:</source>
        <translation>Nombre de cœurs du processeur à utiliser :</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="553"/>
        <source>md5</source>
        <translation>md5</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="563"/>
        <source>Options:</source>
        <translation>Options :</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="610"/>
        <source>Edit Exclusion File</source>
        <translation>Éditer le fichier d’exclusion</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="626"/>
        <location filename="../src/mainwindow.cpp" line="969"/>
        <source>Remove Custom Exclusion File</source>
        <translation>Supprimer le fichier d’exclusion personnalisé</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="679"/>
        <source>Pictures</source>
        <translation>Photos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="686"/>
        <source>Videos</source>
        <translation>Vidéos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="693"/>
        <source>All of the above</source>
        <translation>Tout ce qui précède</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="700"/>
        <source>exclude network configurations</source>
        <translation>exclure les configurations réseau</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="703"/>
        <source>Networks</source>
        <translation>Réseaux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="710"/>
        <source>Downloads</source>
        <translation>Téléchargements</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="717"/>
        <source>Desktop</source>
        <translation>Bureau</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="724"/>
        <source>Documents</source>
        <translation>Documents</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="731"/>
        <source>Flatpaks</source>
        <translation>Flatpaks</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="738"/>
        <source>Music</source>
        <translation>Musique</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="881"/>
        <source>About this application</source>
        <translation>À propos de cette application</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="884"/>
        <source>About...</source>
        <translation>À propos…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="890"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1005"/>
        <source>Next</source>
        <translation>Suivant</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="906"/>
        <source>Display help </source>
        <translation>Afficher l’aide </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="909"/>
        <source>Help</source>
        <translation>Aide</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="915"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1030"/>
        <source>Quit application</source>
        <translation>Quitter l’application</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1033"/>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1039"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="989"/>
        <source>Back</source>
        <translation>Retour</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="358"/>
        <source>Select Release Date</source>
        <translation>Choisir la date de publication</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="402"/>
        <source>fastest, worst compression</source>
        <translation>compression la plus rapide et la plus mauvaise</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="402"/>
        <source>fast, worse compression</source>
        <translation>compression rapide et moins bonne</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="403"/>
        <source>slow, better compression</source>
        <translation>compression lente et bonne</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="403"/>
        <source>best compromise</source>
        <translation>meilleur compromis</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="404"/>
        <source>slowest, best compression</source>
        <translation>compression la plus lente et la meilleure</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="433"/>
        <source>Free space on %1, where snapshot folder is placed: </source>
        <translation>Espace libre disponible dans %1 où sera mis le dossier de l’instantané : </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="436"/>
        <source>The free space should be sufficient to hold the compressed data from / and /home

      If necessary, you can create more available space by removing previous snapshots and saved copies: %1 snapshots are taking up %2 of disk space.</source>
        <translation>L’espace libre doit être suffisant pour contenir les données compressées de / et de /home.

      Si nécessaire, vous pouvez créer plus d’espace disponible en supprimant les instantanés précédents et les copies sauvegardées : les instantanés « snapshots » %1 occupent %2 de l’espace disque.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="448"/>
        <location filename="../src/mainwindow.cpp" line="449"/>
        <source>Installing </source>
        <translation>Installation </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="587"/>
        <source>Please wait.</source>
        <translation>Veuillez patienter…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="589"/>
        <source>Please wait. Calculating used disk space...</source>
        <translation>Veuillez patienter. Calcul de l’espace disque utilisé…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="275"/>
        <location filename="../src/mainwindow.cpp" line="489"/>
        <location filename="../src/mainwindow.cpp" line="623"/>
        <location filename="../src/mainwindow.cpp" line="630"/>
        <location filename="../src/mainwindow.cpp" line="712"/>
        <location filename="../src/mainwindow.cpp" line="723"/>
        <location filename="../src/mainwindow.cpp" line="748"/>
        <location filename="../src/mainwindow.cpp" line="1034"/>
        <source>Error</source>
        <translation>Erreur</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="175"/>
        <location filename="../src/mainwindow.cpp" line="211"/>
        <source>Updated Exclusion List</source>
        <translation>Liste d’exclusion actualisée</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="178"/>
        <source>The exclusion file at %1 is newer than your configured file at %2.</source>
        <translation>Le fichier d’exclusion à %1 est plus récent que votre fichier configuré à %2.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="180"/>
        <source>Review the changes below. Keep your custom file or replace it with the updated default.</source>
        <translation>Examinez les modifications ci-dessous. Conservez votre fichier personnalisé ou remplacez-le par le fichier par défaut mis à jour.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="186"/>
        <source>Show Differences</source>
        <translation>Afficher les différences</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="192"/>
        <source>Keep Custom</source>
        <translation>Conserver le fichier personnalisé</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="198"/>
        <source>Use Updated Default</source>
        <translation>Utiliser le fichier par défaut mis à jour</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="490"/>
        <source>Administrator access was not granted; the snapshot cannot continue.</source>
        <translation>L’accès administrateur n’a pas été accordé ; la création du snapshot ne peut pas continuer.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="522"/>
        <source>Done</source>
        <translation>Terminé</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="624"/>
        <source>Output file %1 already exists. Please use another file name, or delete the existent file.</source>
        <translation>Le nom de fichier %1 existe déjà. Veuillez utiliser un autre nom de fichier ou supprimer le fichier existant.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="631"/>
        <source>Insufficient free space. Please select a different snapshot directory or free up space.</source>
        <translation>Espace libre insuffisant. Veuillez sélectionner un autre répertoire ou libérer de l’espace.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="635"/>
        <source>Settings</source>
        <translation>Paramètres</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="641"/>
        <source>Snapshot will use the following settings:</source>
        <translation>Snapshot utilisera les paramètres suivants :</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="643"/>
        <source>- Snapshot directory:</source>
        <translation>- Répertoire de l’instantané :</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="644"/>
        <source>- Kernel to be used:</source>
        <translation>- Noyau à utiliser :</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="668"/>
        <location filename="../src/mainwindow.cpp" line="677"/>
        <source>NVIDIA Detected</source>
        <translation>NVIDIA détecté</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="669"/>
        <source>This computer uses an NVIDIA graphics card. Are you planning to use the resulting ISO on the same computer or another computer with an NVIDIA card?</source>
        <translation>Cet ordinateur utilise une carte graphique NVIDIA. Prévoyez-vous d’utiliser l’ISO obtenu sur le même ordinateur ou sur un autre ordinateur équipé d’une carte NVIDIA ?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="673"/>
        <source>NVIDIA Selected</source>
        <translation>NVIDIA sélectionné</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="674"/>
        <source>Note: If you use the resulting ISO on a computer without an NVIDIA card, you will likely need to remove &apos;xorg=nvidia&apos; from the boot options.</source>
        <translation>Remarque : si vous utilisez l’ISO résultant sur un ordinateur sans carte NVIDIA, vous devrez probablement supprimer « xorg=nvidia » des options de démarrage.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="678"/>
        <source>Note: If you use the resulting ISO on a computer with an NVIDIA card, you may need to add &apos;xorg=nvidia&apos; to the boot options.</source>
        <translation>Remarque : si vous utilisez l’ISO obtenu sur un ordinateur équipé d’une carte NVIDIA, vous devrez peut-être ajouter « xorg=nvidia » aux options de démarrage.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="276"/>
        <location filename="../src/mainwindow.cpp" line="713"/>
        <source>Could not replace the exclusion file with the updated default.</source>
        <translation>Impossible de remplacer le fichier d’exclusion par le fichier par défaut mis à jour.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="724"/>
        <source>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</source>
        <translation>Le noyau actuel ne supporte pas l’algorithme de compression choisi, veuillez éditer le fichier de configuration et sélectionner un algorithme différent.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="744"/>
        <source>Cancelled</source>
        <translation>Annulé</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="745"/>
        <source>Administrator access is required to create a snapshot.</source>
        <translation>L’accès administrateur est requis pour créer un snapshot.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="746"/>
        <source>The operation was cancelled. Select Next when you are ready to try again.</source>
        <translation>L’opération a été annulée. Sélectionnez « Suivant » lorsque vous serez prêt à réessayer.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="749"/>
        <source>Could not create the snapshot or work directory.</source>
        <translation>Impossible de créer le snapshot ou le répertoire de travail.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="762"/>
        <source>Final chance</source>
        <translation>Dernière occasion d’arrêter le processus</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="764"/>
        <source>Snapshot now has all the information it needs to create an ISO from your running system.</source>
        <translation>Snapshot dispose désormais de toutes les informations nécessaires à la création du fichier ISO instantané de votre système.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="765"/>
        <source>It will take some time to finish, depending on the size of the installed system and the capacity of your computer.</source>
        <translation>Selon la taille de votre image et la puissance de votre ordinateur, le processus peut durer un certain temps.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="767"/>
        <source>OK to start?</source>
        <translation>Prêt à démarrer ?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="824"/>
        <location filename="../src/mainwindow.cpp" line="771"/>
        <source>Shutdown computer when done.</source>
        <translation>Arrêter l’ordinateur une fois terminé.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="805"/>
        <source>Output</source>
        <translation>Résultats</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="849"/>
        <source>Close</source>
        <translation>Quitter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="924"/>
        <source>Edit Boot Menu</source>
        <translation>Éditer le menu de démarrage</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="925"/>
        <source>The program will now pause to allow you to edit any files in the work directory. Select Yes to edit the boot menu or select No to bypass this step and continue creating the snapshot.</source>
        <translation>Le programme va se mettre en pause afin de vous permettre d’éditer les fichiers du répertoire de travail. Veuillez choisir Yes pour éditer le menu de démarrage, ou No pour passer cette étape et continuer la création de l’instantané.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="970"/>
        <source>Revert the exclusion list to the default file? This will overwrite your current exclusions.</source>
        <translation>Rétablir la liste d’exclusion avec le fichier par défaut ? Cela écrasera vos exclusions actuelles.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1002"/>
        <source>About %1</source>
        <translation>À propos %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1004"/>
        <source>Version: </source>
        <translation>Version : </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1005"/>
        <source>Program for creating a live-CD from the running system for MX Linux</source>
        <translation>Programme créant un instantané du système MX Linux en fonctionnement sous forme d’un live CD.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1007"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1009"/>
        <source>%1 License</source>
        <translation>%1 Licence</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1022"/>
        <source>%1 Help</source>
        <translation>%1 Aide</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1027"/>
        <source>Select Snapshot Directory</source>
        <translation>Choisissez un répertoire pour l’instantané</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1035"/>
        <source>Insufficient free space in the selected directory. Please choose a different location.</source>
        <translation>Espace libre insuffisant dans le répertoire sélectionné. Veuillez choisir un autre emplacement.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1079"/>
        <source>Confirmation</source>
        <translation>Confirmation</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1079"/>
        <source>Are you sure you want to quit the application?</source>
        <translation>Êtes-vous sûr de vouloir quitter l’application ?</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/main.cpp" line="109"/>
        <source>Tool used for creating a live-CD from the running system</source>
        <translation>Outil de création d’un live-CD à partir d’un système en cours de fonctionnement</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>Use CLI only</source>
        <translation>Utiliser seulement CLI</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="117"/>
        <source>Number of CPU cores to be used.</source>
        <translation>Nombre de cœurs du processeur devant être utilisés.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="118"/>
        <source>Output directory</source>
        <translation>Répertoire de destination</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="119"/>
        <source>Output filename</source>
        <translation>Nom du fichier de destination</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="121"/>
        <source>Name a different kernel to use other than the default running kernel, use format returned by &apos;uname -r&apos;</source>
        <translation>Désignez un noyau différent devant être utilisé à la place du noyau fonctionnant par défaut, en utilisant le format renvoyé par « uname -r »</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="123"/>
        <source>Or the full path: %1</source>
        <translation>Ou le chemin entier : %1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="126"/>
        <source>Compression level options.</source>
        <translation>Options du niveau de compression.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="127"/>
        <source>Use quotes: &quot;-Xcompression-level &lt;level&gt;&quot;, or &quot;-Xalgorithm &lt;algorithm&gt;&quot;, or &quot;-Xhc&quot;, see mksquashfs man page</source>
        <translation>Entourez ces options de guillemets : &quot;-Xcompression-level &lt;level&gt;&quot; ou &quot;-Xalgorithm &lt;algorithm&gt;&quot; ou &quot;-Xhc&quot;. Voir la page de manuel (man) consacrée à mksquashfs</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="131"/>
        <source>Create a monthly snapshot, add &apos;Month&apos; name in the ISO name, skip used space calculation</source>
        <translation>Créer un instantané mensuel, inclure le nom du « mois » dans le nom de l’ISO et ignorer le calcul de l’espace utilisé</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="132"/>
        <source>This option sets reset-accounts and compression to defaults, arguments changing those items will be ignored</source>
        <translation>Cette option définit les comptes de réinitialisation et la compression par défaut, les arguments modifiant ces éléments seront ignorés</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="134"/>
        <source>Optionally specify a suffix to add to the month name (e.g., &apos;1&apos; for &apos;July.1&apos;)</source>
        <translation>Vous pouvez éventuellement spécifier un suffixe à ajouter au nom du mois (par exemple, « 1 » pour « juillet.1 »).</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="135"/>
        <source>Don&apos;t calculate checksums for resulting ISO file</source>
        <translation>Ne pas calculer les sommes de contrôle pour le fichier ISO obtenu</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="136"/>
        <source>Skip calculating free space to see if the resulting ISO will fit</source>
        <translation>Ne pas calculer l’espace libre pour voir si l’ISO qui en résulte tiendra dans l’espace.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="137"/>
        <source>Option to fix issue with calculating checksums on preempt_rt kernels</source>
        <translation>Option permettant de régler les problèmes lors du calcul de la somme de contrôle des noyaux preempt_rt (noyaux temps réel)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="138"/>
        <source>Resetting accounts (for distribution to others)</source>
        <translation>Réinitialisation des comptes (pour distribuer à d’autres personnes)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="139"/>
        <source>Calculate checksums for resulting ISO file</source>
        <translation>Calculer les sommes de contrôle pour le fichier ISO obtenu</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="141"/>
        <source>Throttle the I/O input rate by the given percentage. This can be used to reduce the I/O and CPU consumption of Mksquashfs.</source>
        <translation>Réduire le taux d’entrée des I/O - Entrées/Sorties - selon le pourcentage donné. Cela peut être utilisé pour réduire les I/O et la consommation du CPU de Mksquashfs.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="144"/>
        <source>Work directory</source>
        <translation>Répertoire de travail</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="146"/>
        <source>Exclude main folders, valid choices: </source>
        <translation>Exclure les dossiers principaux, choix valables : </translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="148"/>
        <source>Use the option one time for each item you want to exclude</source>
        <translation>Répétez cette option pour chaque élément à exclure</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="151"/>
        <source>Compression format, valid choices: </source>
        <translation>Format de compression, choix valables : </translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="153"/>
        <source>Shutdown computer when done.</source>
        <translation>Arrêter l’ordinateur une fois terminé.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="154"/>
        <source>Use grub for legacy mbr iso boot instead of isolinux/syslinux.</source>
        <translation>Utiliser GRUB pour l’amorçage ISO MBR hérité (legacy) à la place d’ISOLINUX/SYSLINUX.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="155"/>
        <source>Add the &apos;xorg=nvidia&apos; boot option to the ISO (for booting on a system with an NVIDIA card).</source>
        <translation>Ajoutez l’option de démarrage « xorg=nvidia » à l’ISO (pour démarrer sur un système équipé d’une carte NVIDIA).</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="163"/>
        <source>Optional suffix for a monthly snapshot; only valid together with --month.</source>
        <translation>Suffixe optionnel pour un instantané mensuel ; uniquement valide avec --month.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="196"/>
        <source>A single suffix positional argument is only valid together with --month.</source>
        <translation>Un seul argument positionnel de suffixe n’est valide qu’avec --month.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="255"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Vous êtes apparemment connecté en tant que root, veuillez vous déconnecter et vous connecter en tant qu’utilisateur normal pour utiliser ce programme.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="270"/>
        <source>version:</source>
        <translation>version :</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="266"/>
        <source>You must run this program with sudo or pkexec.</source>
        <translation>Vous devez exécuter ce programme avec sudo ou pkexec.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="235"/>
        <source>MX Snapshot</source>
        <translation>MX Instantané - MX Snapshot</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="257"/>
        <location filename="../src/main.cpp" line="343"/>
        <location filename="../src/settings.cpp" line="770"/>
        <location filename="../src/settings.cpp" line="779"/>
        <location filename="../src/settings.cpp" line="1396"/>
        <location filename="../src/settings.cpp" line="1506"/>
        <source>Error</source>
        <translation>Erreur</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="300"/>
        <source>Fatal error:</source>
        <translation>Une erreur a interrompu l’opération.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="302"/>
        <source>Fatal error: unknown exception</source>
        <translation>Une erreur s’est produite en raison d’une exception inconnue.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="342"/>
        <location filename="../src/settings.cpp" line="778"/>
        <source>Current kernel doesn&apos;t support Squashfs, cannot continue.</source>
        <translation>Le noyau actuel ne supporte pas Squashfs, impossible de continuer.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="261"/>
        <source>Exception during initialization: %1</source>
        <translation>Erreur lors de l’initialisation : %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="216"/>
        <source>Pending Arch bind-root cleanup state but installed-to-live-arch is missing: %1</source>
        <translation>État en attente pour le nettoyage bind-root d’Arch, mais « installed-to-live-arch » est manquant : %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="264"/>
        <source>Unknown exception during initialization</source>
        <translation>Erreur inconnue lors de l’initialisation</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="299"/>
        <source>Could not create work directory. </source>
        <translation>Impossible de créer le répertoire de travail. </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="382"/>
        <source>No suitable filesystem found for the temp directory. Tried /tmp, /home, and the snapshot directory.</source>
        <translation>Aucun système de fichiers pris en charge n’a été trouvé pour le dossier temporaire. Les emplacements /tmp, /home et le dossier de l’instantané ont été testés.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="393"/>
        <source>Could not create temp directory:</source>
        <translation>Impossible de créer le répertoire temporaire :</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="394"/>
        <source>Please check that the parent directory exists and is writable:</source>
        <translation>Veuillez vérifier que le répertoire parent existe et qu’il est accessible en écriture :</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="412"/>
        <source>Compression format &apos;%1&apos; is not supported by the current kernel</source>
        <translation>Le format de compression « %1 » n’est pas pris en charge par le noyau actuel</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="418"/>
        <source>Invalid cores setting: %1. Must be between 1 and %2</source>
        <translation>Paramètre de cœurs non valide : %1. Doit être compris entre 1 et %2</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="427"/>
        <source>Invalid throttle setting: %1. Must be between 0 and 99</source>
        <translation>Paramètre de limitation invalide : %1. La valeur doit être comprise entre 0 et 99</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="433"/>
        <source>Snapshot directory cannot be empty</source>
        <translation>Le répertoire Snapshot (Instantané) ne peut pas être vide</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="441"/>
        <source>Snapshot name cannot be empty</source>
        <translation>Le nom du snapshot (instantané) ne peut pas être vide</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="447"/>
        <source>Snapshot name contains invalid characters: %1</source>
        <translation>Le nom du snapshot (instantané) contient des caractères non valides : %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="453"/>
        <source>Kernel version cannot be empty</source>
        <translation>La version du noyau ne peut pas être vide</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="458"/>
        <source>Kernel file not found: /boot/vmlinuz-%1</source>
        <translation>Fichier noyau introuvable : /boot/vmlinuz-%1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="465"/>
        <source>Kernel %1 doesn&apos;t support Squashfs</source>
        <translation>Le noyau %1 ne prend pas en charge Squashfs</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="496"/>
        <source>Exclusion file does not exist: %1</source>
        <translation>Le fichier d’exclusion n’existe pas : %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="505"/>
        <source>Unbalanced quotes in exclusion list</source>
        <translation>Guillemets non équilibrés dans la liste d’exclusion</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="530"/>
        <source>Insufficient free space: %1 KiB available, minimum %2 KiB required</source>
        <translation>Espace libre insuffisant : %1 Ko (KiB) disponible, minimum %2 Ko (KiB) requis</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="537"/>
        <source>Insufficient free space in work directory: %1 KiB available, minimum %2 KiB required</source>
        <translation>Espace libre insuffisant dans le répertoire de travail : %1 Ko (KiB) disponible, minimum %2 Ko (KiB) requis</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="552"/>
        <source>Failed to determine number of CPU cores</source>
        <translation>Impossible de déterminer le nombre de cœurs du processeur</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="558"/>
        <source>Configuration file does not exist: %1</source>
        <translation>Le fichier de configuration n’existe pas : %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="559"/>
        <source>Using default settings</source>
        <translation>Utilisation des paramètres par défaut</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="561"/>
        <source>Cannot read configuration file: %1</source>
        <translation>Impossible de lire le fichier de configuration : %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="562"/>
        <source>Error: %1</source>
        <translation>Erreur : %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="572"/>
        <source>Required tool not found: %1</source>
        <translation>Outil requis introuvable : %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="581"/>
        <source>Required directory not found: %1</source>
        <translation>Répertoire requis introuvable : %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="600"/>
        <source>Initialization Error</source>
        <translation>Erreur d’initialisation</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="601"/>
        <source>Failed to initialize application settings:

%1</source>
        <translation>Impossible d’initialiser les paramètres de l’application :

%1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="768"/>
        <source>Could not find a usable kernel</source>
        <translation>Impossible de trouver un noyau utilisable</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="769"/>
        <source>Searched for kernel files in /boot/ but none were found or accessible.</source>
        <translation>Recherche de fichiers du noyau dans /boot/, mais aucun n’a été trouvé ou n’était accessible.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="791"/>
        <source>No users found in the system</source>
        <translation>Aucun utilisateur trouvé dans le système</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="794"/>
        <source>Failed to determine system information</source>
        <translation>Impossible de déterminer les informations système</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="964"/>
        <source>Used space on / (root): </source>
        <translation>Espace utilisé dans /(root) : </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="980"/>
        <source>estimated</source>
        <translation>estimé</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="987"/>
        <source>Used space on /home: </source>
        <translation>Espace utilisé dans /home : </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1048"/>
        <source>Free space on %1, where snapshot folder is placed: </source>
        <translation>Espace libre disponible dans %1 où sera mis le dossier de l’instantané : </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1052"/>
        <source>The free space should be sufficient to hold the compressed data from / and /home

      If necessary, you can create more available space
      by removing previous snapshots and saved copies:
      %1 snapshots are taking up %2 of disk space.
</source>
        <translation>L’espace libre doit pouvoir contenir les données compressées de / et de /home

Si nécessaire, vous pouvez obtenir de l’espace supplémentaire en supprimant les instantanés et les copies créées auparavant :
Les instantanés « snapshots » %1 occupent %2 de l’espace disque.
</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1199"/>
        <source>Error reading system configuration file: %1</source>
        <translation>Erreur lors de la lecture du fichier de configuration du système : %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1208"/>
        <source>Error accessing user configuration</source>
        <translation>Erreur lors de l’accès à la configuration de l’utilisateur</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1260"/>
        <source>Could not copy exclusion file from %1 to %2</source>
        <translation>Impossible de copier le fichier d’exclusion de %1 vers %2</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1283"/>
        <source>Unsupported compression &apos;%1&apos; in configuration, using zstd.</source>
        <translation>Compression « %1 » non prise en charge dans la configuration ; zstd sera utilisé.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1293"/>
        <source>Invalid stored cores setting (%1). Using detected CPU count: %2</source>
        <translation>Paramètre de cœurs mémorisés non valide (%1). Nombre de processeurs détectés utilisé : %2</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1303"/>
        <source>Invalid stored throttle setting (%1). Using 0.</source>
        <translation>Paramètre de limitation enregistré non valide (%1). La valeur numérique 0 sera utilisée.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1394"/>
        <location filename="../src/settings.cpp" line="1504"/>
        <source>Output file %1 already exists. Please use another file name, or delete the existent file.</source>
        <translation>Le nom de fichier %1 existe déjà. Veuillez utiliser un autre nom de fichier ou supprimer le fichier existant.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="73"/>
        <source>Could not load %1</source>
        <translation>Impossible de charger %1</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>License</source>
        <translation>Licence</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <location filename="../src/about.cpp" line="107"/>
        <source>Changelog</source>
        <translation>Journal des modifications</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="98"/>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="119"/>
        <source>Could not load changelog.</source>
        <translation>Impossible de charger le journal des modifications.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="53"/>
        <location filename="../src/about.cpp" line="122"/>
        <source>&amp;Close</source>
        <translation>&amp;Quitter</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="78"/>
        <source>No diff output available.</source>
        <translation>La commande « diff » ne donne aucun résultat.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="91"/>
        <source>Could not open default exclusion file at %1.</source>
        <translation>Impossible d’ouvrir le fichier d’exclusion par défaut à %1.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="97"/>
        <source>Could not create exclusion file directory at %1.</source>
        <translation>Impossible de créer le répertoire du fichier d’exclusion à %1.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="106"/>
        <source>Could not prepare exclusion file at %1.</source>
        <translation>Impossible de préparer le fichier d’exclusion à %1.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="123"/>
        <source>Could not read default exclusion file at %1.</source>
        <translation>Impossible de lire le fichier d’exclusion par défaut à %1.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="131"/>
        <source>Could not write exclusion file at %1.</source>
        <translation>Impossible d’écrire le fichier d’exclusion à %1.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="113"/>
        <source>Could not backup existing exclusion file to %1.</source>
        <translation>Impossible de sauvegarder le fichier d’exclusion existant vers %1.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="139"/>
        <source>Could not copy default exclusion file from %1 to %2.</source>
        <translation>Impossible de copier le fichier d’exclusion par défaut de %1 vers %2.</translation>
    </message>
</context>
<context>
    <name>Work</name>
    <message>
        <location filename="../src/work.cpp" line="312"/>
        <source>Cleaning...</source>
        <translation>Nettoyage…</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="343"/>
        <location filename="../src/work.cpp" line="1125"/>
        <source>Done</source>
        <translation>Terminé</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="357"/>
        <source>Interrupted or failed to complete</source>
        <translation>Interrompu ou non terminé</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="368"/>
        <location filename="../src/work.cpp" line="425"/>
        <location filename="../src/work.cpp" line="629"/>
        <location filename="../src/work.cpp" line="637"/>
        <location filename="../src/work.cpp" line="672"/>
        <location filename="../src/work.cpp" line="715"/>
        <location filename="../src/work.cpp" line="743"/>
        <location filename="../src/work.cpp" line="757"/>
        <location filename="../src/work.cpp" line="771"/>
        <location filename="../src/work.cpp" line="779"/>
        <location filename="../src/work.cpp" line="785"/>
        <location filename="../src/work.cpp" line="793"/>
        <location filename="../src/work.cpp" line="842"/>
        <location filename="../src/work.cpp" line="858"/>
        <location filename="../src/work.cpp" line="919"/>
        <location filename="../src/work.cpp" line="934"/>
        <location filename="../src/work.cpp" line="942"/>
        <location filename="../src/work.cpp" line="953"/>
        <location filename="../src/work.cpp" line="961"/>
        <location filename="../src/work.cpp" line="1078"/>
        <location filename="../src/work.cpp" line="1095"/>
        <location filename="../src/work.cpp" line="1108"/>
        <location filename="../src/work.cpp" line="1116"/>
        <location filename="../src/work.cpp" line="1177"/>
        <location filename="../src/work.cpp" line="1468"/>
        <location filename="../src/work.cpp" line="1476"/>
        <location filename="../src/work.cpp" line="1490"/>
        <location filename="../src/work.cpp" line="1529"/>
        <location filename="../src/work.cpp" line="1579"/>
        <location filename="../src/work.cpp" line="1603"/>
        <source>Error</source>
        <translation>Erreur</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="369"/>
        <source>Administrator access was not granted; the snapshot cannot continue.</source>
        <translation>L’accès administrateur n’a pas été accordé ; la création du snapshot ne peut pas continuer.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="426"/>
        <source>There&apos;s not enough free space on your target disk, you need at least %1</source>
        <translation>Il n’y a pas assez d’espace libre sur votre disque cible, vous avez besoin d’au moins %1</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="429"/>
        <source>You have %1 free space on %2</source>
        <translation>Vous avez %1 d’espace libre sur %2</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="432"/>
        <source>If you are sure you have enough free space rerun the program with -o/--override-size option</source>
        <translation>Si vous êtes certain d’avoir assez d’espace libre, relancez le programme avec l’option -o/--override-size</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="610"/>
        <source>Copying the new-iso filesystem...</source>
        <translation>Copie du nouveau système de fichiers iso en cours…</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="629"/>
        <source>ISO template not found: </source>
        <translation>Modèle ISO introuvable : </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="637"/>
        <location filename="../src/work.cpp" line="757"/>
        <source>Could not extract the ISO template: </source>
        <translation>Impossible d’extraire le modèle ISO : </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="665"/>
        <source>Arch ISO template is missing boot/ or efi/ directories.</source>
        <translation>Le modèle ISO Arch est incomplet : les répertoires boot/ ou efi/ sont absents.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="668"/>
        <source>Detected boot/ or efi/ under the work directory root; the template may have been extracted to the wrong location.</source>
        <translation>Des répertoires boot/ ou efi/ ont été trouvés à la racine du répertoire de travail ; il est possible que le modèle ait été extrait à un emplacement incorrect.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="671"/>
        <source>Template: %1</source>
        <translation>Modèle : %1</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="707"/>
        <source>Stale archiso initramfs detected, rebuilding...</source>
        <translation>Un initramfs archiso obsolète a été détecté ; reconstruction en cours…</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="709"/>
        <source>Found /boot/archiso.img built for kernel %1, but the selected kernel is %2.</source>
        <translation>Fichier /boot/archiso.img détecté pour le noyau %1, alors que le noyau sélectionné est %2.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="713"/>
        <source>Rebuilding /boot/archiso.img failed. Please rebuild it manually or remove the stale file.</source>
        <translation>La reconstruction de /boot/archiso.img n’a pas abouti. Vous pouvez le reconstruire manuellement ou supprimer le fichier obsolète.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="725"/>
        <source>No /boot/archiso.img found, attempting to create one...</source>
        <translation>Aucun fichier /boot/archiso.img trouvé, tentative de création…</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="730"/>
        <location filename="../src/work.cpp" line="1167"/>
        <source>Warning</source>
        <translation>Attention</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="731"/>
        <source>Could not create /boot/archiso.img (is the &apos;archiso&apos; package installed?). Falling back to the regular initramfs — the resulting ISO will likely fail to boot (&quot;Failed to start Switch Root&quot;).</source>
        <translation>Impossible de créer /boot/archiso.img (le paquet « archiso » est‑il installé ?). Utilisation du initramfs classique — l’ISO générée pourrait ne pas démarrer (« Failed to start Switch Root »).</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="743"/>
        <source>Could not find an initramfs image to use.</source>
        <translation>Aucune image initramfs utilisable n’a été trouvée.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="772"/>
        <source>--grub-mbr option specified but boot/grub/i386-pc/eltorito.img is missing from iso-template</source>
        <translation>Option --grub-mbr spécifiée mais le fichier boot/grub/i386-pc/eltorito.img est absent du modèle ISO</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="780"/>
        <source>Could not copy the template initrd: </source>
        <translation>Impossible de copier l’initrd du modèle : </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="786"/>
        <source>Could not copy the kernel: </source>
        <translation>Impossible de copier le noyau : </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="794"/>
        <location filename="../src/work.cpp" line="859"/>
        <location filename="../src/work.cpp" line="943"/>
        <location filename="../src/work.cpp" line="962"/>
        <source>Could not create the checksum for %1.</source>
        <translation>Impossible de créer la somme de contrôle pour %1.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="802"/>
        <source>Could not create temp directory. </source>
        <translation>Impossible de créer le répertoire temporaire. </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="843"/>
        <source>Could not copy the kernel modules or programs into the initrd.</source>
        <translation>Impossible de copier les modules du noyau ou les programmes dans l’initrd.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="909"/>
        <source>Squashing filesystem...</source>
        <translation>Création du système de fichiers compressé « SquashFS »…</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="920"/>
        <source>Could not create linuxfs file, please check /var/log/%1.log</source>
        <translation>Impossible de créer un fichier linuxfs, veuillez vérifier /var/log/%1.log</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="935"/>
        <location filename="../src/work.cpp" line="954"/>
        <source>Could not move %1 to the ISO directory.</source>
        <translation>Impossible de déplacer %1 vers le dossier ISO.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1069"/>
        <source>Creating CD/DVD image file...</source>
        <translation>Création du fichier image pour CD/DVD…</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1079"/>
        <source>Could not create ISO file, please check whether you have enough space on the destination partition.</source>
        <translation>Impossible de créer le fichier ISO. Veuillez vérifier que l’espace sur la partition de destination est suffisant.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1089"/>
        <source>Making hybrid iso</source>
        <translation>Création d’une image ISO hybride</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1096"/>
        <source>Could not make the ISO hybrid; it would not boot correctly from USB.</source>
        <translation>Impossible de créer l’ISO hybride ; le démarrage depuis une clé USB risque de ne pas fonctionner correctement.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1109"/>
        <location filename="../src/work.cpp" line="1117"/>
        <source>Could not create the %1 checksum for the ISO.</source>
        <translation>Impossible de créer la somme de contrôle %1 pour l’ISO.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1130"/>
        <source>Success</source>
        <translation>Installation réussie</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1131"/>
        <source>MX Snapshot completed successfully!</source>
        <translation>Le processus de MX Snapshot s’est terminé avec succès !</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1132"/>
        <source>Snapshot took %1 to finish.</source>
        <translation>Le processus de création de l’instantané s’est terminé en %1.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1133"/>
        <source>Thanks for using MX Snapshot, run MX Live USB Maker next!</source>
        <translation>Merci d’utiliser MX Instantané - MX Snapshot, lancez ensuite MX Live USB Création !</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1148"/>
        <location filename="../src/work.cpp" line="1174"/>
        <source>Installing </source>
        <translation>Installation </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1163"/>
        <source>paru not found; cannot install %1 from the AUR.</source>
        <translation>paru est introuvable ; l’installation de %1 depuis l’AUR n’est pas possible.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1168"/>
        <source>Could not install %1; continuing without the installer.</source>
        <translation>Impossible d’installer %1 ; poursuite sans l’installateur.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1177"/>
        <source>Could not install </source>
        <translation>Installation impossible </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1187"/>
        <source>Calculating checksum...</source>
        <translation>Calcul de la somme de contrôle…</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1238"/>
        <source>Building new initrd...</source>
        <translation>Nouvel initrd en cours de création…</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1341"/>
        <source>Rebuilding initramfs with: mkinitcpio %1</source>
        <translation>Reconstruction de l’initramfs à l’aide de : mkinitcpio %1</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1468"/>
        <location filename="../src/work.cpp" line="1490"/>
        <source>Could not create the package list: </source>
        <translation>Impossible de créer la liste des paquets : </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1477"/>
        <source>Could not create working directory. </source>
        <translation>Impossible de créer le répertoire de travail. </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1530"/>
        <source>Could not prepare a safe bind-root overlay. Snapshot cannot continue.</source>
        <translation>Impossible de préparer un overlay bind-root sécurisé. La création de l’instantané (snapshot) ne peut pas se poursuivre.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1580"/>
        <location filename="../src/work.cpp" line="1604"/>
        <source>Could not prepare the snapshot bind-root environment.</source>
        <translation>Impossible de préparer l’environnement bind-root pour l’instantané (snapshot). </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1943"/>
        <source>Calculating total size of excluded files...</source>
        <translation>Calcul de la taille totale des fichiers exclus…</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1970"/>
        <source>Calculating size of root...</source>
        <translation>Calcul de la taille de root…</translation>
    </message>
</context>
</TS>