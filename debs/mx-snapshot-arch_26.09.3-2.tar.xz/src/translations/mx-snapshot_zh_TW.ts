<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="zh_TW">
<context>
    <name>Batchprocessing</name>
    <message>
        <location filename="../src/batchprocessing.cpp" line="53"/>
        <source>Error</source>
        <translation>錯誤</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="54"/>
        <source>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</source>
        <translation>當前內核不支持所選的壓縮算法，請編輯配置文件並選擇其他算法。</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="101"/>
        <source>The program will pause the build and open the boot menu in your text editor.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="114"/>
        <source>The boot-menu editor failed; the snapshot cannot continue with potentially unedited files.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="131"/>
        <source>Administrator access was not granted; the snapshot cannot continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="258"/>
        <source>Detected newer exclusion file at %1 compared to %2. Prompting for action.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="264"/>
        <source>s</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'show diff'</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="265"/>
        <source>u</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'use updated default'</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="266"/>
        <source>k</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'keep custom (update timestamp)'</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="267"/>
        <source>q</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'quit'</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="269"/>
        <source>show diff</source>
        <comment>CLI excludes prompt option label</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="270"/>
        <source>use updated default</source>
        <comment>CLI excludes prompt option label</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="271"/>
        <source>keep custom (update timestamp)</source>
        <comment>CLI excludes prompt option label</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="272"/>
        <source>quit</source>
        <comment>CLI excludes prompt option label</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="275"/>
        <source>[%1]%2  [%3]%4  [%5]%6  [%7]%8: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="280"/>
        <source>The exclusion file at %1 is newer than your configured file at %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="296"/>
        <source>Reverted to updated default exclusion file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="313"/>
        <source>No input available to answer the exclusion file prompt; aborting without creating a snapshot.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="316"/>
        <source>Leaving custom exclusion file unchanged.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="327"/>
        <source>Invalid choice. Please select again.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="121"/>
        <source>No elevation tool found (pkexec/gksu/sudo).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="212"/>
        <source>Failed to start command: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="283"/>
        <source>Administrator access was not granted (authentication cancelled or denied).</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <location filename="../src/mainwindow.cpp" line="396"/>
        <location filename="../src/mainwindow.cpp" line="944"/>
        <source>MX Snapshot</source>
        <translation>MX 快照</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="33"/>
        <source>Optional customization</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="65"/>
        <source>Release version:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="79"/>
        <source>Boot options:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="86"/>
        <source>Live kernel:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="93"/>
        <source>Project name:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="100"/>
        <source>Release date:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="107"/>
        <source>Release codename:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="133"/>
        <source>Current date</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="172"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Snapshot is a utility that creates a bootable image (ISO) of your working system that you can use for storage or distribution. You can continue working with undemanding applications while it is running.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;快照工具是為電腦正在運作的系統製作一份可開機映像檔（ISO），此檔案可以用來備份或流通。當它在執行的時候，你仍然可以繼續使用不太消耗資源的程式。&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="182"/>
        <source>Used space on / (root) and /home partitions:</source>
        <translation>/（根目錄）和 /home 磁碟區已使用的空間：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="192"/>
        <source>Location and ISO name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="219"/>
        <source>Snapshot location:</source>
        <translation>快照存放位置：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="226"/>
        <source>Select a different snapshot directory</source>
        <translation>將快照存放在別的目錄</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="236"/>
        <location filename="../src/mainwindow.cpp" line="644"/>
        <source>Snapshot name:</source>
        <translation>快照檔名：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="360"/>
        <source>Type of snapshot:</source>
        <translation>快照類型：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="367"/>
        <source>Preserving accounts (for personal backup)</source>
        <translation>保留帳密（個人備份用）</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This option will reset &amp;quot;demo&amp;quot; and &amp;quot;root&amp;quot; passwords to the MX Linux defaults and will not copy any personal accounts created.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;選擇此項，則會回復 MX Linux 預設的 demo 和 root 帳密，而不複製任何自訂的個人帳號資料。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="380"/>
        <source>Resetting accounts (for distribution to others)</source>
        <translation>重新設定帳密（公開流通用）</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="451"/>
        <source>You can also exclude certain directories by ticking the common choices below, or by clicking on the button to directly edit /etc/mx-snapshot-exclude.list.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="496"/>
        <source>sha512</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="519"/>
        <source>Throttle the I/O input rate by the given percentage.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="525"/>
        <source>I/O throttle:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="532"/>
        <source>Calculate checksums:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="539"/>
        <source>ISO compression scheme:</source>
        <translation>ISO 壓縮方案:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="546"/>
        <source>Number of CPU cores to use:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="553"/>
        <source>md5</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="563"/>
        <source>Options:</source>
        <translation>選項：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="610"/>
        <source>Edit Exclusion File</source>
        <translation>編輯排除檔</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="626"/>
        <location filename="../src/mainwindow.cpp" line="969"/>
        <source>Remove Custom Exclusion File</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="679"/>
        <source>Pictures</source>
        <translation>圖片</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="686"/>
        <source>Videos</source>
        <translation>影片</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="693"/>
        <source>All of the above</source>
        <translation>以上全選</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="700"/>
        <source>exclude network configurations</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="703"/>
        <source>Networks</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="710"/>
        <source>Downloads</source>
        <translation>所有下載</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="717"/>
        <source>Desktop</source>
        <translation>桌面</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="724"/>
        <source>Documents</source>
        <translation>文件</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="731"/>
        <source>Flatpaks</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="738"/>
        <source>Music</source>
        <translation>音樂</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="881"/>
        <source>About this application</source>
        <translation>關於本程式</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="884"/>
        <source>About...</source>
        <translation>關於……</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="890"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1005"/>
        <source>Next</source>
        <translation>下一個</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="906"/>
        <source>Display help </source>
        <translation>顯示說明</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="909"/>
        <source>Help</source>
        <translation>說明</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="915"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1030"/>
        <source>Quit application</source>
        <translation>退出程式</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1033"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1039"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="989"/>
        <source>Back</source>
        <translation>後退</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="358"/>
        <source>Select Release Date</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="402"/>
        <source>fastest, worst compression</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="402"/>
        <source>fast, worse compression</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="403"/>
        <source>slow, better compression</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="403"/>
        <source>best compromise</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="404"/>
        <source>slowest, best compression</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="433"/>
        <source>Free space on %1, where snapshot folder is placed: </source>
        <translation>快照目錄所在的 %1 尚可利用的空間：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="436"/>
        <source>The free space should be sufficient to hold the compressed data from / and /home

      If necessary, you can create more available space by removing previous snapshots and saved copies: %1 snapshots are taking up %2 of disk space.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="448"/>
        <location filename="../src/mainwindow.cpp" line="449"/>
        <source>Installing </source>
        <translation>正在安裝……</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="587"/>
        <source>Please wait.</source>
        <translation>請稍待。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="589"/>
        <source>Please wait. Calculating used disk space...</source>
        <translation>請稍待。正在計算佔用多少磁碟空間……</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="275"/>
        <location filename="../src/mainwindow.cpp" line="489"/>
        <location filename="../src/mainwindow.cpp" line="623"/>
        <location filename="../src/mainwindow.cpp" line="630"/>
        <location filename="../src/mainwindow.cpp" line="712"/>
        <location filename="../src/mainwindow.cpp" line="723"/>
        <location filename="../src/mainwindow.cpp" line="748"/>
        <location filename="../src/mainwindow.cpp" line="1034"/>
        <source>Error</source>
        <translation>錯誤</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="175"/>
        <location filename="../src/mainwindow.cpp" line="211"/>
        <source>Updated Exclusion List</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="178"/>
        <source>The exclusion file at %1 is newer than your configured file at %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="180"/>
        <source>Review the changes below. Keep your custom file or replace it with the updated default.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="186"/>
        <source>Show Differences</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="192"/>
        <source>Keep Custom</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="198"/>
        <source>Use Updated Default</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="490"/>
        <source>Administrator access was not granted; the snapshot cannot continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="522"/>
        <source>Done</source>
        <translation>完成</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="624"/>
        <source>Output file %1 already exists. Please use another file name, or delete the existent file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="631"/>
        <source>Insufficient free space. Please select a different snapshot directory or free up space.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="635"/>
        <source>Settings</source>
        <translation>設定</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="641"/>
        <source>Snapshot will use the following settings:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="643"/>
        <source>- Snapshot directory:</source>
        <translation>- 快照存放目錄：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="644"/>
        <source>- Kernel to be used:</source>
        <translation>- 使用核心：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="668"/>
        <location filename="../src/mainwindow.cpp" line="677"/>
        <source>NVIDIA Detected</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="669"/>
        <source>This computer uses an NVIDIA graphics card. Are you planning to use the resulting ISO on the same computer or another computer with an NVIDIA card?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="673"/>
        <source>NVIDIA Selected</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="674"/>
        <source>Note: If you use the resulting ISO on a computer without an NVIDIA card, you will likely need to remove &apos;xorg=nvidia&apos; from the boot options.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="678"/>
        <source>Note: If you use the resulting ISO on a computer with an NVIDIA card, you may need to add &apos;xorg=nvidia&apos; to the boot options.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="276"/>
        <location filename="../src/mainwindow.cpp" line="713"/>
        <source>Could not replace the exclusion file with the updated default.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="724"/>
        <source>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</source>
        <translation>當前內核不支持所選的壓縮算法，請編輯配置文件並選擇其他算法。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="744"/>
        <source>Cancelled</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="745"/>
        <source>Administrator access is required to create a snapshot.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="746"/>
        <source>The operation was cancelled. Select Next when you are ready to try again.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="749"/>
        <source>Could not create the snapshot or work directory.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="762"/>
        <source>Final chance</source>
        <translation>最後確認</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="764"/>
        <source>Snapshot now has all the information it needs to create an ISO from your running system.</source>
        <translation>快照工具已經掌握了所有相關資料，可以從現在運行的系統中創造出 ISO 檔。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="765"/>
        <source>It will take some time to finish, depending on the size of the installed system and the capacity of your computer.</source>
        <translation>要花上一些時間才能完成，實際狀況取決於現行系統大小以及電腦性能。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="767"/>
        <source>OK to start?</source>
        <translation>可以開始嗎？</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="824"/>
        <location filename="../src/mainwindow.cpp" line="771"/>
        <source>Shutdown computer when done.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="805"/>
        <source>Output</source>
        <translation>輸出</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="849"/>
        <source>Close</source>
        <translation>關閉</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="924"/>
        <source>Edit Boot Menu</source>
        <translation>編輯開機選單</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="925"/>
        <source>The program will now pause to allow you to edit any files in the work directory. Select Yes to edit the boot menu or select No to bypass this step and continue creating the snapshot.</source>
        <translation>本程式即將暫停，讓你有機會編修工作目錄之中的每個檔案。選擇「是」便可編輯開機選單，選擇「否」 則會省略此一步驟，直接製作快照。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="970"/>
        <source>Revert the exclusion list to the default file? This will overwrite your current exclusions.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1002"/>
        <source>About %1</source>
        <translation>大約 %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1004"/>
        <source>Version: </source>
        <translation>版本：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1005"/>
        <source>Program for creating a live-CD from the running system for MX Linux</source>
        <translation>本程式可將正在運作的 MX Linux 系統做成現場版 CD</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1007"/>
        <source>Copyright (c) MX Linux</source>
        <translation>版權所有 (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1009"/>
        <source>%1 License</source>
        <translation>%1 許可</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1022"/>
        <source>%1 Help</source>
        <translation>%1 幫助</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1027"/>
        <source>Select Snapshot Directory</source>
        <translation>選擇快照目錄</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1035"/>
        <source>Insufficient free space in the selected directory. Please choose a different location.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1079"/>
        <source>Confirmation</source>
        <translation>確認</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1079"/>
        <source>Are you sure you want to quit the application?</source>
        <translation>真的要退出此程式嗎？</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/main.cpp" line="109"/>
        <source>Tool used for creating a live-CD from the running system</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>Use CLI only</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="117"/>
        <source>Number of CPU cores to be used.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="118"/>
        <source>Output directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="119"/>
        <source>Output filename</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="121"/>
        <source>Name a different kernel to use other than the default running kernel, use format returned by &apos;uname -r&apos;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="123"/>
        <source>Or the full path: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="126"/>
        <source>Compression level options.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="127"/>
        <source>Use quotes: &quot;-Xcompression-level &lt;level&gt;&quot;, or &quot;-Xalgorithm &lt;algorithm&gt;&quot;, or &quot;-Xhc&quot;, see mksquashfs man page</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="131"/>
        <source>Create a monthly snapshot, add &apos;Month&apos; name in the ISO name, skip used space calculation</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="132"/>
        <source>This option sets reset-accounts and compression to defaults, arguments changing those items will be ignored</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="134"/>
        <source>Optionally specify a suffix to add to the month name (e.g., &apos;1&apos; for &apos;July.1&apos;)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="135"/>
        <source>Don&apos;t calculate checksums for resulting ISO file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="136"/>
        <source>Skip calculating free space to see if the resulting ISO will fit</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="137"/>
        <source>Option to fix issue with calculating checksums on preempt_rt kernels</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="138"/>
        <source>Resetting accounts (for distribution to others)</source>
        <translation>重新設定帳密（公開流通用）</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="139"/>
        <source>Calculate checksums for resulting ISO file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="141"/>
        <source>Throttle the I/O input rate by the given percentage. This can be used to reduce the I/O and CPU consumption of Mksquashfs.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="144"/>
        <source>Work directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="146"/>
        <source>Exclude main folders, valid choices: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="148"/>
        <source>Use the option one time for each item you want to exclude</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="151"/>
        <source>Compression format, valid choices: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="153"/>
        <source>Shutdown computer when done.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="154"/>
        <source>Use grub for legacy mbr iso boot instead of isolinux/syslinux.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="155"/>
        <source>Add the &apos;xorg=nvidia&apos; boot option to the ISO (for booting on a system with an NVIDIA card).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="163"/>
        <source>Optional suffix for a monthly snapshot; only valid together with --month.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="196"/>
        <source>A single suffix positional argument is only valid together with --month.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="255"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>您似乎是以 root 身份登錄，請登出並以一般使用者身份登錄以使用此程式。</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="270"/>
        <source>version:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="266"/>
        <source>You must run this program with sudo or pkexec.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="235"/>
        <source>MX Snapshot</source>
        <translation>MX 快照</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="257"/>
        <location filename="../src/main.cpp" line="343"/>
        <location filename="../src/settings.cpp" line="770"/>
        <location filename="../src/settings.cpp" line="779"/>
        <location filename="../src/settings.cpp" line="1396"/>
        <location filename="../src/settings.cpp" line="1506"/>
        <source>Error</source>
        <translation>錯誤</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="300"/>
        <source>Fatal error:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="302"/>
        <source>Fatal error: unknown exception</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="342"/>
        <location filename="../src/settings.cpp" line="778"/>
        <source>Current kernel doesn&apos;t support Squashfs, cannot continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="261"/>
        <source>Exception during initialization: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="216"/>
        <source>Pending Arch bind-root cleanup state but installed-to-live-arch is missing: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="264"/>
        <source>Unknown exception during initialization</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="299"/>
        <source>Could not create work directory. </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="382"/>
        <source>No suitable filesystem found for the temp directory. Tried /tmp, /home, and the snapshot directory.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="393"/>
        <source>Could not create temp directory:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="394"/>
        <source>Please check that the parent directory exists and is writable:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="412"/>
        <source>Compression format &apos;%1&apos; is not supported by the current kernel</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="418"/>
        <source>Invalid cores setting: %1. Must be between 1 and %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="427"/>
        <source>Invalid throttle setting: %1. Must be between 0 and 99</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="433"/>
        <source>Snapshot directory cannot be empty</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="441"/>
        <source>Snapshot name cannot be empty</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="447"/>
        <source>Snapshot name contains invalid characters: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="453"/>
        <source>Kernel version cannot be empty</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="458"/>
        <source>Kernel file not found: /boot/vmlinuz-%1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="465"/>
        <source>Kernel %1 doesn&apos;t support Squashfs</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="496"/>
        <source>Exclusion file does not exist: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="505"/>
        <source>Unbalanced quotes in exclusion list</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="530"/>
        <source>Insufficient free space: %1 KiB available, minimum %2 KiB required</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="537"/>
        <source>Insufficient free space in work directory: %1 KiB available, minimum %2 KiB required</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="552"/>
        <source>Failed to determine number of CPU cores</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="558"/>
        <source>Configuration file does not exist: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="559"/>
        <source>Using default settings</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="561"/>
        <source>Cannot read configuration file: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="562"/>
        <source>Error: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="572"/>
        <source>Required tool not found: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="581"/>
        <source>Required directory not found: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="600"/>
        <source>Initialization Error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="601"/>
        <source>Failed to initialize application settings:

%1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="768"/>
        <source>Could not find a usable kernel</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="769"/>
        <source>Searched for kernel files in /boot/ but none were found or accessible.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="791"/>
        <source>No users found in the system</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="794"/>
        <source>Failed to determine system information</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="964"/>
        <source>Used space on / (root): </source>
        <translation>/（根目錄）使用的空間：</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="980"/>
        <source>estimated</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="987"/>
        <source>Used space on /home: </source>
        <translation>/home 使用的空間：</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1048"/>
        <source>Free space on %1, where snapshot folder is placed: </source>
        <translation>快照目錄所在的 %1 尚可利用的空間：</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1052"/>
        <source>The free space should be sufficient to hold the compressed data from / and /home

      If necessary, you can create more available space
      by removing previous snapshots and saved copies:
      %1 snapshots are taking up %2 of disk space.
</source>
        <translation>所餘空間當足以存放 / 和 /home 的壓縮資料

      若有必要，可以移除早先的快照，以換取更多空間：
      目前有 %1 組快照，使用了 %2 磁碟空間。
</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1199"/>
        <source>Error reading system configuration file: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1208"/>
        <source>Error accessing user configuration</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1260"/>
        <source>Could not copy exclusion file from %1 to %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1283"/>
        <source>Unsupported compression &apos;%1&apos; in configuration, using zstd.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1293"/>
        <source>Invalid stored cores setting (%1). Using detected CPU count: %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1303"/>
        <source>Invalid stored throttle setting (%1). Using 0.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1394"/>
        <location filename="../src/settings.cpp" line="1504"/>
        <source>Output file %1 already exists. Please use another file name, or delete the existent file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="73"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>License</source>
        <translation>授權條款</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <location filename="../src/about.cpp" line="107"/>
        <source>Changelog</source>
        <translation>變更紀錄</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="98"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="119"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="53"/>
        <location filename="../src/about.cpp" line="122"/>
        <source>&amp;Close</source>
        <translation>關閉（&amp;C）</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="78"/>
        <source>No diff output available.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="91"/>
        <source>Could not open default exclusion file at %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="97"/>
        <source>Could not create exclusion file directory at %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="106"/>
        <source>Could not prepare exclusion file at %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="123"/>
        <source>Could not read default exclusion file at %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="131"/>
        <source>Could not write exclusion file at %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="113"/>
        <source>Could not backup existing exclusion file to %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="139"/>
        <source>Could not copy default exclusion file from %1 to %2.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Work</name>
    <message>
        <location filename="../src/work.cpp" line="312"/>
        <source>Cleaning...</source>
        <translation>清理打掃……</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="343"/>
        <location filename="../src/work.cpp" line="1125"/>
        <source>Done</source>
        <translation>完成</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="357"/>
        <source>Interrupted or failed to complete</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="368"/>
        <location filename="../src/work.cpp" line="425"/>
        <location filename="../src/work.cpp" line="629"/>
        <location filename="../src/work.cpp" line="637"/>
        <location filename="../src/work.cpp" line="672"/>
        <location filename="../src/work.cpp" line="715"/>
        <location filename="../src/work.cpp" line="743"/>
        <location filename="../src/work.cpp" line="757"/>
        <location filename="../src/work.cpp" line="771"/>
        <location filename="../src/work.cpp" line="779"/>
        <location filename="../src/work.cpp" line="785"/>
        <location filename="../src/work.cpp" line="793"/>
        <location filename="../src/work.cpp" line="842"/>
        <location filename="../src/work.cpp" line="858"/>
        <location filename="../src/work.cpp" line="919"/>
        <location filename="../src/work.cpp" line="934"/>
        <location filename="../src/work.cpp" line="942"/>
        <location filename="../src/work.cpp" line="953"/>
        <location filename="../src/work.cpp" line="961"/>
        <location filename="../src/work.cpp" line="1078"/>
        <location filename="../src/work.cpp" line="1095"/>
        <location filename="../src/work.cpp" line="1108"/>
        <location filename="../src/work.cpp" line="1116"/>
        <location filename="../src/work.cpp" line="1177"/>
        <location filename="../src/work.cpp" line="1468"/>
        <location filename="../src/work.cpp" line="1476"/>
        <location filename="../src/work.cpp" line="1490"/>
        <location filename="../src/work.cpp" line="1529"/>
        <location filename="../src/work.cpp" line="1579"/>
        <location filename="../src/work.cpp" line="1603"/>
        <source>Error</source>
        <translation>錯誤</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="369"/>
        <source>Administrator access was not granted; the snapshot cannot continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="426"/>
        <source>There&apos;s not enough free space on your target disk, you need at least %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="429"/>
        <source>You have %1 free space on %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="432"/>
        <source>If you are sure you have enough free space rerun the program with -o/--override-size option</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="610"/>
        <source>Copying the new-iso filesystem...</source>
        <translation>正在複製 new-iso 檔案系統……</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="629"/>
        <source>ISO template not found: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="637"/>
        <location filename="../src/work.cpp" line="757"/>
        <source>Could not extract the ISO template: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="665"/>
        <source>Arch ISO template is missing boot/ or efi/ directories.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="668"/>
        <source>Detected boot/ or efi/ under the work directory root; the template may have been extracted to the wrong location.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="671"/>
        <source>Template: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="707"/>
        <source>Stale archiso initramfs detected, rebuilding...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="709"/>
        <source>Found /boot/archiso.img built for kernel %1, but the selected kernel is %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="713"/>
        <source>Rebuilding /boot/archiso.img failed. Please rebuild it manually or remove the stale file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="725"/>
        <source>No /boot/archiso.img found, attempting to create one...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="730"/>
        <location filename="../src/work.cpp" line="1167"/>
        <source>Warning</source>
        <translation>注意</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="731"/>
        <source>Could not create /boot/archiso.img (is the &apos;archiso&apos; package installed?). Falling back to the regular initramfs — the resulting ISO will likely fail to boot (&quot;Failed to start Switch Root&quot;).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="743"/>
        <source>Could not find an initramfs image to use.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="772"/>
        <source>--grub-mbr option specified but boot/grub/i386-pc/eltorito.img is missing from iso-template</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="780"/>
        <source>Could not copy the template initrd: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="786"/>
        <source>Could not copy the kernel: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="794"/>
        <location filename="../src/work.cpp" line="859"/>
        <location filename="../src/work.cpp" line="943"/>
        <location filename="../src/work.cpp" line="962"/>
        <source>Could not create the checksum for %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="802"/>
        <source>Could not create temp directory. </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="843"/>
        <source>Could not copy the kernel modules or programs into the initrd.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="909"/>
        <source>Squashing filesystem...</source>
        <translation>正在壓縮檔案系統……</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="920"/>
        <source>Could not create linuxfs file, please check /var/log/%1.log</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="935"/>
        <location filename="../src/work.cpp" line="954"/>
        <source>Could not move %1 to the ISO directory.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1069"/>
        <source>Creating CD/DVD image file...</source>
        <translation>正在創造 CD/DVD 映像檔……</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1079"/>
        <source>Could not create ISO file, please check whether you have enough space on the destination partition.</source>
        <translation>無法製作 ISO 檔，請檢查目的地磁碟區是否還有足夠的空間。</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1089"/>
        <source>Making hybrid iso</source>
        <translation>正在作混合式 iso</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1096"/>
        <source>Could not make the ISO hybrid; it would not boot correctly from USB.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1109"/>
        <location filename="../src/work.cpp" line="1117"/>
        <source>Could not create the %1 checksum for the ISO.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1130"/>
        <source>Success</source>
        <translation>成功</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1131"/>
        <source>MX Snapshot completed successfully!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1132"/>
        <source>Snapshot took %1 to finish.</source>
        <translation>快照已完成 %1 。</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1133"/>
        <source>Thanks for using MX Snapshot, run MX Live USB Maker next!</source>
        <translation>感謝您使用MX 快照，接下來運行MX Live USB Maker！</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1148"/>
        <location filename="../src/work.cpp" line="1174"/>
        <source>Installing </source>
        <translation>正在安裝……</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1163"/>
        <source>paru not found; cannot install %1 from the AUR.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1168"/>
        <source>Could not install %1; continuing without the installer.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1177"/>
        <source>Could not install </source>
        <translation>無法安裝</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1187"/>
        <source>Calculating checksum...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1238"/>
        <source>Building new initrd...</source>
        <translation>建立新 initrd...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1341"/>
        <source>Rebuilding initramfs with: mkinitcpio %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1468"/>
        <location filename="../src/work.cpp" line="1490"/>
        <source>Could not create the package list: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1477"/>
        <source>Could not create working directory. </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1530"/>
        <source>Could not prepare a safe bind-root overlay. Snapshot cannot continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1580"/>
        <location filename="../src/work.cpp" line="1604"/>
        <source>Could not prepare the snapshot bind-root environment.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1943"/>
        <source>Calculating total size of excluded files...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1970"/>
        <source>Calculating size of root...</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>