<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="es">
<context>
    <name>Batchprocessing</name>
    <message>
        <location filename="../src/batchprocessing.cpp" line="54"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="55"/>
        <source>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</source>
        <translation>El kernel actual no admite el algoritmo de compresión seleccionado, por favor edite el archivo de configuración y seleccione un algoritmo diferente.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="80"/>
        <source>The program will pause the build and open the boot menu in your text editor.</source>
        <translation>El programa pausará la construcción y abrirá el menú de inicio en su editor de texto.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="162"/>
        <source>No diff output available.</source>
        <translation>No hay salida diff disponible.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="200"/>
        <source>Default exclusion file not found at %1.</source>
        <translation>No se ha encontrado el archivo de exclusión por defecto en %1.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="212"/>
        <source>Could not backup existing exclusion file to %1.</source>
        <translation>No se pudo hacer una copia de seguridad del archivo de exclusión existente en %1.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="215"/>
        <source>Could not remove existing exclusion file at %1.</source>
        <translation>No se pudo eliminar el archivo de exclusión existente en %1.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="222"/>
        <source>Could not copy default exclusion file from %1 to %2.</source>
        <translation>No se pudo copiar el archivo de exclusión por defecto de %1 a %2.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="238"/>
        <source>Detected newer exclusion file at %1 compared to %2. Prompting for action.</source>
        <translation>Se ha detectado un archivo de exclusión más reciente en %1 en comparación con %2. Se solicita una acción.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="244"/>
        <source>s</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'show diff'</comment>
        <translation>s</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="245"/>
        <source>u</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'use updated default'</comment>
        <translation>u</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="246"/>
        <source>k</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'keep custom (update timestamp)'</comment>
        <translation>k</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="247"/>
        <source>q</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'quit'</comment>
        <translation>q</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="249"/>
        <source>show diff</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>Mostrar diferencias</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="250"/>
        <source>use updated default</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>usar actualizado por defecto</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="251"/>
        <source>keep custom (update timestamp)</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>mantener la personalización (actualizar la marca de tiempo)</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="252"/>
        <source>quit</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>terminar</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="255"/>
        <source>[%1]%2  [%3]%4  [%5]%6  [%7]%8: </source>
        <translation>[%1]%2  [%3]%4  [%5]%6  [%7]%8: </translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="260"/>
        <source>The exclusion file at %1 is newer than your configured file at %2.</source>
        <translation>El archivo de exclusión en %1 es más reciente que el archivo configurado en %2.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="276"/>
        <source>Reverted to updated default exclusion file.</source>
        <translation>Se ha vuelto al archivo de exclusión por defecto actualizado.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="297"/>
        <source>Leaving custom exclusion file unchanged.</source>
        <translation>Dejar el archivo de exclusión personalizado sin cambios.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="308"/>
        <source>Invalid choice. Please select again.</source>
        <translation>Selección no válida. Vuelva a seleccionar.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="315"/>
        <source>This computer uses an NVIDIA graphics card. Are you planning to use the resulting ISO on the same computer or another computer with an NVIDIA card?</source>
        <translation>Este ordenador utiliza una tarjeta gráfica NVIDIA. ¿Planea utilizar la ISO resultante en el mismo ordenador o en otro ordenador con una tarjeta NVIDIA?</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="325"/>
        <source>Note: If you use the resulting ISO on a computer without an NVIDIA card, you will likely need to remove &apos;xorg=nvidia&apos; from the boot options.</source>
        <translation>Nota: Si utiliza la ISO resultante en un ordenador sin tarjeta NVIDIA, es probable que tenga que eliminar &apos;xorg=nvidia&apos; de las opciones de arranque.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="328"/>
        <source>Note: If you use the resulting ISO on a computer with an NVIDIA card, you may need to add &apos;xorg=nvidia&apos; to the boot options.</source>
        <translation>Nota: Si utiliza la ISO resultante en un ordenador con una tarjeta NVIDIA, puede que necesite añadir &apos;xorg=nvidia&apos; a las opciones de arranque.</translation>
    </message>
</context>
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="101"/>
        <source>No elevation tool found (pkexec/gksu/sudo).</source>
        <translation>No se ha encontrado ninguna herramienta de elevación de privilegios (pkexec/gksu/sudo).</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="171"/>
        <source>Administrator Access Required</source>
        <translation>Se requiere acceso de administrador</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="172"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation>Esta operación requiere privilegios de administrador. Reinicia la aplicación e ingresa tu contraseña cuando se te solicite.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <location filename="../src/mainwindow.cpp" line="446"/>
        <location filename="../src/mainwindow.cpp" line="833"/>
        <location filename="../src/ui_mainwindow.h" line="745"/>
        <source>MX Snapshot</source>
        <translation>MX Snapshot</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="33"/>
        <location filename="../src/ui_mainwindow.h" line="746"/>
        <source>Optional customization</source>
        <translation>Personalización opcional</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="65"/>
        <location filename="../src/ui_mainwindow.h" line="747"/>
        <source>Release version:</source>
        <translation>Versión del lanzamiento:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="79"/>
        <location filename="../src/ui_mainwindow.h" line="748"/>
        <source>Boot options:</source>
        <translation>Opciones de arranque:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="86"/>
        <location filename="../src/ui_mainwindow.h" line="749"/>
        <source>Live kernel:</source>
        <translation>Kernel live:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="93"/>
        <location filename="../src/ui_mainwindow.h" line="750"/>
        <source>Project name:</source>
        <translation>Nombre del proyecto:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="100"/>
        <location filename="../src/ui_mainwindow.h" line="751"/>
        <source>Release date:</source>
        <translation>Fecha de lanzamiento:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="107"/>
        <location filename="../src/ui_mainwindow.h" line="752"/>
        <source>Release codename:</source>
        <translation>Nombre clave del lanzamiento:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="133"/>
        <location filename="../src/ui_mainwindow.h" line="753"/>
        <source>Current date</source>
        <translation>Fecha actual</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="172"/>
        <location filename="../src/ui_mainwindow.h" line="754"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Snapshot is a utility that creates a bootable image (ISO) of your working system that you can use for storage or distribution. You can continue working with undemanding applications while it is running.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Snapshot es una utilidad que crea una imagen ISO iniciable de su sistema para que sea usada como almacenamiento o distribución. Puede continuar trabajando con aplicaciones ligeras mientras el programa se ejecuta.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="182"/>
        <location filename="../src/ui_mainwindow.h" line="755"/>
        <source>Used space on / (root) and /home partitions:</source>
        <translation>Espacio usado en las particiones / (root) y /home:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="192"/>
        <location filename="../src/ui_mainwindow.h" line="756"/>
        <source>Location and ISO name</source>
        <translation>Ubicación y nombre ISO</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="219"/>
        <location filename="../src/ui_mainwindow.h" line="758"/>
        <source>Snapshot location:</source>
        <translation>Ubicación de la imagen:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="226"/>
        <location filename="../src/ui_mainwindow.h" line="759"/>
        <source>Select a different snapshot directory</source>
        <translation>Por favor seleccione un medio diferente</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="236"/>
        <location filename="../src/mainwindow.cpp" line="641"/>
        <location filename="../src/ui_mainwindow.h" line="760"/>
        <source>Snapshot name:</source>
        <translation>Nombre de la imagen:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="360"/>
        <location filename="../src/ui_mainwindow.h" line="764"/>
        <source>Type of snapshot:</source>
        <translation>Tipo de imagen del sistema:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="367"/>
        <location filename="../src/ui_mainwindow.h" line="765"/>
        <source>Preserving accounts (for personal backup)</source>
        <translation>Cuentas preservadas (para el respaldo personal)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <location filename="../src/ui_mainwindow.h" line="767"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This option will reset &amp;quot;demo&amp;quot; and &amp;quot;root&amp;quot; passwords to the MX Linux defaults and will not copy any personal accounts created.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Esta opción restablecerá las contraseñas de &quot;demo&quot; y &quot;root&quot; a las incluidas por defecto en MX Linux y no copiará ninguna cuenta personal creada.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="380"/>
        <location filename="../src/ui_mainwindow.h" line="769"/>
        <source>Resetting accounts (for distribution to others)</source>
        <translation>Cuentas por defecto restablecidas (para distribuir a otros)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="451"/>
        <location filename="../src/ui_mainwindow.h" line="770"/>
        <source>You can also exclude certain directories by ticking the common choices below, or by clicking on the button to directly edit /etc/mx-snapshot-exclude.list.</source>
        <translation>También puede excluir ciertos directorios marcando las opciones comunes abajo o haciendo clic en el botón para editar directamente /usr/lib/mx-snapshot/snapshot-exclude.list.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="496"/>
        <location filename="../src/ui_mainwindow.h" line="771"/>
        <source>sha512</source>
        <translation>sha512</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="519"/>
        <location filename="../src/ui_mainwindow.h" line="773"/>
        <source>Throttle the I/O input rate by the given percentage.</source>
        <translation>Regula la tasa de entrada de E/S en el porcentaje dado.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="525"/>
        <location filename="../src/ui_mainwindow.h" line="775"/>
        <source>I/O throttle:</source>
        <translation>Regulador de E/S:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="532"/>
        <location filename="../src/ui_mainwindow.h" line="776"/>
        <source>Calculate checksums:</source>
        <translation>Calcular sumas de verificación:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="539"/>
        <location filename="../src/ui_mainwindow.h" line="777"/>
        <source>ISO compression scheme:</source>
        <translation>Esquema de compresión ISO:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="546"/>
        <location filename="../src/ui_mainwindow.h" line="778"/>
        <source>Number of CPU cores to use:</source>
        <translation>Número de núcleos de CPU utilizables:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="553"/>
        <location filename="../src/ui_mainwindow.h" line="779"/>
        <source>md5</source>
        <translation>md5</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="563"/>
        <location filename="../src/ui_mainwindow.h" line="780"/>
        <source>Options:</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="610"/>
        <location filename="../src/ui_mainwindow.h" line="781"/>
        <source>Edit Exclusion File</source>
        <translation>Editar archivo de exclusión</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="626"/>
        <location filename="../src/mainwindow.cpp" line="853"/>
        <location filename="../src/ui_mainwindow.h" line="782"/>
        <source>Remove Custom Exclusion File</source>
        <translation>Eliminar archivo de exclusión personalizado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="679"/>
        <location filename="../src/ui_mainwindow.h" line="783"/>
        <source>Pictures</source>
        <translation>Imágenes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="686"/>
        <location filename="../src/ui_mainwindow.h" line="784"/>
        <source>Videos</source>
        <translation>Videos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="693"/>
        <location filename="../src/ui_mainwindow.h" line="785"/>
        <source>All of the above</source>
        <translation>Todos los anteriores</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="700"/>
        <location filename="../src/ui_mainwindow.h" line="787"/>
        <source>exclude network configurations</source>
        <translation>excluir configuraciones de red</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="703"/>
        <location filename="../src/ui_mainwindow.h" line="789"/>
        <source>Networks</source>
        <translation>Redes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="710"/>
        <location filename="../src/ui_mainwindow.h" line="790"/>
        <source>Downloads</source>
        <translation>Descargas</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="717"/>
        <location filename="../src/ui_mainwindow.h" line="791"/>
        <source>Desktop</source>
        <translation>Escritorio</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="724"/>
        <location filename="../src/ui_mainwindow.h" line="792"/>
        <source>Documents</source>
        <translation>Documentos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="731"/>
        <location filename="../src/ui_mainwindow.h" line="793"/>
        <source>Flatpaks</source>
        <translation>Flatpaks</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="738"/>
        <location filename="../src/ui_mainwindow.h" line="794"/>
        <source>Music</source>
        <translation>Música</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="850"/>
        <location filename="../src/ui_mainwindow.h" line="797"/>
        <source>About this application</source>
        <translation>Acerca de esta aplicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="853"/>
        <location filename="../src/ui_mainwindow.h" line="799"/>
        <source>About...</source>
        <translation>Acerca de...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="859"/>
        <location filename="../src/ui_mainwindow.h" line="801"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="875"/>
        <location filename="../src/ui_mainwindow.h" line="803"/>
        <source>Next</source>
        <translation>Siguiente</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="900"/>
        <location filename="../src/ui_mainwindow.h" line="808"/>
        <source>Display help </source>
        <translation>Mostrar la ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="903"/>
        <location filename="../src/ui_mainwindow.h" line="810"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="909"/>
        <location filename="../src/ui_mainwindow.h" line="812"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="922"/>
        <location filename="../src/ui_mainwindow.h" line="815"/>
        <source>Quit application</source>
        <translation>Terminar aplicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="925"/>
        <location filename="../src/ui_mainwindow.h" line="817"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="931"/>
        <location filename="../src/ui_mainwindow.h" line="819"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="985"/>
        <location filename="../src/ui_mainwindow.h" line="822"/>
        <source>Back</source>
        <translation>Volver</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="408"/>
        <source>Select Release Date</source>
        <translation>Seleccione la fecha de publicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="452"/>
        <source>fastest, worst compression</source>
        <translation>más rápida, la peor compresión</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="452"/>
        <source>fast, worse compression</source>
        <translation>rápida, peor compresión</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="453"/>
        <source>slow, better compression</source>
        <translation>lenta, mejor compresión</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="453"/>
        <source>best compromise</source>
        <translation>mejor compromiso</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="454"/>
        <source>slowest, best compression</source>
        <translation> más lento, la mejor compresión</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="483"/>
        <source>Free space on %1, where snapshot folder is placed: </source>
        <translation>Espacio libre en %1, donde se colocará la imagen del sistema: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="486"/>
        <source>The free space should be sufficient to hold the compressed data from / and /home

      If necessary, you can create more available space by removing previous snapshots and saved copies: %1 snapshots are taking up %2 of disk space.</source>
        <translation>El espacio libre debe ser suficiente para contener los datos comprimidos de / y /home

      Si es necesario, puede crear más espacio disponible eliminando instantáneas anteriores y copias guardadas: %1 instantáneas están ocupando %2 de espacio en disco.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="498"/>
        <location filename="../src/mainwindow.cpp" line="499"/>
        <source>Installing </source>
        <translation>Instalando</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="584"/>
        <source>Please wait.</source>
        <translation>Espere por favor.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="586"/>
        <source>Please wait. Calculating used disk space...</source>
        <translation>Espere por favor. Calculando el espacio usado en el disco...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="313"/>
        <location filename="../src/mainwindow.cpp" line="330"/>
        <location filename="../src/mainwindow.cpp" line="337"/>
        <location filename="../src/mainwindow.cpp" line="620"/>
        <location filename="../src/mainwindow.cpp" line="627"/>
        <location filename="../src/mainwindow.cpp" line="709"/>
        <location filename="../src/mainwindow.cpp" line="728"/>
        <location filename="../src/mainwindow.cpp" line="966"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="177"/>
        <source>No diff output available.</source>
        <translation>No hay salida diff disponible.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="210"/>
        <location filename="../src/mainwindow.cpp" line="246"/>
        <source>Updated Exclusion List</source>
        <translation>Lista de exclusión actualizada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="213"/>
        <source>The exclusion file at %1 is newer than your configured file at %2.</source>
        <translation>El archivo de exclusión en %1 es más reciente que el archivo configurado en %2.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="215"/>
        <source>Review the changes below. Keep your custom file or replace it with the updated default.</source>
        <translation>Revise los cambios a continuación. Conserve su archivo personalizado o sustitúyalo por el predeterminado actualizado.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="221"/>
        <source>Show Differences</source>
        <translation>Mostrar diferencias</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="227"/>
        <source>Keep Custom</source>
        <translation>Mantener personalización</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="233"/>
        <source>Use Updated Default</source>
        <translation>Usar actualizado por defecto</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="314"/>
        <source>Default exclusion file not found at %1.</source>
        <translation>No se ha encontrado el archivo de exclusión por defecto en %1.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="326"/>
        <source>Warning</source>
        <translation>Advertencia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="327"/>
        <source>Could not backup existing exclusion file to %1.</source>
        <translation>No se pudo hacer una copia de seguridad del archivo de exclusión existente en %1.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="331"/>
        <source>Could not remove existing exclusion file at %1.</source>
        <translation>No se pudo eliminar el archivo de exclusión existente en %1.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="338"/>
        <source>Could not copy default exclusion file from %1 to %2.</source>
        <translation>No se pudo copiar el archivo de exclusión por defecto de %1 a %2.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="621"/>
        <source>Output file %1 already exists. Please use another file name, or delete the existent file.</source>
        <translation>El archivo de salida %1 ya existe. Utilice otro nombre de archivo o elimine el archivo existente.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="628"/>
        <source>Insufficient free space. Please select a different snapshot directory or free up space.</source>
        <translation>Espacio libre insuficiente. Seleccione un directorio de instantáneas diferente o libere espacio.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="632"/>
        <source>Settings</source>
        <translation>Configuración</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="638"/>
        <source>Snapshot will use the following settings:</source>
        <translation>La imagen utilizará la siguiente configuración:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="640"/>
        <source>- Snapshot directory:</source>
        <translation>- Directorio de la imagen:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="641"/>
        <source>- Kernel to be used:</source>
        <translation>- Kernel a usarse:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="665"/>
        <location filename="../src/mainwindow.cpp" line="674"/>
        <source>NVIDIA Detected</source>
        <translation>NVIDIA detectada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="666"/>
        <source>This computer uses an NVIDIA graphics card. Are you planning to use the resulting ISO on the same computer or another computer with an NVIDIA card?</source>
        <translation>Este ordenador utiliza una tarjeta gráfica NVIDIA. ¿Planea utilizar la ISO resultante en el mismo ordenador o en otro ordenador con una tarjeta NVIDIA?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="670"/>
        <source>NVIDIA Selected</source>
        <translation>NVIDIA seleccionada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="671"/>
        <source>Note: If you use the resulting ISO on a computer without an NVIDIA card, you will likely need to remove &apos;xorg=nvidia&apos; from the boot options.</source>
        <translation>Nota: Si utiliza la ISO resultante en un ordenador sin tarjeta NVIDIA, es probable que tenga que eliminar &apos;xorg=nvidia&apos; de las opciones de arranque.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="675"/>
        <source>Note: If you use the resulting ISO on a computer with an NVIDIA card, you may need to add &apos;xorg=nvidia&apos; to the boot options.</source>
        <translation>Nota: Si utiliza la ISO resultante en un ordenador con una tarjeta NVIDIA, puede que necesite añadir &apos;xorg=nvidia&apos; a las opciones de arranque.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="710"/>
        <source>Could not replace the exclusion file with the updated default.</source>
        <translation>No se pudo reemplazar el archivo de exclusión con el por defecto actualizado.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="729"/>
        <source>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</source>
        <translation>El kernel actual no admite el algoritmo de compresión seleccionado, por favor edite el archivo de configuración y seleccione un algoritmo diferente.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="752"/>
        <source>Final chance</source>
        <translation>Última oportunidad</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="754"/>
        <source>Snapshot now has all the information it needs to create an ISO from your running system.</source>
        <translation>Snapshot ya cuenta con toda la información necesaria para crear una ISO de su sistema actual.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="755"/>
        <source>It will take some time to finish, depending on the size of the installed system and the capacity of your computer.</source>
        <translation>Va a tomar un tiempo terminar, dependiendo del tamaño del sistema instalado y de la capacidad de su computadora.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="757"/>
        <source>OK to start?</source>
        <translation>¿Acepta empezar?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="761"/>
        <source>Shutdown computer when done.</source>
        <translation>Apagar la computadora al finalizar.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="794"/>
        <source>Output</source>
        <translation>Salida</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="810"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="817"/>
        <source>Edit Boot Menu</source>
        <translation>Editar el Menú de Inicio</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="818"/>
        <source>The program will now pause to allow you to edit any files in the work directory. Select Yes to edit the boot menu or select No to bypass this step and continue creating the snapshot.</source>
        <translation>El programa efectuará una pausa para que edite cualquier archivo en el directorio de trabajo.  Seleccione Sí para editar el menú de inicio o No para saltarse este paso y seguir con la creación de la imagen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="854"/>
        <source>Revert the exclusion list to the default file? This will overwrite your current exclusions.</source>
        <translation>¿Desea restablecer la lista de exclusiones al archivo por defecto? Esto sobrescribirá sus exclusiones actuales.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="934"/>
        <source>About %1</source>
        <translation>Acerca de %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="936"/>
        <source>Version: </source>
        <translation>Versión:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="937"/>
        <source>Program for creating a live-CD from the running system for MX Linux</source>
        <translation>Programa para crear un live-CD del sistema actual de MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="939"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="941"/>
        <source>%1 License</source>
        <translation>%1 Licencia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="954"/>
        <source>%1 Help</source>
        <translation>%1 Ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="959"/>
        <source>Select Snapshot Directory</source>
        <translation>Seleccione el directorio para la imagen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="967"/>
        <source>Insufficient free space in the selected directory. Please choose a different location.</source>
        <translation>Espacio libre insuficiente en el directorio seleccionado. Elija una ubicación diferente.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="987"/>
        <source>Confirmation</source>
        <translation>Confirmación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="987"/>
        <source>Are you sure you want to quit the application?</source>
        <translation>¿Está seguro de que desea salir de la aplicación?</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/main.cpp" line="95"/>
        <source>Tool used for creating a live-CD from the running system</source>
        <translation>Herramienta utilizada para crear un live-CD desde el sistema activo</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="99"/>
        <source>Use CLI only</source>
        <translation>Solo usar CLI</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="103"/>
        <source>Number of CPU cores to be used.</source>
        <translation>Número de núcleos de CPU que se van a utilizar.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="104"/>
        <source>Output directory</source>
        <translation>Directorio de salida</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="105"/>
        <source>Output filename</source>
        <translation>Nombre del archivo de salida</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="107"/>
        <source>Name a different kernel to use other than the default running kernel, use format returned by &apos;uname -r&apos;</source>
        <translation>Nombrar un kernel diferente para usar que no sea el kernel en ejecución predeterminado, usar el formato devuelto por &apos;uname -r&apos;</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="109"/>
        <source>Or the full path: %1</source>
        <translation>O la ruta completa: %1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="112"/>
        <source>Compression level options.</source>
        <translation>Opciones de nivel de compresión.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>Use quotes: &quot;-Xcompression-level &lt;level&gt;&quot;, or &quot;-Xalgorithm &lt;algorithm&gt;&quot;, or &quot;-Xhc&quot;, see mksquashfs man page</source>
        <translation>Utilice comillas: &quot;-Xcompression-level &lt;level&gt;&quot;, o &quot;-Xalgorithm&lt;algorithm&gt;&quot;, o &quot;-Xhc&quot;, consulte la página del manual de mksquashfs</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="117"/>
        <source>Create a monthly snapshot, add &apos;Month&apos; name in the ISO name, skip used space calculation</source>
        <translation>Crear una imagen mensual, agregar el &apos;Mes&apos; en el nombre ISO, omitir el cálculo del espacio usado</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="118"/>
        <source>This option sets reset-accounts and compression to defaults, arguments changing those items will be ignored</source>
        <translation>Esta opción restablece las cuentas y la compresión a los valores predeterminados, los argumentos que cambian esos elementos se ignorarán</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="120"/>
        <source>Optionally specify a suffix to add to the month name (e.g., &apos;1&apos; for &apos;July.1&apos;)</source>
        <translation>Opcionalmente, especifique un sufijo para añadir al nombre del mes (p.ej., &quot;1&quot; para &quot;Julio.1&quot;)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="121"/>
        <source>Don&apos;t calculate checksums for resulting ISO file</source>
        <translation>No calcule sumas de comprobación para el archivo ISO resultante</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="122"/>
        <source>Skip calculating free space to see if the resulting ISO will fit</source>
        <translation>Omita el cálculo del espacio libre para ver si el ISO resultante se ajusta</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="123"/>
        <source>Option to fix issue with calculating checksums on preempt_rt kernels</source>
        <translation>Opción para solucionar el problema con el cálculo de sumas de comprobación en kernels preempt_rt</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="124"/>
        <source>Resetting accounts (for distribution to others)</source>
        <translation>Cuentas por defecto restablecidas (para distribuir a otros)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="125"/>
        <source>Calculate checksums for resulting ISO file</source>
        <translation>Calcular sumas de comprobación para el archivo ISO resultante</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="127"/>
        <source>Throttle the I/O input rate by the given percentage. This can be used to reduce the I/O and CPU consumption of Mksquashfs.</source>
        <translation>Reduce la tasa de entrada E/S en el porcentaje dado. Esto puede usarse para reducir el consumo de E/S y CPU de Mksquashfs.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="130"/>
        <source>Work directory</source>
        <translation>Directorio de trabajo</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="132"/>
        <source>Exclude main folders, valid choices: </source>
        <translation>Excluir carpetas principales, opciones válidas:</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="134"/>
        <source>Use the option one time for each item you want to exclude</source>
        <translation>Utilice la opción una vez para cada elemento que desee excluir.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="137"/>
        <source>Compression format, valid choices: </source>
        <translation>Formato de compresión, opciones válidas:</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="139"/>
        <source>Shutdown computer when done.</source>
        <translation>Apagar la computadora al finalizar.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="213"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Parece que ha iniciado sesión como root, cierre la sesión e inicie sesión como usuario normal para utilizar este programa.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="231"/>
        <source>version:</source>
        <translation>versión:</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="225"/>
        <source>You must run this program with sudo or pkexec.</source>
        <translation>Debe ejecutar este programa con sudo o pkexec.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="208"/>
        <source>MX Snapshot</source>
        <translation>MX Snapshot</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="215"/>
        <location filename="../src/main.cpp" line="283"/>
        <location filename="../src/settings.cpp" line="524"/>
        <location filename="../src/settings.cpp" line="532"/>
        <location filename="../src/settings.cpp" line="1062"/>
        <location filename="../src/settings.cpp" line="1156"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="282"/>
        <location filename="../src/settings.cpp" line="531"/>
        <source>Current kernel doesn&apos;t support Squashfs, cannot continue.</source>
        <translation>El kernel actual no soporta Squashfs, no puede continuar.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="97"/>
        <source>Failed to initialize configuration</source>
        <translation>No se pudo inicializar la configuración.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="131"/>
        <source>Configuration validation failed</source>
        <translation>Error en la validación de la configuración</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="136"/>
        <source>Exception during initialization: %1</source>
        <translation>Excepción durante la inicialización: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="139"/>
        <source>Unknown exception during initialization</source>
        <translation>Excepción desconocida durante la inicialización</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="170"/>
        <source>Could not create work directory. </source>
        <translation>No se pudo crear el directorio de trabajo.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="197"/>
        <source>Could not create temp directory:</source>
        <translation>No se pudo crear el directorio temporal:</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="198"/>
        <source>Please check that the parent directory exists and is writable:</source>
        <translation>Compruebe que el directorio padre existe y puede escribir en el:</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="216"/>
        <source>Compression format &apos;%1&apos; is not supported by the current kernel</source>
        <translation>El formato de compresión &apos;%1&apos; no está soportado por el kernel actual</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="222"/>
        <source>Invalid cores setting: %1. Must be between 1 and %2</source>
        <translation>Configuración de núcleos no válida: %1. Debe estar 1 y %2</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="228"/>
        <source>Invalid throttle setting: %1. Must be between 0 and 20</source>
        <translation>Configuración del regulador de frecuencia no válida: %1. Debe estar entre 0 y 20</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="234"/>
        <source>Snapshot directory cannot be empty</source>
        <translation>El directorio de la instantánea no puede estar vacío</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="242"/>
        <source>Snapshot name cannot be empty</source>
        <translation>El nombre de la instantánea no puede estar vacío</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="248"/>
        <source>Snapshot name contains invalid characters: %1</source>
        <translation>El nombre de la instantánea contiene caracteres no válidos: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="254"/>
        <source>Kernel version cannot be empty</source>
        <translation>La versión del Kernel no puede estar vacía</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="259"/>
        <source>Kernel file not found: /boot/vmlinuz-%1</source>
        <translation>No se encontró el archivo del núcleo: /boot/vmlinuz-%1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="265"/>
        <source>Kernel %1 doesn&apos;t support Squashfs</source>
        <translation>Kernel %1 no soportado para Squashfs</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="296"/>
        <source>Exclusion file does not exist: %1</source>
        <translation>El archivo de exclusión no existe: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="305"/>
        <source>Unbalanced quotes in exclusion list</source>
        <translation>Comillas incompletas en la lista de exclusión</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="330"/>
        <source>Insufficient free space: %1 KiB available, minimum %2 KiB required</source>
        <translation>Espacio libre insuficiente: %1 KiB disponible, se requiere un mínimo de %2 KiB</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="337"/>
        <source>Insufficient free space in work directory: %1 KiB available, minimum %2 KiB required</source>
        <translation>Espacio libre insuficiente en el directorio de trabajo: %1 KiB disponible, se requiere un mínimo de %2 KiB</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="352"/>
        <source>Failed to determine number of CPU cores</source>
        <translation>No se ha podido determinar el número de núcleos de la CPU.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="358"/>
        <source>Configuration file does not exist: %1</source>
        <translation>El archivo de configuración no existe: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="359"/>
        <source>Using default settings</source>
        <translation>Usando la configuración por defecto</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="361"/>
        <source>Cannot read configuration file: %1</source>
        <translation>No se puede leer el archivo de configuración: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="362"/>
        <source>Error: %1</source>
        <translation>Error: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="372"/>
        <source>Required tool not found: %1</source>
        <translation>No se encontró la herramienta necesaria: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="381"/>
        <source>Required directory not found: %1</source>
        <translation>No se encontró el directorio necesario: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="400"/>
        <source>Initialization Error</source>
        <translation>Error de inicialización</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="401"/>
        <source>Failed to initialize application settings:

%1</source>
        <translation>No se pudo inicializar la configuración de la aplicación:

%1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="522"/>
        <source>Could not find a usable kernel</source>
        <translation>No se pudo encontrar un kernel utilizable</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="523"/>
        <source>Searched for kernel files in /boot/ but none were found or accessible.</source>
        <translation>Se buscaron archivos del núcleo en /boot/, pero no se encontró ninguno ni se pudo acceder a ellos.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="544"/>
        <source>No users found in the system</source>
        <translation>No se han encontrado usuarios en el sistema</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="547"/>
        <source>Failed to determine system information</source>
        <translation>No se pudo determinar la información del sistema</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="641"/>
        <source>Used space on / (root): </source>
        <translation>Espacio usado en / (root): </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="644"/>
        <source>estimated</source>
        <translation>estimado</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="653"/>
        <source>Used space on /home: </source>
        <translation>Espacio usado en /home: </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="709"/>
        <source>Free space on %1, where snapshot folder is placed: </source>
        <translation>Espacio libre en %1, donde se colocará la imagen del sistema: </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="713"/>
        <source>The free space should be sufficient to hold the compressed data from / and /home

      If necessary, you can create more available space
      by removing previous snapshots and saved copies:
      %1 snapshots are taking up %2 of disk space.
</source>
        <translation>El espacio libre debería bastar para los datos comprimidos de  / y /home

      De ser necesario, puede hacer más espacio
      removiendo imágenes anteriores y copias guardadas:
      %1 imágenes toman %2 del espacio en el disco.
</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="727"/>
        <source>Desktop</source>
        <translation>Escritorio</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="728"/>
        <source>Documents</source>
        <translation>Documentos</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="729"/>
        <source>Downloads</source>
        <translation>Descargas</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="730"/>
        <source>Flatpaks</source>
        <translation>Flatpaks</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="731"/>
        <source>Music</source>
        <translation>Música</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="732"/>
        <source>Networks</source>
        <translation>Redes</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="733"/>
        <source>Pictures</source>
        <translation>Imágenes</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="735"/>
        <source>Videos</source>
        <translation>Videos</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="884"/>
        <source>Error reading system configuration file: %1</source>
        <translation>Error al leer el archivo de configuración del sistema: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="892"/>
        <source>Error accessing user configuration</source>
        <translation>Error al acceder a la configuración del usuario</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="944"/>
        <source>Could not copy exclusion file from %1 to %2</source>
        <translation>No se pudo copiar el archivo de exclusión de %1 a %2.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="969"/>
        <source>Invalid stored cores setting (%1). Using detected CPU count: %2</source>
        <translation>Ajuste de núcleos no válido (%1). Usando el recuento de CPU detectadas: %2</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1060"/>
        <location filename="../src/settings.cpp" line="1154"/>
        <source>Output file %1 already exists. Please use another file name, or delete the existent file.</source>
        <translation>El archivo de salida %1 ya existe. Utilice otro nombre de archivo o elimine el archivo existente.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="73"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <location filename="../src/about.cpp" line="107"/>
        <source>Changelog</source>
        <translation>Registro de cambios</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="98"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="119"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="53"/>
        <location filename="../src/about.cpp" line="122"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
</context>
<context>
    <name>Work</name>
    <message>
        <location filename="../src/work.cpp" line="173"/>
        <source>Cleaning...</source>
        <translation>Limpiando...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="189"/>
        <location filename="../src/work.cpp" line="467"/>
        <source>Done</source>
        <translation>Listo</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="201"/>
        <source>Interrupted or failed to complete</source>
        <translation>Interrumpido o no se pudo completar</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="237"/>
        <location filename="../src/work.cpp" line="419"/>
        <location filename="../src/work.cpp" line="447"/>
        <location filename="../src/work.cpp" line="485"/>
        <location filename="../src/work.cpp" line="626"/>
        <location filename="../src/work.cpp" line="660"/>
        <location filename="../src/work.cpp" line="673"/>
        <location filename="../src/work.cpp" line="681"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="238"/>
        <source>There&apos;s not enough free space on your target disk, you need at least %1</source>
        <translation>No hay suficiente espacio libre en el disco de destino, necesita al menos %1</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="241"/>
        <source>You have %1 free space on %2</source>
        <translation>Tienes %1  de espacio libre en %2</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="244"/>
        <source>If you are sure you have enough free space rerun the program with -o/--override-size option</source>
        <translation>Si está seguro de que tiene suficiente espacio libre, vuelva a ejecutar el programa con la opción -o/--override-size</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="330"/>
        <source>Copying the new-iso filesystem...</source>
        <translation>Copiando el sistema de archivos new-iso...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="348"/>
        <source>Could not create temp directory. </source>
        <translation>No se pudo crear el directorio temporal.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="416"/>
        <source>Squashing filesystem...</source>
        <translation>Comprimiendo el sistema de archivos...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="420"/>
        <source>Could not create linuxfs file, please check /var/log/%1.log</source>
        <translation>Ha sido imposible crear el archivo linuxfs, por favor lea /var/log/%1.log</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="444"/>
        <source>Creating CD/DVD image file...</source>
        <translation>Creando la imagen de CD/DVD...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="448"/>
        <source>Could not create ISO file, please check whether you have enough space on the destination partition.</source>
        <translation>No se pudo crear un archivo ISO; por favor revise si tiene suficiente espacio en la partición de destino.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="454"/>
        <source>Making hybrid iso</source>
        <translation>Creando un iso híbrido</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="472"/>
        <source>Success</source>
        <translation>Éxito</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="473"/>
        <source>MX Snapshot completed successfully!</source>
        <translation>¡MX Snapshot se ha completado con éxito!</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="474"/>
        <source>Snapshot took %1 to finish.</source>
        <translation>La imagen tardó 1% en finalizar.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="475"/>
        <source>Thanks for using MX Snapshot, run MX Live USB Maker next!</source>
        <translation>Gracias por usar MX Snapshot, ejecute MX Creador de Live-USB a continuación!</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="482"/>
        <source>Installing </source>
        <translation>Instalando</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="485"/>
        <source>Could not install </source>
        <translation>No se pudo instalar</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="495"/>
        <source>Calculating checksum...</source>
        <translation>Calculando suma de comprobación...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="536"/>
        <source>Building new initrd...</source>
        <translation>Construyendo nuevo initrd...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="627"/>
        <source>Could not create working directory. </source>
        <translation>No se pudo crear el directorio de trabajo.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="661"/>
        <source>Could not prepare a safe bind-root overlay. Snapshot cannot continue.</source>
        <translation>No se pudo preparar una superposición segura de bind-root. La instantánea no puede continuar.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="674"/>
        <location filename="../src/work.cpp" line="682"/>
        <source>Could not prepare the snapshot bind-root environment.</source>
        <translation>No se pudo preparar el entorno bind-root de la instantánea.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="986"/>
        <source>Calculating total size of excluded files...</source>
        <translation>Calculando el tamaño total de los archivos excluidos...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1012"/>
        <source>Calculating size of root...</source>
        <translation>Calculando el tamaño de root...</translation>
    </message>
</context>
</TS>