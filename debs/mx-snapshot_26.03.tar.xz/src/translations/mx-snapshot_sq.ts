<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="sq">
<context>
    <name>Batchprocessing</name>
    <message>
        <location filename="../src/batchprocessing.cpp" line="54"/>
        <source>Error</source>
        <translation>Gabim</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="55"/>
        <source>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</source>
        <translation>Kerneli i tanishëm nuk mbulon algoritëm të përzgjedhur për ngjeshje, ju lutemi, përpunon kartelën e formësimit dhe përzgjidhni një tjetër logaritëm.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="80"/>
        <source>The program will pause the build and open the boot menu in your text editor.</source>
        <translation>Programi do të ndalë ndërtimin dhe hapë menunë e nisjes në përpunuesin tuaj të teksteve.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="162"/>
        <source>No diff output available.</source>
        <translation>S’ka përfundim diff--i.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="200"/>
        <source>Default exclusion file not found at %1.</source>
        <translation>S’u gjet kartelë parazgjedhje përjashtimesh te %1.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="212"/>
        <source>Could not backup existing exclusion file to %1.</source>
        <translation>S’u kopjeruajt dot kartelë ekzistuese përjashtimesh te %1.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="215"/>
        <source>Could not remove existing exclusion file at %1.</source>
        <translation>S’u hoq dot kartelë ekzistuese përjashtimesh te %1.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="222"/>
        <source>Could not copy default exclusion file from %1 to %2.</source>
        <translation>S’u kopjua dot kartelë ekzistuese përjashtimesh nga %1 në %2.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="238"/>
        <source>Detected newer exclusion file at %1 compared to %2. Prompting for action.</source>
        <translation>Te %1 u pikas kartelë përjashtimesh më e re, krahasuar me %2. Po kërkohet për veprim.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="244"/>
        <source>s</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'show diff'</comment>
        <translation>s</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="245"/>
        <source>u</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'use updated default'</comment>
        <translation>p</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="246"/>
        <source>k</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'keep custom (update timestamp)'</comment>
        <translation>m</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="247"/>
        <source>q</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'quit'</comment>
        <translation>d</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="249"/>
        <source>show diff</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>shfaqe diff-in</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="250"/>
        <source>use updated default</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>përdor parazgjedhje të përditësuar</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="251"/>
        <source>keep custom (update timestamp)</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>mbaj vetjaken (përditëso vulë kohore)</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="252"/>
        <source>quit</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>mbylle</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="255"/>
        <source>[%1]%2  [%3]%4  [%5]%6  [%7]%8: </source>
        <translation>[%1]%2  [%3]%4  [%5]%6  [%7]%8: </translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="260"/>
        <source>The exclusion file at %1 is newer than your configured file at %2.</source>
        <translation>Kartela e përjashtimit te %1 është më e re se sa kartela juaj e formësuar te %2.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="276"/>
        <source>Reverted to updated default exclusion file.</source>
        <translation>U kthye te kartela parazgjedhje e përditësuar e përjashtimeve.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="297"/>
        <source>Leaving custom exclusion file unchanged.</source>
        <translation>Po lihet e pandryshuar kartela vetjake e përjashtimeve.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="308"/>
        <source>Invalid choice. Please select again.</source>
        <translation>Zgjidhje e pavlefshme. Ju lutemi, përzgjidhni sërish.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="315"/>
        <source>This computer uses an NVIDIA graphics card. Are you planning to use the resulting ISO on the same computer or another computer with an NVIDIA card?</source>
        <translation>Ky kompjuter përdor një kartë grafike NVIDIA. Keni në plan ta përdorni IOS-n e prodhuar keni në plan ta përdorni në të njëjtin kompjuter, apo në një tjetër kompjuter me një kartë NVIDIA?</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="325"/>
        <source>Note: If you use the resulting ISO on a computer without an NVIDIA card, you will likely need to remove &apos;xorg=nvidia&apos; from the boot options.</source>
        <translation>Shënim: Nëse ISO-n e prodhuar e përdorni në një kompjuter pa një kartë NVIDIA, gjasat janë t’ju duhet të hiqni &apos;xorg=nvidia&apos; nga mundësitë e nisjes.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="328"/>
        <source>Note: If you use the resulting ISO on a computer with an NVIDIA card, you may need to add &apos;xorg=nvidia&apos; to the boot options.</source>
        <translation>Shënim: Nëse ISO-n e prodhuar e përdorni në një kompjuter me një kartë NVIDIA, mund t’ju duhet të shtoni &apos;xorg=nvidia&apos; te mundësitë e nisjes.</translation>
    </message>
</context>
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="82"/>
        <source>No elevation tool found (pkexec/gksu/sudo).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="116"/>
        <source>Administrator Access Required</source>
        <translation>Lyp Hyrje Përgjegjësi</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="117"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation>Ky veprim lyp privilegje përgjegjësi. Ju lutemi, rinisni aplikacionin dhe jepni fjalëkalimin tuaj kur t’ju kërkohet.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <location filename="../src/mainwindow.cpp" line="446"/>
        <location filename="../src/mainwindow.cpp" line="833"/>
        <location filename="../src/ui_mainwindow.h" line="745"/>
        <source>MX Snapshot</source>
        <translation>Fotografim MX Sistemi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="33"/>
        <location filename="../src/ui_mainwindow.h" line="746"/>
        <source>Optional customization</source>
        <translation>Përshtatje opsionale</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="65"/>
        <location filename="../src/ui_mainwindow.h" line="747"/>
        <source>Release version:</source>
        <translation>Version hedhjeje në qarkullim:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="79"/>
        <location filename="../src/ui_mainwindow.h" line="748"/>
        <source>Boot options:</source>
        <translation>Mundësi nisjeje:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="86"/>
        <location filename="../src/ui_mainwindow.h" line="749"/>
        <source>Live kernel:</source>
        <translation>Kernel “live”:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="93"/>
        <location filename="../src/ui_mainwindow.h" line="750"/>
        <source>Project name:</source>
        <translation>Emër projekti:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="100"/>
        <location filename="../src/ui_mainwindow.h" line="751"/>
        <source>Release date:</source>
        <translation>Datë hedhjeje në qarkullim:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="107"/>
        <location filename="../src/ui_mainwindow.h" line="752"/>
        <source>Release codename:</source>
        <translation>Emër kod për hedhjen në qarkullim:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="133"/>
        <location filename="../src/ui_mainwindow.h" line="753"/>
        <source>Current date</source>
        <translation>Data e sotme</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="172"/>
        <location filename="../src/ui_mainwindow.h" line="754"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Snapshot is a utility that creates a bootable image (ISO) of your working system that you can use for storage or distribution. You can continue working with undemanding applications while it is running.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Fotografimi është një mjet që krijon një pamje të nisshme (ISO) të sistemit që përdorni, e cila mund të përdoret për depozitim ose shpërndarje. Mund të vazhdoni të punoni me aplikacione jo të rënda, teksa xhiron mjeti.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="182"/>
        <location filename="../src/ui_mainwindow.h" line="755"/>
        <source>Used space on / (root) and /home partitions:</source>
        <translation>Hapësirë e përdorur në pjesët / (rrënjë) dhe /home:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="192"/>
        <location filename="../src/ui_mainwindow.h" line="756"/>
        <source>Location and ISO name</source>
        <translation>Vendndodhje dhe emër ISO-je</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="219"/>
        <location filename="../src/ui_mainwindow.h" line="758"/>
        <source>Snapshot location:</source>
        <translation>Vendndodhje fotografimi:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="226"/>
        <location filename="../src/ui_mainwindow.h" line="759"/>
        <source>Select a different snapshot directory</source>
        <translation>Përzgjidhni tjetër drejtori fotografimesh</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="236"/>
        <location filename="../src/mainwindow.cpp" line="641"/>
        <location filename="../src/ui_mainwindow.h" line="760"/>
        <source>Snapshot name:</source>
        <translation>Emër fotografimi:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="360"/>
        <location filename="../src/ui_mainwindow.h" line="764"/>
        <source>Type of snapshot:</source>
        <translation>Lloj fotografimi:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="367"/>
        <location filename="../src/ui_mainwindow.h" line="765"/>
        <source>Preserving accounts (for personal backup)</source>
        <translation>Ruajtje llogarish (për kopjeruajtje personale)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <location filename="../src/ui_mainwindow.h" line="767"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This option will reset &amp;quot;demo&amp;quot; and &amp;quot;root&amp;quot; passwords to the MX Linux defaults and will not copy any personal accounts created.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Kjo mundësi do të bëjë kthimin e fjalëkalimeve për “demo” dhe “root” te parazgjedhjet e MX Linux-it dhe s’do të kopjojë ndonjë llogari personale të krijuar.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="380"/>
        <location filename="../src/ui_mainwindow.h" line="769"/>
        <source>Resetting accounts (for distribution to others)</source>
        <translation>Po rikthehen llogaritë te parazgjedhjet (për shpërndarje të tjerëve)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="451"/>
        <location filename="../src/ui_mainwindow.h" line="770"/>
        <source>You can also exclude certain directories by ticking the common choices below, or by clicking on the button to directly edit /etc/mx-snapshot-exclude.list.</source>
        <translation>Mundeni edhe të përjashtoni drejtori të caktuara, duke u vënë shenjë zgjidhjeve të zakonshme më poshtë, ose duke klikuar mbi butonin, për të përpunuar drejtpërsëdrejti /etc/mx-snapshot-exclude.list.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="496"/>
        <location filename="../src/ui_mainwindow.h" line="771"/>
        <source>sha512</source>
        <translation>sha512</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="519"/>
        <location filename="../src/ui_mainwindow.h" line="773"/>
        <source>Throttle the I/O input rate by the given percentage.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="525"/>
        <location filename="../src/ui_mainwindow.h" line="775"/>
        <source>I/O throttle:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="532"/>
        <location filename="../src/ui_mainwindow.h" line="776"/>
        <source>Calculate checksums:</source>
        <translation>Njehsoni checksum-e:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="539"/>
        <location filename="../src/ui_mainwindow.h" line="777"/>
        <source>ISO compression scheme:</source>
        <translation>Skemë ngjeshjeje për ISO-n:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="546"/>
        <location filename="../src/ui_mainwindow.h" line="778"/>
        <source>Number of CPU cores to use:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="553"/>
        <location filename="../src/ui_mainwindow.h" line="779"/>
        <source>md5</source>
        <translation>md5</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="563"/>
        <location filename="../src/ui_mainwindow.h" line="780"/>
        <source>Options:</source>
        <translation>Mundësi:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="610"/>
        <location filename="../src/ui_mainwindow.h" line="781"/>
        <source>Edit Exclusion File</source>
        <translation>Përpunoni Kartelë Përjashtimesh</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="626"/>
        <location filename="../src/mainwindow.cpp" line="853"/>
        <location filename="../src/ui_mainwindow.h" line="782"/>
        <source>Remove Custom Exclusion File</source>
        <translation>Hiq Kartelë Vetjake Përjashtimesh</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="679"/>
        <location filename="../src/ui_mainwindow.h" line="783"/>
        <source>Pictures</source>
        <translation>Foto</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="686"/>
        <location filename="../src/ui_mainwindow.h" line="784"/>
        <source>Videos</source>
        <translation>Video</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="693"/>
        <location filename="../src/ui_mainwindow.h" line="785"/>
        <source>All of the above</source>
        <translation>Krejt sa më sipër</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="700"/>
        <location filename="../src/ui_mainwindow.h" line="787"/>
        <source>exclude network configurations</source>
        <translation>përjashto formësime rrjeti</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="703"/>
        <location filename="../src/ui_mainwindow.h" line="789"/>
        <source>Networks</source>
        <translation>Rrjete</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="710"/>
        <location filename="../src/ui_mainwindow.h" line="790"/>
        <source>Downloads</source>
        <translation>Shkarkime</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="717"/>
        <location filename="../src/ui_mainwindow.h" line="791"/>
        <source>Desktop</source>
        <translation>Desktop</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="724"/>
        <location filename="../src/ui_mainwindow.h" line="792"/>
        <source>Documents</source>
        <translation>Dokumente</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="731"/>
        <location filename="../src/ui_mainwindow.h" line="793"/>
        <source>Flatpaks</source>
        <translation>Paketime Flatpak</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="738"/>
        <location filename="../src/ui_mainwindow.h" line="794"/>
        <source>Music</source>
        <translation>Muzikë</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="850"/>
        <location filename="../src/ui_mainwindow.h" line="797"/>
        <source>About this application</source>
        <translation>Mbi këtë aplikacion</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="853"/>
        <location filename="../src/ui_mainwindow.h" line="799"/>
        <source>About...</source>
        <translation>Mbi…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="859"/>
        <location filename="../src/ui_mainwindow.h" line="801"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="875"/>
        <location filename="../src/ui_mainwindow.h" line="803"/>
        <source>Next</source>
        <translation>Pasuesi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="900"/>
        <location filename="../src/ui_mainwindow.h" line="808"/>
        <source>Display help </source>
        <translation>Shfaq ndihmë</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="903"/>
        <location filename="../src/ui_mainwindow.h" line="810"/>
        <source>Help</source>
        <translation>Ndihmë</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="909"/>
        <location filename="../src/ui_mainwindow.h" line="812"/>
        <source>Alt+H</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="922"/>
        <location filename="../src/ui_mainwindow.h" line="815"/>
        <source>Quit application</source>
        <translation>Mbylle aplikacionin</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="925"/>
        <location filename="../src/ui_mainwindow.h" line="817"/>
        <source>Cancel</source>
        <translation>Anuloje</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="931"/>
        <location filename="../src/ui_mainwindow.h" line="819"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="985"/>
        <location filename="../src/ui_mainwindow.h" line="822"/>
        <source>Back</source>
        <translation>Mbrapsht</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="408"/>
        <source>Select Release Date</source>
        <translation>Përzgjidhni Datë Hedhjeje Në Qarkullim</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="452"/>
        <source>fastest, worst compression</source>
        <translation>më e shpejta, ngjeshja më e dobët</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="452"/>
        <source>fast, worse compression</source>
        <translation>e shpejtë, ngjeshje e dobët</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="453"/>
        <source>slow, better compression</source>
        <translation>e ngadaltë, ngjeshje më e mirë</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="453"/>
        <source>best compromise</source>
        <translation>kompromisi më i mirë</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="454"/>
        <source>slowest, best compression</source>
        <translation>më e ngadalta, ngjeshja më e mirë</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="483"/>
        <source>Free space on %1, where snapshot folder is placed: </source>
        <translation>Hapësirë e lirë në %1, ku vendoset dosja e fotografimeve: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="486"/>
        <source>The free space should be sufficient to hold the compressed data from / and /home

      If necessary, you can create more available space by removing previous snapshots and saved copies: %1 snapshots are taking up %2 of disk space.</source>
        <translation>Hapësira e lirë duhet të jetë e mjaftueshme për mbajtjen e të dhënave të ngjeshura nga / dhe /home

      Në u dashtë, mund të krijoni më tepër hapësirë të lirë, duke hequr fotografime të mëparshme dhe kopje të ruajtura: %1 fotografime zënë aktualisht %2 të hapësirës së diskut.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="498"/>
        <location filename="../src/mainwindow.cpp" line="499"/>
        <source>Installing </source>
        <translation>Po instalohet </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="584"/>
        <source>Please wait.</source>
        <translation>Ju lutemi, pritni.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="586"/>
        <source>Please wait. Calculating used disk space...</source>
        <translation>Ju lutemi, pritni. Po llogaritet hapësira e përdorur në disk…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="313"/>
        <location filename="../src/mainwindow.cpp" line="330"/>
        <location filename="../src/mainwindow.cpp" line="337"/>
        <location filename="../src/mainwindow.cpp" line="620"/>
        <location filename="../src/mainwindow.cpp" line="627"/>
        <location filename="../src/mainwindow.cpp" line="709"/>
        <location filename="../src/mainwindow.cpp" line="728"/>
        <location filename="../src/mainwindow.cpp" line="967"/>
        <source>Error</source>
        <translation>Gabim</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="177"/>
        <source>No diff output available.</source>
        <translation>S’ka përfundim diff--i.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="210"/>
        <location filename="../src/mainwindow.cpp" line="246"/>
        <source>Updated Exclusion List</source>
        <translation>U përditësua Listë Përjashtimesh</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="213"/>
        <source>The exclusion file at %1 is newer than your configured file at %2.</source>
        <translation>Kartela e përjashtimit te %1 është më e re se sa kartela juaj e formësuar te %2.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="215"/>
        <source>Review the changes below. Keep your custom file or replace it with the updated default.</source>
        <translation>Shqyrtoni ndryshimet më poshtë. Mbajini kartelën tuaj të përshtatur, ose zëvendësojeni me parazgjedhjen e përditësuar.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="221"/>
        <source>Show Differences</source>
        <translation>Shfaq Dallimet</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="227"/>
        <source>Keep Custom</source>
        <translation>Mbaj të Përshtaturën</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="233"/>
        <source>Use Updated Default</source>
        <translation>Përdor Parazgjedhjen e Përditësuar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="314"/>
        <source>Default exclusion file not found at %1.</source>
        <translation>S’u gjet kartelë parazgjedhje përjashtimesh te %1.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="326"/>
        <source>Warning</source>
        <translation>Kujdes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="327"/>
        <source>Could not backup existing exclusion file to %1.</source>
        <translation>S’u kopjeruajt dot kartelë ekzistuese përjashtimesh te %1.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="331"/>
        <source>Could not remove existing exclusion file at %1.</source>
        <translation>S’u hoq dot kartelë ekzistuese përjashtimesh te %1.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="338"/>
        <source>Could not copy default exclusion file from %1 to %2.</source>
        <translation>S’u kopjua dot kartelë ekzistuese përjashtimesh nga %1 në %2.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="621"/>
        <source>Output file %1 already exists. Please use another file name, or delete the existent file.</source>
        <translation>Kartela përfundim %1 ekziston tashmë. Ju lutemi, përdorni një tjetër emër kartele, ose fshini kartelën ekzistuese.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="628"/>
        <source>Insufficient free space. Please select a different snapshot directory or free up space.</source>
        <translation>Hapësirë e lirë e pamjaftueshme. Ju lutemi, përzgjidhni një tjetër drejtori fotografimesh sistemi, ose lironi ca hapësirë.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="632"/>
        <source>Settings</source>
        <translation>Rregullime</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="638"/>
        <source>Snapshot will use the following settings:</source>
        <translation>Fotografimi do të përdorë rregullimet vijuese:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="640"/>
        <source>- Snapshot directory:</source>
        <translation>- Drejtorimi fotografimesh:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="641"/>
        <source>- Kernel to be used:</source>
        <translation>- Kernel për t’u përdorur:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="665"/>
        <location filename="../src/mainwindow.cpp" line="674"/>
        <source>NVIDIA Detected</source>
        <translation>U pikas NVIDIA</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="666"/>
        <source>This computer uses an NVIDIA graphics card. Are you planning to use the resulting ISO on the same computer or another computer with an NVIDIA card?</source>
        <translation>Ky kompjuter përdor një kartë grafike NVIDIA. Keni në plan ta përdorni IOS-n e prodhuar keni në plan ta përdorni në të njëjtin kompjuter, apo në një tjetër kompjuter me një kartë NVIDIA?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="670"/>
        <source>NVIDIA Selected</source>
        <translation>U përzgjodh NVIDIA</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="671"/>
        <source>Note: If you use the resulting ISO on a computer without an NVIDIA card, you will likely need to remove &apos;xorg=nvidia&apos; from the boot options.</source>
        <translation>Shënim: Nëse ISO-n e prodhuar e përdorni në një kompjuter pa një kartë NVIDIA, gjasat janë t’ju duhet të hiqni &apos;xorg=nvidia&apos; nga mundësitë e nisjes.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="675"/>
        <source>Note: If you use the resulting ISO on a computer with an NVIDIA card, you may need to add &apos;xorg=nvidia&apos; to the boot options.</source>
        <translation>Shënim: Nëse ISO-n e prodhuar e përdorni në një kompjuter me një kartë NVIDIA, mund t’ju duhet të shtoni &apos;xorg=nvidia&apos; te mundësitë e nisjes.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="710"/>
        <source>Could not replace the exclusion file with the updated default.</source>
        <translation>S’u zëvendësua kartela e përjashtimeve me parazgjedhjen e përditësuar.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="729"/>
        <source>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</source>
        <translation>Kerneli i tanishëm nuk mbulon algoritëm të përzgjedhur për ngjeshje, ju lutemi, përpunon kartelën e formësimit dhe përzgjidhni një tjetër logaritëm.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="752"/>
        <source>Final chance</source>
        <translation>Shansi i fundit</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="754"/>
        <source>Snapshot now has all the information it needs to create an ISO from your running system.</source>
        <translation>Fotografimi tani ka krejt informacionin që i duhet për të krijuar një ISO nga sistemi që xhironi.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="755"/>
        <source>It will take some time to finish, depending on the size of the installed system and the capacity of your computer.</source>
        <translation>Do të duhet ca kohë për ta përfunduar, në varësi të madhësisë së sistemit të instaluar dhe kapaciteteve të kompjuterit tuaj.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="757"/>
        <source>OK to start?</source>
        <translation>OK të fillohet?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="761"/>
        <source>Shutdown computer when done.</source>
        <translation>Fikni kompjuterin, kur të ketë mbaruar.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="794"/>
        <source>Output</source>
        <translation>Përfundim</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="810"/>
        <source>Close</source>
        <translation>Mbylle</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="817"/>
        <source>Edit Boot Menu</source>
        <translation>Përpunoni Menu Nisjeje</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="818"/>
        <source>The program will now pause to allow you to edit any files in the work directory. Select Yes to edit the boot menu or select No to bypass this step and continue creating the snapshot.</source>
        <translation>Programi tani do të ndalet, për t’ju lejuar të përpunoni çfarëdo kartelash te drejtoria e punës. Përzgjidhni Po që të përpunoni menunë e nisjeve, ose përzgjidhni Jo, për të anashkaluar këtë hap dhe të vazhdoni me krijimin e fotografimit.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="854"/>
        <source>Revert the exclusion list to the default file? This will overwrite your current exclusions.</source>
        <translation>Të rikthehet lista e përjashtimeve te kartela parazgjedhje? Kjo do të mbishkruajë përjashtimet tuaja ekzistuese.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="934"/>
        <source>About %1</source>
        <translation>Mbi %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="936"/>
        <source>Version: </source>
        <translation>Version:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="937"/>
        <source>Program for creating a live-CD from the running system for MX Linux</source>
        <translation>Program për krijimin e një CD-je sistemi MX Linux “live” që nga sistemi që po xhironi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="939"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Të drejta kopjimi (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="941"/>
        <source>%1 License</source>
        <translation>Licencë %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="955"/>
        <source>%1 Help</source>
        <translation>Ndihmë për %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="960"/>
        <source>Select Snapshot Directory</source>
        <translation>Përzgjidhni Drejtori Fotografimi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="968"/>
        <source>Insufficient free space in the selected directory. Please choose a different location.</source>
        <translation>Hapësirë e lirë e pamjaftueshme në drejtorinë e përzgjedhur. Ju lutemi, përzgjidhni një tjetër vend.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="988"/>
        <source>Confirmation</source>
        <translation>Ripohim</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="988"/>
        <source>Are you sure you want to quit the application?</source>
        <translation>Jeni i sigurt se doni të mbyllet aplikacioni?</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/main.cpp" line="94"/>
        <source>Tool used for creating a live-CD from the running system</source>
        <translation>Program për krijimin e një CD-je sistemi antiX Linux “live” që nga sistemi që po xhironi</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="98"/>
        <source>Use CLI only</source>
        <translation>Përdor vetëm CLI</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="102"/>
        <source>Number of CPU cores to be used.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="103"/>
        <source>Output directory</source>
        <translation>Drejtori output-i</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="104"/>
        <source>Output filename</source>
        <translation>Emër kartele përfundim</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="106"/>
        <source>Name a different kernel to use other than the default running kernel, use format returned by &apos;uname -r&apos;</source>
        <translation>Caktoni për t’u përdorur një tjetër kernel nga kerneli parazgjedhje që po xhiron, përdorni formatin e kthyer nga “uname -r”</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="108"/>
        <source>Or the full path: %1</source>
        <translation>Ose shteg të plotë: %1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="111"/>
        <source>Compression level options.</source>
        <translation>Mundësi shkalle ngjeshjeje</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="112"/>
        <source>Use quotes: &quot;-Xcompression-level &lt;level&gt;&quot;, or &quot;-Xalgorithm &lt;algorithm&gt;&quot;, or &quot;-Xhc&quot;, see mksquashfs man page</source>
        <translation>Përdorni thonjëza: &quot;-Xcompression-level &lt;level&gt;&quot;, ose &quot;-Xalgorithm &lt;algorithm&gt;&quot;, ose &quot;-Xhc&quot;, shihni faqen man për mksquashfs</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="116"/>
        <source>Create a monthly snapshot, add &apos;Month&apos; name in the ISO name, skip used space calculation</source>
        <translation>Krijo një fotogratim mujor, shto emrin e “Muajit” te emri i ISO-s, anashkalo llogaritjen e hapësirës së përdorur</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="117"/>
        <source>This option sets reset-accounts and compression to defaults, arguments changing those items will be ignored</source>
        <translation>Kjo mundësi kthen reset-accounts dhe ngjeshje te vlerat parazgjedhje, do të shpërfillen argumente që ndryshojnë këto zëra</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="119"/>
        <source>Optionally specify a suffix to add to the month name (e.g., &apos;1&apos; for &apos;July.1&apos;)</source>
        <translation>Nëse doni, specifikoni një prapashtesë për ta shtuar te emri i muajit (p.sh., &apos;1&apos; për &apos;Korrik.1&apos;)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="120"/>
        <source>Don&apos;t calculate checksums for resulting ISO file</source>
        <translation>Mos përllogarit vlera checksum-i për kartelën ISO të përftuar</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="121"/>
        <source>Skip calculating free space to see if the resulting ISO will fit</source>
        <translation>Anashkalo përllogaritje hapësire të lirë për të parë nëse e nxë a jo ISO-n e prodhuar</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="122"/>
        <source>Option to fix issue with calculating checksums on preempt_rt kernels</source>
        <translation>Mundësi për të ndrequr problem me përllogaritje checksum-esh në kernela preempt_rt</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="123"/>
        <source>Resetting accounts (for distribution to others)</source>
        <translation>Po rikthehen llogaritë te parazgjedhjet (për shpërndarje të tjerëve)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="124"/>
        <source>Calculate checksums for resulting ISO file</source>
        <translation>Përllogarit vlera checksum-i për kartelën ISO të përftuar</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="126"/>
        <source>Throttle the I/O input rate by the given percentage. This can be used to reduce the I/O and CPU consumption of Mksquashfs.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="129"/>
        <source>Work directory</source>
        <translation>Drejtori pune</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="131"/>
        <source>Exclude main folders, valid choices: </source>
        <translation>Përjashtoni dosje kryesore, zgjedhje të vlefshme: </translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="133"/>
        <source>Use the option one time for each item you want to exclude</source>
        <translation>Përdoreni mundësinë një herë për çdo zë që doni të përjashtohet</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="136"/>
        <source>Compression format, valid choices: </source>
        <translation>Format ngjeshjeje, zgjedhje të vlefshme: </translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="138"/>
        <source>Shutdown computer when done.</source>
        <translation>Fikni kompjuterin, kur të ketë mbaruar.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="211"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Duket të keni hyrë si rrënjë, ju lutemi, që të përdorni këtë program, dilni dhe bëni hyrjen si përdorues normal.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="229"/>
        <source>version:</source>
        <translation>version:</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="223"/>
        <source>You must run this program with sudo or pkexec.</source>
        <translation>Këtë program duhet ta xhironi me sudo ose pkexec.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="206"/>
        <source>MX Snapshot</source>
        <translation>Fotografim MX Sistemi</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="213"/>
        <location filename="../src/main.cpp" line="281"/>
        <location filename="../src/settings.cpp" line="527"/>
        <location filename="../src/settings.cpp" line="535"/>
        <location filename="../src/settings.cpp" line="1065"/>
        <location filename="../src/settings.cpp" line="1159"/>
        <source>Error</source>
        <translation>Gabim</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="280"/>
        <location filename="../src/settings.cpp" line="534"/>
        <source>Current kernel doesn&apos;t support Squashfs, cannot continue.</source>
        <translation>Kerneli i tanishëm nuk mbulon Squashfs, s’vazhdohet dot.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="113"/>
        <source>Failed to initialize configuration</source>
        <translation>S’u arrit të bëhej gati formësimi</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="147"/>
        <source>Configuration validation failed</source>
        <translation>Vlerësimi i formësimit dështoi</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="152"/>
        <source>Exception during initialization: %1</source>
        <translation>Gabim gjatë gatitjeje: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="155"/>
        <source>Unknown exception during initialization</source>
        <translation>Gabim i panjohur gjatë gatitjeje</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="186"/>
        <source>Could not create work directory. </source>
        <translation>S’u krijua dot drejtori pune.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="210"/>
        <source>Could not create temp directory:</source>
        <translation>S’u krijua dot drejtori e përkohshme:</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="211"/>
        <source>Please check that the parent directory exists and is writable:</source>
        <translation>Ju lutemi, kontrolloni se drejtoria mëmë ekziston dhe është e shkrueshme:</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="229"/>
        <source>Compression format &apos;%1&apos; is not supported by the current kernel</source>
        <translation>Formati &apos;%1&apos; i ngjeshjeve nuk mbulohet nga kerneli i tanishëm</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="235"/>
        <source>Invalid cores setting: %1. Must be between 1 and %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="241"/>
        <source>Invalid throttle setting: %1. Must be between 0 and 20</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="247"/>
        <source>Snapshot directory cannot be empty</source>
        <translation>Drejtoria e fotografimeve të sistemit s’mund të jetë e zbrazët</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="255"/>
        <source>Snapshot name cannot be empty</source>
        <translation>Emri i fotografimit të sistemit s’mund të jetë i zbrazët</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="261"/>
        <source>Snapshot name contains invalid characters: %1</source>
        <translation>Emri i drejtorisë së fotografimeve të sistemit përmban një shenjë të pavlefshme: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="267"/>
        <source>Kernel version cannot be empty</source>
        <translation>Versioni i kernelit s’mund të jetë i zbrazët</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="272"/>
        <source>Kernel file not found: /boot/vmlinuz-%1</source>
        <translation>S’u gjet kartelë kerneli: /boot/vmlinuz-%1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="278"/>
        <source>Kernel %1 doesn&apos;t support Squashfs</source>
        <translation>Kerneli %1 nuk mbulon Squashfs</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="309"/>
        <source>Exclusion file does not exist: %1</source>
        <translation>Kartela e përjashtimeve s’ekziston: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="318"/>
        <source>Unbalanced quotes in exclusion list</source>
        <translation>Thonjëza të pambylluara te listë përjashtimesh</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="343"/>
        <source>Insufficient free space: %1 KiB available, minimum %2 KiB required</source>
        <translation>Hapësirë e lirë e pamjaftueshme: %1 KiB të lirë, minimum %2 KiB i domosdoshëm</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="350"/>
        <source>Insufficient free space in work directory: %1 KiB available, minimum %2 KiB required</source>
        <translation>Hapësirë e lirë e pamjaftueshme në drejtori pune: %1 KiB të lirë, minimum i domosdoshëm %2 KiB</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="365"/>
        <source>Failed to determine number of CPU cores</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="371"/>
        <source>Configuration file does not exist: %1</source>
        <translation>Kartela e formësimit s’ekziston: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="372"/>
        <source>Using default settings</source>
        <translation>Po përdoren rregullimet parazgjedhje</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="374"/>
        <source>Cannot read configuration file: %1</source>
        <translation>S’lexohet dot kartelë formësimi: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="375"/>
        <source>Error: %1</source>
        <translation>Gabim: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="385"/>
        <source>Required tool not found: %1</source>
        <translation>S’u gjet mjet i domosdoshëm: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="394"/>
        <source>Required directory not found: %1</source>
        <translation>S’u gjet drejtori e domosdoshme: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="413"/>
        <source>Initialization Error</source>
        <translation>Gabim Gatitjeje</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="414"/>
        <source>Failed to initialize application settings:

%1</source>
        <translation>S’u arrit të gatiten rregullime aplikacioni:

%1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="525"/>
        <source>Could not find a usable kernel</source>
        <translation>S’u gjet dot një kernel i përdorshëm</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="526"/>
        <source>Searched for kernel files in /boot/ but none were found or accessible.</source>
        <translation>U kërkua për kartela kerneli në /boot/, por s’u gjet ndonjë, apo e përdorshme.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="547"/>
        <source>No users found in the system</source>
        <translation>Te sistemi s’u gjetën përdorues</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="550"/>
        <source>Failed to determine system information</source>
        <translation>S’u arrit të përcaktohet informacion sistemi</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="644"/>
        <source>Used space on / (root): </source>
        <translation>Hapësirë e përdorur në / (rrënjë): </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="647"/>
        <source>estimated</source>
        <translation>afërsisht</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="656"/>
        <source>Used space on /home: </source>
        <translation>Hapësirë e përdorur në /home: </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="712"/>
        <source>Free space on %1, where snapshot folder is placed: </source>
        <translation>Hapësirë e lirë në %1, ku vendoset dosja e fotografimeve: </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="716"/>
        <source>The free space should be sufficient to hold the compressed data from / and /home

      If necessary, you can create more available space
      by removing previous snapshots and saved copies:
      %1 snapshots are taking up %2 of disk space.
</source>
        <translation>Hapësira e lirë duhet të jetë e mjaftueshme të mbajë të dhënat e ngjeshura të / dhe /home

      Në qoftë e nevojshme, mund të krijoni më tepër hapësirë
      duke hequr fotografime të mëparshme dhe kopje të ruajtura:
      %1 fotografime, që zënë %2 hapësirë në disk.
</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="730"/>
        <source>Desktop</source>
        <translation>Desktop</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="731"/>
        <source>Documents</source>
        <translation>Dokumente</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="732"/>
        <source>Downloads</source>
        <translation>Shkarkime</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="733"/>
        <source>Flatpaks</source>
        <translation>Paketime Flatpak</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="734"/>
        <source>Music</source>
        <translation>Muzikë</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="735"/>
        <source>Networks</source>
        <translation>Rrjete</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="736"/>
        <source>Pictures</source>
        <translation>Foto</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="738"/>
        <source>Videos</source>
        <translation>Video</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="887"/>
        <source>Error reading system configuration file: %1</source>
        <translation>Gabim në lexim kartele formësimi: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="895"/>
        <source>Error accessing user configuration</source>
        <translation>Gabim në hyrje te formësim përdoruesi</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="947"/>
        <source>Could not copy exclusion file from %1 to %2</source>
        <translation>S’u kopjua dot kartelë përjashtimesh nga %1 në %2</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="972"/>
        <source>Invalid stored cores setting (%1). Using detected CPU count: %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1063"/>
        <location filename="../src/settings.cpp" line="1157"/>
        <source>Output file %1 already exists. Please use another file name, or delete the existent file.</source>
        <translation>Kartela përfundim %1 ekziston tashmë. Ju lutemi, përdorni një tjetër emër kartele, ose fshini kartelën ekzistuese.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="70"/>
        <source>License</source>
        <translation>Licencë</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <location filename="../src/about.cpp" line="81"/>
        <source>Changelog</source>
        <translation>Regjistër ndryshimesh</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="72"/>
        <source>Cancel</source>
        <translation>Anuloje</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="94"/>
        <source>&amp;Close</source>
        <translation>&amp;Mbylle</translation>
    </message>
</context>
<context>
    <name>Work</name>
    <message>
        <location filename="../src/work.cpp" line="147"/>
        <source>Cleaning...</source>
        <translation>Po pastrohet…</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="163"/>
        <location filename="../src/work.cpp" line="420"/>
        <source>Done</source>
        <translation>U bë</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="175"/>
        <source>Interrupted or failed to complete</source>
        <translation>U ndërpre, ose s’u arrit të plotësohej</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="211"/>
        <location filename="../src/work.cpp" line="376"/>
        <location filename="../src/work.cpp" line="400"/>
        <location filename="../src/work.cpp" line="438"/>
        <location filename="../src/work.cpp" line="578"/>
        <location filename="../src/work.cpp" line="612"/>
        <location filename="../src/work.cpp" line="621"/>
        <location filename="../src/work.cpp" line="627"/>
        <source>Error</source>
        <translation>Gabim</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="212"/>
        <source>There&apos;s not enough free space on your target disk, you need at least %1</source>
        <translation>S’ka hapësirë të mjaftë të lirë në diskun ku synoni, ju duhen të paktën %1</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="215"/>
        <source>You have %1 free space on %2</source>
        <translation>Keni %1 hapësirë të lirë në %2</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="218"/>
        <source>If you are sure you have enough free space rerun the program with -o/--override-size option</source>
        <translation>Nëse jeni i sigurt se keni hapësirë të mjaftueshme, rixhironi programin me mundësinë -o/--override-size</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="304"/>
        <source>Copying the new-iso filesystem...</source>
        <translation>Po kopjohet sistemi i ri i kartelave ISO…</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="316"/>
        <source>Could not create temp directory. </source>
        <translation>S’u krijua dot drejtori e përkohshme. </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="373"/>
        <source>Squashing filesystem...</source>
        <translation>Po ngjishet sistemi i kartelave…</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="377"/>
        <source>Could not create linuxfs file, please check /var/log/%1.log</source>
        <translation>S’u krijua dot kartelë linuxfs, ju lutemi, shihni te /var/log/%1.log</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="397"/>
        <source>Creating CD/DVD image file...</source>
        <translation>Po krijohet kartelë pamje CD/DVD…</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="401"/>
        <source>Could not create ISO file, please check whether you have enough space on the destination partition.</source>
        <translation>S’u krijua dot kartelë ISO, ju lutemi, kontrolloni nëse keni hapësirë të mjaftueshme te pjesa e synuar.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="407"/>
        <source>Making hybrid iso</source>
        <translation>Po krijohet ISO hibride</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="425"/>
        <source>Success</source>
        <translation>Sukses</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="426"/>
        <source>MX Snapshot completed successfully!</source>
        <translation>MX Snapshot u plotësua me sukses!</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="427"/>
        <source>Snapshot took %1 to finish.</source>
        <translation>Fotografimit iu deshën %1 të plotësohet.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="428"/>
        <source>Thanks for using MX Snapshot, run MX Live USB Maker next!</source>
        <translation>Faleminderit që përdorni MX Snapshot, pas kësaj xhironi MX Live USB Maker!</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="435"/>
        <source>Installing </source>
        <translation>Po instalohet </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="438"/>
        <source>Could not install </source>
        <translation>S’u instalua dot </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="448"/>
        <source>Calculating checksum...</source>
        <translation>Po llogaritet vlera e checksum-it…</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="488"/>
        <source>Building new initrd...</source>
        <translation>Po ndërtohet initrd i ri…</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="579"/>
        <source>Could not create working directory. </source>
        <translation>S’u krijua dot drejtori pune. </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="613"/>
        <source>Could not prepare a safe bind-root overlay. Snapshot cannot continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="622"/>
        <location filename="../src/work.cpp" line="628"/>
        <source>Could not prepare the snapshot bind-root environment.</source>
        <translation>S’u përgatit dot mjedis bind-root fotografimi sistemi.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="931"/>
        <source>Calculating total size of excluded files...</source>
        <translation>Po njehsohet madhësia gjithsej e kartelave të përjashtuara…</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="957"/>
        <source>Calculating size of root...</source>
        <translation>Po njehsohet madhësia e rrënjës…</translation>
    </message>
</context>
</TS>