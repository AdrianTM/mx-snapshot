<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="zh_CN">
<context>
    <name>Batchprocessing</name>
    <message>
        <location filename="../src/batchprocessing.cpp" line="50"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="51"/>
        <source>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</source>
        <translation>当前内核不支持选择的压缩算法，请编辑配置文件并选择不同的算法。</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="76"/>
        <source>The program will pause the build and open the boot menu in your text editor.</source>
        <translation>程序将暂停构建并在你的文本编辑器中打开启动菜单。</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="157"/>
        <source>Detected newer exclusion file at %1 compared to %2. Prompting for action.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="163"/>
        <source>s</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'show diff'</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="164"/>
        <source>u</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'use updated default'</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="165"/>
        <source>k</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'keep custom (update timestamp)'</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="166"/>
        <source>q</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'quit'</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="168"/>
        <source>show diff</source>
        <comment>CLI excludes prompt option label</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="169"/>
        <source>use updated default</source>
        <comment>CLI excludes prompt option label</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="170"/>
        <source>keep custom (update timestamp)</source>
        <comment>CLI excludes prompt option label</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="171"/>
        <source>quit</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>退出</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="174"/>
        <source>[%1]%2  [%3]%4  [%5]%6  [%7]%8: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="179"/>
        <source>The exclusion file at %1 is newer than your configured file at %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="195"/>
        <source>Reverted to updated default exclusion file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="208"/>
        <source>Leaving custom exclusion file unchanged.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="219"/>
        <source>Invalid choice. Please select again.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="226"/>
        <source>This computer uses an NVIDIA graphics card. Are you planning to use the resulting ISO on the same computer or another computer with an NVIDIA card?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="236"/>
        <source>Note: If you use the resulting ISO on a computer without an NVIDIA card, you will likely need to remove &apos;xorg=nvidia&apos; from the boot options.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="239"/>
        <source>Note: If you use the resulting ISO on a computer with an NVIDIA card, you may need to add &apos;xorg=nvidia&apos; to the boot options.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="101"/>
        <source>No elevation tool found (pkexec/gksu/sudo).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="171"/>
        <source>Administrator Access Required</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="172"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <location filename="../src/mainwindow.cpp" line="380"/>
        <location filename="../src/mainwindow.cpp" line="759"/>
        <location filename="../src/ui_mainwindow.h" line="745"/>
        <source>MX Snapshot</source>
        <translation>MX Snapshot</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="33"/>
        <location filename="../src/ui_mainwindow.h" line="746"/>
        <source>Optional customization</source>
        <translation>可选定制项</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="65"/>
        <location filename="../src/ui_mainwindow.h" line="747"/>
        <source>Release version:</source>
        <translation>发布版本：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="79"/>
        <location filename="../src/ui_mainwindow.h" line="748"/>
        <source>Boot options:</source>
        <translation>启动选项：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="86"/>
        <location filename="../src/ui_mainwindow.h" line="749"/>
        <source>Live kernel:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="93"/>
        <location filename="../src/ui_mainwindow.h" line="750"/>
        <source>Project name:</source>
        <translation>项目名称：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="100"/>
        <location filename="../src/ui_mainwindow.h" line="751"/>
        <source>Release date:</source>
        <translation>发布日期：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="107"/>
        <location filename="../src/ui_mainwindow.h" line="752"/>
        <source>Release codename:</source>
        <translation>发布代号：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="133"/>
        <location filename="../src/ui_mainwindow.h" line="753"/>
        <source>Current date</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="172"/>
        <location filename="../src/ui_mainwindow.h" line="754"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Snapshot is a utility that creates a bootable image (ISO) of your working system that you can use for storage or distribution. You can continue working with undemanding applications while it is running.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Snapshot 是一种实用工具，可以为您的工作系统创建可引导镜像 (ISO)，您可以将其用于存储或分发。您可以在运行时继续使用要求不高的应用程序。&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="182"/>
        <location filename="../src/ui_mainwindow.h" line="755"/>
        <source>Used space on / (root) and /home partitions:</source>
        <translation>/ (root) 和 /home 分区上的已用空间：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="192"/>
        <location filename="../src/ui_mainwindow.h" line="756"/>
        <source>Location and ISO name</source>
        <translation>位置和 ISO 名称</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="219"/>
        <location filename="../src/ui_mainwindow.h" line="758"/>
        <source>Snapshot location:</source>
        <translation>快照位置：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="226"/>
        <location filename="../src/ui_mainwindow.h" line="759"/>
        <source>Select a different snapshot directory</source>
        <translation>选择不同的快照目录</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="236"/>
        <location filename="../src/mainwindow.cpp" line="575"/>
        <location filename="../src/ui_mainwindow.h" line="760"/>
        <source>Snapshot name:</source>
        <translation>快照名称：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="360"/>
        <location filename="../src/ui_mainwindow.h" line="764"/>
        <source>Type of snapshot:</source>
        <translation>快照类型：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="367"/>
        <location filename="../src/ui_mainwindow.h" line="765"/>
        <source>Preserving accounts (for personal backup)</source>
        <translation>保留帐户（用于个人备份）</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <location filename="../src/ui_mainwindow.h" line="767"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This option will reset &amp;quot;demo&amp;quot; and &amp;quot;root&amp;quot; passwords to the MX Linux defaults and will not copy any personal accounts created.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;此选项会将“demo”和“root”密码重置为 MX Linux 默认值，并且不会复制任何已创建的个人帐户。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="380"/>
        <location filename="../src/ui_mainwindow.h" line="769"/>
        <source>Resetting accounts (for distribution to others)</source>
        <translation>重置帐户（用于分发给他人）</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="451"/>
        <location filename="../src/ui_mainwindow.h" line="770"/>
        <source>You can also exclude certain directories by ticking the common choices below, or by clicking on the button to directly edit /etc/mx-snapshot-exclude.list.</source>
        <translation>您还可以通过勾选下面的常用选项来排除某些目录，或者通过单击按钮直接编辑 /etc/mx-snapshot-exclude.list。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="496"/>
        <location filename="../src/ui_mainwindow.h" line="771"/>
        <source>sha512</source>
        <translation>sha512</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="519"/>
        <location filename="../src/ui_mainwindow.h" line="773"/>
        <source>Throttle the I/O input rate by the given percentage.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="525"/>
        <location filename="../src/ui_mainwindow.h" line="775"/>
        <source>I/O throttle:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="532"/>
        <location filename="../src/ui_mainwindow.h" line="776"/>
        <source>Calculate checksums:</source>
        <translation>计算校验和：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="539"/>
        <location filename="../src/ui_mainwindow.h" line="777"/>
        <source>ISO compression scheme:</source>
        <translation>ISO压缩方案：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="546"/>
        <location filename="../src/ui_mainwindow.h" line="778"/>
        <source>Number of CPU cores to use:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="553"/>
        <location filename="../src/ui_mainwindow.h" line="779"/>
        <source>md5</source>
        <translation>md5</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="563"/>
        <location filename="../src/ui_mainwindow.h" line="780"/>
        <source>Options:</source>
        <translation>选项：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="610"/>
        <location filename="../src/ui_mainwindow.h" line="781"/>
        <source>Edit Exclusion File</source>
        <translation>编辑排除文件</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="626"/>
        <location filename="../src/mainwindow.cpp" line="779"/>
        <location filename="../src/ui_mainwindow.h" line="782"/>
        <source>Remove Custom Exclusion File</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="679"/>
        <location filename="../src/ui_mainwindow.h" line="783"/>
        <source>Pictures</source>
        <translation>图片</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="686"/>
        <location filename="../src/ui_mainwindow.h" line="784"/>
        <source>Videos</source>
        <translation>视频</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="693"/>
        <location filename="../src/ui_mainwindow.h" line="785"/>
        <source>All of the above</source>
        <translation>以上全部</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="700"/>
        <location filename="../src/ui_mainwindow.h" line="787"/>
        <source>exclude network configurations</source>
        <translation>排除网络配置</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="703"/>
        <location filename="../src/ui_mainwindow.h" line="789"/>
        <source>Networks</source>
        <translation>网络</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="710"/>
        <location filename="../src/ui_mainwindow.h" line="790"/>
        <source>Downloads</source>
        <translation>下载</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="717"/>
        <location filename="../src/ui_mainwindow.h" line="791"/>
        <source>Desktop</source>
        <translation>桌面</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="724"/>
        <location filename="../src/ui_mainwindow.h" line="792"/>
        <source>Documents</source>
        <translation>文档</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="731"/>
        <location filename="../src/ui_mainwindow.h" line="793"/>
        <source>Flatpaks</source>
        <translation>Flatpaks</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="738"/>
        <location filename="../src/ui_mainwindow.h" line="794"/>
        <source>Music</source>
        <translation>音乐</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="850"/>
        <location filename="../src/ui_mainwindow.h" line="797"/>
        <source>About this application</source>
        <translation>关于此软件</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="853"/>
        <location filename="../src/ui_mainwindow.h" line="799"/>
        <source>About...</source>
        <translation>关于…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="859"/>
        <location filename="../src/ui_mainwindow.h" line="801"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="875"/>
        <location filename="../src/ui_mainwindow.h" line="803"/>
        <source>Next</source>
        <translation>下一页</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="900"/>
        <location filename="../src/ui_mainwindow.h" line="808"/>
        <source>Display help </source>
        <translation>显示帮助</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="903"/>
        <location filename="../src/ui_mainwindow.h" line="810"/>
        <source>Help</source>
        <translation>帮助</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="909"/>
        <location filename="../src/ui_mainwindow.h" line="812"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="922"/>
        <location filename="../src/ui_mainwindow.h" line="815"/>
        <source>Quit application</source>
        <translation>退出应用程序</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="925"/>
        <location filename="../src/ui_mainwindow.h" line="817"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="931"/>
        <location filename="../src/ui_mainwindow.h" line="819"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="985"/>
        <location filename="../src/ui_mainwindow.h" line="822"/>
        <source>Back</source>
        <translation>后退</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="342"/>
        <source>Select Release Date</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="386"/>
        <source>fastest, worst compression</source>
        <translation>最快，最差的压缩</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="386"/>
        <source>fast, worse compression</source>
        <translation>快速，较差的压缩</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="387"/>
        <source>slow, better compression</source>
        <translation>慢，更好的压缩</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="387"/>
        <source>best compromise</source>
        <translation>最好的这种</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="388"/>
        <source>slowest, best compression</source>
        <translation>最慢，最好的压缩</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="417"/>
        <source>Free space on %1, where snapshot folder is placed: </source>
        <translation>%1 上的可用空间，其中放置快照文件夹:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="420"/>
        <source>The free space should be sufficient to hold the compressed data from / and /home

      If necessary, you can create more available space by removing previous snapshots and saved copies: %1 snapshots are taking up %2 of disk space.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="432"/>
        <location filename="../src/mainwindow.cpp" line="433"/>
        <source>Installing </source>
        <translation>正在安装</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="518"/>
        <source>Please wait.</source>
        <translation>请稍等。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="520"/>
        <source>Please wait. Calculating used disk space...</source>
        <translation>请稍等。正在计算已用磁盘空间...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="271"/>
        <location filename="../src/mainwindow.cpp" line="554"/>
        <location filename="../src/mainwindow.cpp" line="561"/>
        <location filename="../src/mainwindow.cpp" line="643"/>
        <location filename="../src/mainwindow.cpp" line="654"/>
        <location filename="../src/mainwindow.cpp" line="844"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="171"/>
        <location filename="../src/mainwindow.cpp" line="207"/>
        <source>Updated Exclusion List</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="174"/>
        <source>The exclusion file at %1 is newer than your configured file at %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="176"/>
        <source>Review the changes below. Keep your custom file or replace it with the updated default.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="182"/>
        <source>Show Differences</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="188"/>
        <source>Keep Custom</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="194"/>
        <source>Use Updated Default</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="555"/>
        <source>Output file %1 already exists. Please use another file name, or delete the existent file.</source>
        <translation>输出文件 %1 已经存在。请使用其他文件名，或删除现有文件。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="562"/>
        <source>Insufficient free space. Please select a different snapshot directory or free up space.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="566"/>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="572"/>
        <source>Snapshot will use the following settings:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="574"/>
        <source>- Snapshot directory:</source>
        <translation>- 快照目录：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="575"/>
        <source>- Kernel to be used:</source>
        <translation>- 要使用的内核：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="599"/>
        <location filename="../src/mainwindow.cpp" line="608"/>
        <source>NVIDIA Detected</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="600"/>
        <source>This computer uses an NVIDIA graphics card. Are you planning to use the resulting ISO on the same computer or another computer with an NVIDIA card?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="604"/>
        <source>NVIDIA Selected</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="605"/>
        <source>Note: If you use the resulting ISO on a computer without an NVIDIA card, you will likely need to remove &apos;xorg=nvidia&apos; from the boot options.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="609"/>
        <source>Note: If you use the resulting ISO on a computer with an NVIDIA card, you may need to add &apos;xorg=nvidia&apos; to the boot options.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="272"/>
        <location filename="../src/mainwindow.cpp" line="644"/>
        <source>Could not replace the exclusion file with the updated default.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="655"/>
        <source>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</source>
        <translation>当前内核不支持选择的压缩算法，请编辑配置文件并选择不同的算法。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="678"/>
        <source>Final chance</source>
        <translation>最后确认</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="680"/>
        <source>Snapshot now has all the information it needs to create an ISO from your running system.</source>
        <translation>Snapshot 现在拥有从正在运行的系统创建 ISO 所需的所有信息。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="681"/>
        <source>It will take some time to finish, depending on the size of the installed system and the capacity of your computer.</source>
        <translation>这将需要一些时间才能完成，具体时长取决于已安装系统的大小和计算机的容量。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="683"/>
        <source>OK to start?</source>
        <translation>准备好要开始了吗？</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="687"/>
        <source>Shutdown computer when done.</source>
        <translation>完成后关闭计算机。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="720"/>
        <source>Output</source>
        <translation>输出</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="736"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="743"/>
        <source>Edit Boot Menu</source>
        <translation>编辑启动菜单</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="744"/>
        <source>The program will now pause to allow you to edit any files in the work directory. Select Yes to edit the boot menu or select No to bypass this step and continue creating the snapshot.</source>
        <translation>程序现在将暂停以允许您编辑工作目录中的任何文件。选择“是”来编辑启动菜单或选择“否”绕过此步骤并继续创建快照。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="780"/>
        <source>Revert the exclusion list to the default file? This will overwrite your current exclusions.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="812"/>
        <source>About %1</source>
        <translation>关于 %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="814"/>
        <source>Version: </source>
        <translation>版本:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="815"/>
        <source>Program for creating a live-CD from the running system for MX Linux</source>
        <translation>从正在运行的 MX Linux 系统创建 live-CD 的程序</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="817"/>
        <source>Copyright (c) MX Linux</source>
        <translation>版权所有(c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="819"/>
        <source>%1 License</source>
        <translation>%1 许可证</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="832"/>
        <source>%1 Help</source>
        <translation>%1 帮助</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="837"/>
        <source>Select Snapshot Directory</source>
        <translation>选择快照目录</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="845"/>
        <source>Insufficient free space in the selected directory. Please choose a different location.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="865"/>
        <source>Confirmation</source>
        <translation>确认</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="865"/>
        <source>Are you sure you want to quit the application?</source>
        <translation>您确定要退出吗？</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/main.cpp" line="95"/>
        <source>Tool used for creating a live-CD from the running system</source>
        <translation>用于从正在运行的系统创建 live-CD 的工具</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="99"/>
        <source>Use CLI only</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="103"/>
        <source>Number of CPU cores to be used.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="104"/>
        <source>Output directory</source>
        <translation>输出目录</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="105"/>
        <source>Output filename</source>
        <translation>输出文件名</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="107"/>
        <source>Name a different kernel to use other than the default running kernel, use format returned by &apos;uname -r&apos;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="109"/>
        <source>Or the full path: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="112"/>
        <source>Compression level options.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>Use quotes: &quot;-Xcompression-level &lt;level&gt;&quot;, or &quot;-Xalgorithm &lt;algorithm&gt;&quot;, or &quot;-Xhc&quot;, see mksquashfs man page</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="117"/>
        <source>Create a monthly snapshot, add &apos;Month&apos; name in the ISO name, skip used space calculation</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="118"/>
        <source>This option sets reset-accounts and compression to defaults, arguments changing those items will be ignored</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="120"/>
        <source>Optionally specify a suffix to add to the month name (e.g., &apos;1&apos; for &apos;July.1&apos;)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="121"/>
        <source>Don&apos;t calculate checksums for resulting ISO file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="122"/>
        <source>Skip calculating free space to see if the resulting ISO will fit</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="123"/>
        <source>Option to fix issue with calculating checksums on preempt_rt kernels</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="124"/>
        <source>Resetting accounts (for distribution to others)</source>
        <translation>重置帐户（用于分发给他人）</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="125"/>
        <source>Calculate checksums for resulting ISO file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="127"/>
        <source>Throttle the I/O input rate by the given percentage. This can be used to reduce the I/O and CPU consumption of Mksquashfs.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="130"/>
        <source>Work directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="132"/>
        <source>Exclude main folders, valid choices: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="134"/>
        <source>Use the option one time for each item you want to exclude</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="137"/>
        <source>Compression format, valid choices: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="139"/>
        <source>Shutdown computer when done.</source>
        <translation>完成后关闭计算机。</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="140"/>
        <source>Use grub for legacy mbr iso boot instead of isolinux/syslinux.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="214"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>您似乎是以 root 身份登录的，请注销并以普通用户身份登录以使用该程序。</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="232"/>
        <source>version:</source>
        <translation>版本：</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="226"/>
        <source>You must run this program with sudo or pkexec.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="209"/>
        <source>MX Snapshot</source>
        <translation>MX Snapshot</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="216"/>
        <location filename="../src/main.cpp" line="284"/>
        <location filename="../src/settings.cpp" line="525"/>
        <location filename="../src/settings.cpp" line="533"/>
        <location filename="../src/settings.cpp" line="1039"/>
        <location filename="../src/settings.cpp" line="1133"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="283"/>
        <location filename="../src/settings.cpp" line="532"/>
        <source>Current kernel doesn&apos;t support Squashfs, cannot continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="98"/>
        <source>Failed to initialize configuration</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="132"/>
        <source>Configuration validation failed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="137"/>
        <source>Exception during initialization: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="140"/>
        <source>Unknown exception during initialization</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="171"/>
        <source>Could not create work directory. </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="198"/>
        <source>Could not create temp directory:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="199"/>
        <source>Please check that the parent directory exists and is writable:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="217"/>
        <source>Compression format &apos;%1&apos; is not supported by the current kernel</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="223"/>
        <source>Invalid cores setting: %1. Must be between 1 and %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="229"/>
        <source>Invalid throttle setting: %1. Must be between 0 and 20</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="235"/>
        <source>Snapshot directory cannot be empty</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="243"/>
        <source>Snapshot name cannot be empty</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="249"/>
        <source>Snapshot name contains invalid characters: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="255"/>
        <source>Kernel version cannot be empty</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="260"/>
        <source>Kernel file not found: /boot/vmlinuz-%1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="266"/>
        <source>Kernel %1 doesn&apos;t support Squashfs</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="297"/>
        <source>Exclusion file does not exist: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="306"/>
        <source>Unbalanced quotes in exclusion list</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="331"/>
        <source>Insufficient free space: %1 KiB available, minimum %2 KiB required</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="338"/>
        <source>Insufficient free space in work directory: %1 KiB available, minimum %2 KiB required</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="353"/>
        <source>Failed to determine number of CPU cores</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="359"/>
        <source>Configuration file does not exist: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="360"/>
        <source>Using default settings</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="362"/>
        <source>Cannot read configuration file: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="363"/>
        <source>Error: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="373"/>
        <source>Required tool not found: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="382"/>
        <source>Required directory not found: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="401"/>
        <source>Initialization Error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="402"/>
        <source>Failed to initialize application settings:

%1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="523"/>
        <source>Could not find a usable kernel</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="524"/>
        <source>Searched for kernel files in /boot/ but none were found or accessible.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="545"/>
        <source>No users found in the system</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="548"/>
        <source>Failed to determine system information</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="642"/>
        <source>Used space on / (root): </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="645"/>
        <source>estimated</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="654"/>
        <source>Used space on /home: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="710"/>
        <source>Free space on %1, where snapshot folder is placed: </source>
        <translation>%1 上的可用空间，其中放置快照文件夹:</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="714"/>
        <source>The free space should be sufficient to hold the compressed data from / and /home

      If necessary, you can create more available space
      by removing previous snapshots and saved copies:
      %1 snapshots are taking up %2 of disk space.
</source>
        <translation>可用空间应足以容纳来自 / 和 /home 的压缩数据

  如有必要，您可以创建更多可用空间
  通过删除以前的快照和保存的副本：
  %1 个快照占用了 %2 的磁盘空间。</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="728"/>
        <source>Desktop</source>
        <translation>桌面</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="729"/>
        <source>Documents</source>
        <translation>文档</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="730"/>
        <source>Downloads</source>
        <translation>下载</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="731"/>
        <source>Flatpaks</source>
        <translation>Flatpaks</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="732"/>
        <source>Music</source>
        <translation>音乐</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="733"/>
        <source>Networks</source>
        <translation>网络</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="734"/>
        <source>Pictures</source>
        <translation>图片</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="736"/>
        <source>Videos</source>
        <translation>视频</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="861"/>
        <source>Error reading system configuration file: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="869"/>
        <source>Error accessing user configuration</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="921"/>
        <source>Could not copy exclusion file from %1 to %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="946"/>
        <source>Invalid stored cores setting (%1). Using detected CPU count: %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1037"/>
        <location filename="../src/settings.cpp" line="1131"/>
        <source>Output file %1 already exists. Please use another file name, or delete the existent file.</source>
        <translation>输出文件 %1 已经存在。请使用其他文件名，或删除现有文件。</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="73"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>License</source>
        <translation>许可证</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <location filename="../src/about.cpp" line="107"/>
        <source>Changelog</source>
        <translation>更新日志</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="98"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="119"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="53"/>
        <location filename="../src/about.cpp" line="122"/>
        <source>&amp;Close</source>
        <translation>关闭(&amp;C)</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="77"/>
        <source>No diff output available.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="89"/>
        <source>Default exclusion file not found at %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="101"/>
        <source>Could not backup existing exclusion file to %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="105"/>
        <source>Could not remove existing exclusion file at %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="112"/>
        <source>Could not copy default exclusion file from %1 to %2.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Work</name>
    <message>
        <location filename="../src/work.cpp" line="178"/>
        <source>Cleaning...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="194"/>
        <location filename="../src/work.cpp" line="497"/>
        <source>Done</source>
        <translation>完成</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="206"/>
        <source>Interrupted or failed to complete</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="242"/>
        <location filename="../src/work.cpp" line="355"/>
        <location filename="../src/work.cpp" line="440"/>
        <location filename="../src/work.cpp" line="477"/>
        <location filename="../src/work.cpp" line="515"/>
        <location filename="../src/work.cpp" line="656"/>
        <location filename="../src/work.cpp" line="690"/>
        <location filename="../src/work.cpp" line="703"/>
        <location filename="../src/work.cpp" line="711"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="243"/>
        <source>There&apos;s not enough free space on your target disk, you need at least %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="246"/>
        <source>You have %1 free space on %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="249"/>
        <source>If you are sure you have enough free space rerun the program with -o/--override-size option</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="335"/>
        <source>Copying the new-iso filesystem...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="356"/>
        <source>--grub-mbr option specified but boot/grub/i386-pc/eltorito.img is missing from iso-template</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="368"/>
        <source>Could not create temp directory. </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="437"/>
        <source>Squashing filesystem...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="441"/>
        <source>Could not create linuxfs file, please check /var/log/%1.log</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="474"/>
        <source>Creating CD/DVD image file...</source>
        <translation>创建 CD/DVD 镜像文件...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="478"/>
        <source>Could not create ISO file, please check whether you have enough space on the destination partition.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="484"/>
        <source>Making hybrid iso</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="502"/>
        <source>Success</source>
        <translation>成功</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="503"/>
        <source>MX Snapshot completed successfully!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="504"/>
        <source>Snapshot took %1 to finish.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="505"/>
        <source>Thanks for using MX Snapshot, run MX Live USB Maker next!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="512"/>
        <source>Installing </source>
        <translation>正在安装</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="515"/>
        <source>Could not install </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="525"/>
        <source>Calculating checksum...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="566"/>
        <source>Building new initrd...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="657"/>
        <source>Could not create working directory. </source>
        <translation>无法创建工作目录。</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="691"/>
        <source>Could not prepare a safe bind-root overlay. Snapshot cannot continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="704"/>
        <location filename="../src/work.cpp" line="712"/>
        <source>Could not prepare the snapshot bind-root environment.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1018"/>
        <source>Calculating total size of excluded files...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1044"/>
        <source>Calculating size of root...</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>