<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="es_ES">
<context>
    <name>Batchprocessing</name>
    <message>
        <location filename="../src/batchprocessing.cpp" line="50"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="51"/>
        <source>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</source>
        <translation>El kernel actual no admite el algoritmo de compresión seleccionado, edite el archivo de configuración y seleccione un algoritmo diferente.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="88"/>
        <source>The program will pause the build and open the boot menu in your text editor.</source>
        <translation>El programa pausará la compilación y abrirá el menú de inicio en su editor de texto.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="169"/>
        <source>Detected newer exclusion file at %1 compared to %2. Prompting for action.</source>
        <translation>Se ha detectado un archivo de exclusión más reciente en %1 en comparación con %2. Se solicita una acción.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="175"/>
        <source>s</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'show diff'</comment>
        <translation>s</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="176"/>
        <source>u</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'use updated default'</comment>
        <translation>u</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="177"/>
        <source>k</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'keep custom (update timestamp)'</comment>
        <translation>k</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="178"/>
        <source>q</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'quit'</comment>
        <translation>q</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="180"/>
        <source>show diff</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>Mostrar diferencias</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="181"/>
        <source>use updated default</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>usar actualizado por defecto</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="182"/>
        <source>keep custom (update timestamp)</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>mantener la personalización (actualizar la marca de tiempo)</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="183"/>
        <source>quit</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>salir</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="186"/>
        <source>[%1]%2  [%3]%4  [%5]%6  [%7]%8: </source>
        <translation>[%1]%2  [%3]%4  [%5]%6  [%7]%8: </translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="191"/>
        <source>The exclusion file at %1 is newer than your configured file at %2.</source>
        <translation>El archivo de exclusión en %1 es más reciente que el archivo configurado en %2.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="207"/>
        <source>Reverted to updated default exclusion file.</source>
        <translation>Se ha vuelto al archivo de exclusión por defecto actualizado.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="220"/>
        <source>Leaving custom exclusion file unchanged.</source>
        <translation>Dejar el archivo de exclusión personalizado sin cambios.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="231"/>
        <source>Invalid choice. Please select again.</source>
        <translation>Selección no válida. Vuelva a seleccionar.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="238"/>
        <source>This computer uses an NVIDIA graphics card. Are you planning to use the resulting ISO on the same computer or another computer with an NVIDIA card?</source>
        <translation>Este ordenador utiliza una tarjeta gráfica NVIDIA. ¿Planea utilizar la ISO resultante en el mismo ordenador o en otro ordenador con una tarjeta NVIDIA?</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="248"/>
        <source>Note: If you use the resulting ISO on a computer without an NVIDIA card, you will likely need to remove &apos;xorg=nvidia&apos; from the boot options.</source>
        <translation>Nota: Si utiliza la ISO resultante en un ordenador sin tarjeta NVIDIA, es probable que tenga que eliminar &apos;xorg=nvidia&apos; de las opciones de arranque.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="251"/>
        <source>Note: If you use the resulting ISO on a computer with an NVIDIA card, you may need to add &apos;xorg=nvidia&apos; to the boot options.</source>
        <translation>Nota: Si utiliza la ISO resultante en un ordenador con una tarjeta NVIDIA, puede que necesite añadir &apos;xorg=nvidia&apos; a las opciones de arranque.</translation>
    </message>
</context>
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="142"/>
        <source>No elevation tool found (pkexec/gksu/sudo).</source>
        <translation>No se ha encontrado ninguna herramienta de elevación de privilegios (pkexec/gksu/sudo).</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="231"/>
        <source>Administrator Access Required</source>
        <translation>Se requiere acceso de administrador</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="232"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation>Esta operación requiere privilegios de administrador. Reinicia la aplicación e ingresa tu contraseña cuando se te solicite.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <location filename="../src/mainwindow.cpp" line="391"/>
        <location filename="../src/mainwindow.cpp" line="843"/>
        <source>MX Snapshot</source>
        <translation>MX Snapshot</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="33"/>
        <source>Optional customization</source>
        <translation>Personalización opcional</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="65"/>
        <source>Release version:</source>
        <translation>Versión de lanzamiento:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="79"/>
        <source>Boot options:</source>
        <translation>Opciones de arranque:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="86"/>
        <source>Live kernel:</source>
        <translation>Kernel live:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="93"/>
        <source>Project name:</source>
        <translation>Nombre del proyecto:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="100"/>
        <source>Release date:</source>
        <translation>Fecha de publicación:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="107"/>
        <source>Release codename:</source>
        <translation>Nombre clave del proyecto:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="133"/>
        <source>Current date</source>
        <translation>Fecha actual</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="172"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Snapshot is a utility that creates a bootable image (ISO) of your working system that you can use for storage or distribution. You can continue working with undemanding applications while it is running.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Snapshot es una utilidad que crea una imagen de arranque (ISO) de su sistema de trabajo que puede usar para almacenamiento o distribución. Puede seguir trabajando con aplicaciones poco exigentes mientras se ejecuta..&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="182"/>
        <source>Used space on / (root) and /home partitions:</source>
        <translation>Espacio usado en las particiones / (root) y /home:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="192"/>
        <source>Location and ISO name</source>
        <translation>Ubicación y nombre de la ISO</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="219"/>
        <source>Snapshot location:</source>
        <translation>Ubicación de la imagen:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="226"/>
        <source>Select a different snapshot directory</source>
        <translation>Seleccione un directorio de imagen diferente</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="236"/>
        <location filename="../src/mainwindow.cpp" line="607"/>
        <source>Snapshot name:</source>
        <translation>Nombre de la imagen:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="360"/>
        <source>Type of snapshot:</source>
        <translation>Tipo de imagen del sistema:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="367"/>
        <source>Preserving accounts (for personal backup)</source>
        <translation>Conservación de cuentas (para respaldo personal)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This option will reset &amp;quot;demo&amp;quot; and &amp;quot;root&amp;quot; passwords to the MX Linux defaults and will not copy any personal accounts created.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Esta opción restablecerá las contraseñas &amp;quot;demo&amp;quot; y &amp;quot;root&amp;quot; a los valores predeterminados de MX Linux y no copiará ninguna cuenta personal creada.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="380"/>
        <source>Resetting accounts (for distribution to others)</source>
        <translation>Restablecimiento de cuentas (para distribuir a otros)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="451"/>
        <source>You can also exclude certain directories by ticking the common choices below, or by clicking on the button to directly edit /etc/mx-snapshot-exclude.list.</source>
        <translation>También puede excluir ciertos directorios marcando las opciones comunes a continuación, o haciendo clic en el botón para editar directamente /etc/mx-snapshot-exclude.list.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="496"/>
        <source>sha512</source>
        <translation>sha512</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="519"/>
        <source>Throttle the I/O input rate by the given percentage.</source>
        <translation>Regula la tasa de entrada de E/S en el porcentaje dado.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="525"/>
        <source>I/O throttle:</source>
        <translation>Regulador de E/S:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="532"/>
        <source>Calculate checksums:</source>
        <translation>Calcular sumas de comprobación:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="539"/>
        <source>ISO compression scheme:</source>
        <translation>Esquema de compresión ISO:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="546"/>
        <source>Number of CPU cores to use:</source>
        <translation>Número de núcleos de CPU utilizables:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="553"/>
        <source>md5</source>
        <translation>md5</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="563"/>
        <source>Options:</source>
        <translation>Opciones:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="610"/>
        <source>Edit Exclusion File</source>
        <translation>Editar archivo de exclusión</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="626"/>
        <location filename="../src/mainwindow.cpp" line="863"/>
        <source>Remove Custom Exclusion File</source>
        <translation>Eliminar archivo de exclusión personalizado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="679"/>
        <source>Pictures</source>
        <translation>Imágenes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="686"/>
        <source>Videos</source>
        <translation>Videos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="693"/>
        <source>All of the above</source>
        <translation>Todos los anteriores</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="700"/>
        <source>exclude network configurations</source>
        <translation>excluir configuraciones de red</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="703"/>
        <source>Networks</source>
        <translation>Redes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="710"/>
        <source>Downloads</source>
        <translation>Descargas</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="717"/>
        <source>Desktop</source>
        <translation>Escritorio</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="724"/>
        <source>Documents</source>
        <translation>Documentos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="731"/>
        <source>Flatpaks</source>
        <translation>Flatpaks</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="738"/>
        <source>Music</source>
        <translation>Música</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="876"/>
        <source>About this application</source>
        <translation>Acerca de esta aplicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="879"/>
        <source>About...</source>
        <translation>Acerca de...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="885"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="901"/>
        <source>Next</source>
        <translation>Siguiente</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="926"/>
        <source>Display help </source>
        <translation>Mostrar la ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="929"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="935"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="948"/>
        <source>Quit application</source>
        <translation>Salir de la aplicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="951"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="957"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1011"/>
        <source>Back</source>
        <translation>Atras</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="353"/>
        <source>Select Release Date</source>
        <translation>Seleccione la fecha de publicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="397"/>
        <source>fastest, worst compression</source>
        <translation>más rápida, peor compresión</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="397"/>
        <source>fast, worse compression</source>
        <translation>rápida, peor compresión</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="398"/>
        <source>slow, better compression</source>
        <translation>lenta, mejor compresión</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="398"/>
        <source>best compromise</source>
        <translation>el mejor compromiso</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="399"/>
        <source>slowest, best compression</source>
        <translation>más lento, mejor compresión</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="428"/>
        <source>Free space on %1, where snapshot folder is placed: </source>
        <translation>Espacio libre en %1, donde se colocará la imagen del sistema: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="431"/>
        <source>The free space should be sufficient to hold the compressed data from / and /home

      If necessary, you can create more available space by removing previous snapshots and saved copies: %1 snapshots are taking up %2 of disk space.</source>
        <translation>El espacio libre debe ser suficiente para contener los datos comprimidos de / y /home

      Si es necesario, puede crear más espacio disponible eliminando instantáneas anteriores y copias guardadas: %1 instantáneas están ocupando %2 de espacio en disco.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="443"/>
        <location filename="../src/mainwindow.cpp" line="444"/>
        <source>Installing </source>
        <translation>Instalando </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="550"/>
        <source>Please wait.</source>
        <translation>Espere por favor.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="552"/>
        <source>Please wait. Calculating used disk space...</source>
        <translation>Espere por favor. Calculando el espacio usado en el disco...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="274"/>
        <location filename="../src/mainwindow.cpp" line="586"/>
        <location filename="../src/mainwindow.cpp" line="593"/>
        <location filename="../src/mainwindow.cpp" line="675"/>
        <location filename="../src/mainwindow.cpp" line="686"/>
        <location filename="../src/mainwindow.cpp" line="928"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="174"/>
        <location filename="../src/mainwindow.cpp" line="210"/>
        <source>Updated Exclusion List</source>
        <translation>Lista de exclusión actualizada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="177"/>
        <source>The exclusion file at %1 is newer than your configured file at %2.</source>
        <translation>El archivo de exclusión en %1 es más reciente que el archivo configurado en %2.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="179"/>
        <source>Review the changes below. Keep your custom file or replace it with the updated default.</source>
        <translation>Revise los cambios a continuación. Conserve su archivo personalizado o sustitúyalo por el predeterminado actualizado.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="185"/>
        <source>Show Differences</source>
        <translation>Mostrar diferencias</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="191"/>
        <source>Keep Custom</source>
        <translation>Mantener personalización</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="197"/>
        <source>Use Updated Default</source>
        <translation>Usar actualizado por defecto</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="498"/>
        <source>Done</source>
        <translation>Hecho</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="587"/>
        <source>Output file %1 already exists. Please use another file name, or delete the existent file.</source>
        <translation>El archivo de salida %1 ya existe. Por favor, utilice otro nombre de archivo o elimine el archivo existente.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="594"/>
        <source>Insufficient free space. Please select a different snapshot directory or free up space.</source>
        <translation>Espacio libre insuficiente. Seleccione un directorio de instantáneas diferente o libere espacio.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="598"/>
        <source>Settings</source>
        <translation>Configuración</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="604"/>
        <source>Snapshot will use the following settings:</source>
        <translation>Snapshot utilizará la siguiente configuración:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="606"/>
        <source>- Snapshot directory:</source>
        <translation>- Directorio de la imagen:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="607"/>
        <source>- Kernel to be used:</source>
        <translation>- Kernel a usar:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="631"/>
        <location filename="../src/mainwindow.cpp" line="640"/>
        <source>NVIDIA Detected</source>
        <translation>NVIDIA detectada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="632"/>
        <source>This computer uses an NVIDIA graphics card. Are you planning to use the resulting ISO on the same computer or another computer with an NVIDIA card?</source>
        <translation>Este ordenador utiliza una tarjeta gráfica NVIDIA. ¿Planea utilizar la ISO resultante en el mismo ordenador o en otro ordenador con una tarjeta NVIDIA?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="636"/>
        <source>NVIDIA Selected</source>
        <translation>NVIDIA Seleccionada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="637"/>
        <source>Note: If you use the resulting ISO on a computer without an NVIDIA card, you will likely need to remove &apos;xorg=nvidia&apos; from the boot options.</source>
        <translation>Nota: Si utiliza la ISO resultante en un ordenador sin tarjeta NVIDIA, es probable que tenga que eliminar &apos;xorg=nvidia&apos; de las opciones de arranque.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="641"/>
        <source>Note: If you use the resulting ISO on a computer with an NVIDIA card, you may need to add &apos;xorg=nvidia&apos; to the boot options.</source>
        <translation>Nota: Si utiliza la ISO resultante en un ordenador con una tarjeta NVIDIA, puede que necesite añadir &apos;xorg=nvidia&apos; a las opciones de arranque.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="275"/>
        <location filename="../src/mainwindow.cpp" line="676"/>
        <source>Could not replace the exclusion file with the updated default.</source>
        <translation>No se pudo reemplazar el archivo de exclusión con el por defecto actualizado.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="687"/>
        <source>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</source>
        <translation>El kernel actual no admite el algoritmo de compresión seleccionado, edite el archivo de configuración y seleccione un algoritmo diferente.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="710"/>
        <source>Final chance</source>
        <translation>Ultima oportunidad</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="712"/>
        <source>Snapshot now has all the information it needs to create an ISO from your running system.</source>
        <translation>Snapshot ahora tiene toda la información que necesita para crear una imagen ISO desde su sistema en ejecución.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="713"/>
        <source>It will take some time to finish, depending on the size of the installed system and the capacity of your computer.</source>
        <translation>Tardara un tiempo en finalizar, dependiendo del tamaño del sistema instalado y la capacidad de su computadora.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="715"/>
        <source>OK to start?</source>
        <translation>¿Acepta comenzar?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="824"/>
        <location filename="../src/mainwindow.cpp" line="719"/>
        <source>Shutdown computer when done.</source>
        <translation>Apagar el ordenador al finalizar.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="753"/>
        <source>Output</source>
        <translation>Salida</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="773"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="827"/>
        <source>Edit Boot Menu</source>
        <translation>Editar el Menú de Arranque</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="828"/>
        <source>The program will now pause to allow you to edit any files in the work directory. Select Yes to edit the boot menu or select No to bypass this step and continue creating the snapshot.</source>
        <translation>El programa ahora se detendrá para permitirle editar cualquier archivo en el directorio de trabajo. Seleccione Sí para editar el menú de arranque o seleccione No para omitir este paso y continuar creando la imagen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="864"/>
        <source>Revert the exclusion list to the default file? This will overwrite your current exclusions.</source>
        <translation>¿Desea restablecer la lista de exclusiones al archivo por defecto? Esto sobrescribirá sus exclusiones actuales.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="896"/>
        <source>About %1</source>
        <translation>Acerca de %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="898"/>
        <source>Version: </source>
        <translation>Versión: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="899"/>
        <source>Program for creating a live-CD from the running system for MX Linux</source>
        <translation>Programa para crear un live-CD del sistema actual de MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="901"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="903"/>
        <source>%1 License</source>
        <translation>%1 Licencia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="916"/>
        <source>%1 Help</source>
        <translation>%1 Ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="921"/>
        <source>Select Snapshot Directory</source>
        <translation>Seleccionar directorio de la imagen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="929"/>
        <source>Insufficient free space in the selected directory. Please choose a different location.</source>
        <translation>Espacio libre insuficiente en el directorio seleccionado. Elija una ubicación diferente.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="973"/>
        <source>Confirmation</source>
        <translation>Confirmación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="973"/>
        <source>Are you sure you want to quit the application?</source>
        <translation>¿Está seguro de que desea salir de la aplicación?</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/main.cpp" line="96"/>
        <source>Tool used for creating a live-CD from the running system</source>
        <translation>Herramienta usada para crear un Live-CD desde el sistema actual</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="100"/>
        <source>Use CLI only</source>
        <translation>Usar CLI solamente</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="104"/>
        <source>Number of CPU cores to be used.</source>
        <translation>Número de núcleos de CPU que se van a utilizar.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="105"/>
        <source>Output directory</source>
        <translation>Directorio de salida</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="106"/>
        <source>Output filename</source>
        <translation>Nombre del archivo de salida</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="108"/>
        <source>Name a different kernel to use other than the default running kernel, use format returned by &apos;uname -r&apos;</source>
        <translation>Nombre un kernel diferente para usar que no sea el kernel en ejecución predeterminado, use el formato devuelto por &apos;uname -r&apos;</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="110"/>
        <source>Or the full path: %1</source>
        <translation>O la ruta completa: %1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>Compression level options.</source>
        <translation>Opciones de niveles de compresión.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="114"/>
        <source>Use quotes: &quot;-Xcompression-level &lt;level&gt;&quot;, or &quot;-Xalgorithm &lt;algorithm&gt;&quot;, or &quot;-Xhc&quot;, see mksquashfs man page</source>
        <translation>Utilice las comillas: &quot;-Xcompression-level &lt;level&gt;&quot;, o &quot;-Xalgorithm &lt;algorithm&gt;&quot;, o &quot;-Xhc&quot;, vea la página man de mksquashfs</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="118"/>
        <source>Create a monthly snapshot, add &apos;Month&apos; name in the ISO name, skip used space calculation</source>
        <translation>Crear una imagen mensual, añadir el &apos;Mes&apos; en el nombre ISO, omitir el cálculo del espacio usado</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="119"/>
        <source>This option sets reset-accounts and compression to defaults, arguments changing those items will be ignored</source>
        <translation>Esta opción restablece las cuentas y la compresión a los valores predeterminados, los argumentos que cambian esos elementos se ignorarán</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="121"/>
        <source>Optionally specify a suffix to add to the month name (e.g., &apos;1&apos; for &apos;July.1&apos;)</source>
        <translation>Opcionalmente, especifique un sufijo para añadir al nombre del mes (p.ej., &quot;1&quot; para &quot;Julio.1&quot;)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="122"/>
        <source>Don&apos;t calculate checksums for resulting ISO file</source>
        <translation>No calcule sumas de comprobación para el archivo ISO resultante</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="123"/>
        <source>Skip calculating free space to see if the resulting ISO will fit</source>
        <translation>Omitir el cálculo del espacio libre para ver si la ISO resultante cabe</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="124"/>
        <source>Option to fix issue with calculating checksums on preempt_rt kernels</source>
        <translation>Opción para solucionar el problema con el cálculo de sumas de comprobación en kernels preempt_rt</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="125"/>
        <source>Resetting accounts (for distribution to others)</source>
        <translation>Restablecimiento de cuentas (para distribuir a otros)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="126"/>
        <source>Calculate checksums for resulting ISO file</source>
        <translation>Calcular sumas de comprobación para el archivo ISO resultante</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="128"/>
        <source>Throttle the I/O input rate by the given percentage. This can be used to reduce the I/O and CPU consumption of Mksquashfs.</source>
        <translation>Reduce la tasa de entrada E/S en el porcentaje dado. Esto puede usarse para reducir el consumo de E/S y CPU de Mksquashfs.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="131"/>
        <source>Work directory</source>
        <translation>Directorio de trabajo</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="133"/>
        <source>Exclude main folders, valid choices: </source>
        <translation>Excluir carpetas principales, opciones válidas: </translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="135"/>
        <source>Use the option one time for each item you want to exclude</source>
        <translation>Use la opción una vez para cada elemento que desee excluir</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="138"/>
        <source>Compression format, valid choices: </source>
        <translation>Formato de compresión, opciones válidas: </translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="140"/>
        <source>Shutdown computer when done.</source>
        <translation>Apagar el ordenador al finalizar.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="141"/>
        <source>Use grub for legacy mbr iso boot instead of isolinux/syslinux.</source>
        <translation>Utiliza GRUB para el arranque de ISO con MBR heredado en lugar de isolinux/syslinux.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="217"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Parece que ha iniciado sesión como root, cierre la sesión e inicie sesión como usuario normal para usar este programa.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="232"/>
        <source>version:</source>
        <translation>versión:</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="228"/>
        <source>You must run this program with sudo or pkexec.</source>
        <translation>Debe ejecutar este programa con sudo o pkexec.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="210"/>
        <source>MX Snapshot</source>
        <translation>MX Snapshot</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="219"/>
        <location filename="../src/main.cpp" line="297"/>
        <location filename="../src/settings.cpp" line="594"/>
        <location filename="../src/settings.cpp" line="603"/>
        <location filename="../src/settings.cpp" line="1193"/>
        <location filename="../src/settings.cpp" line="1289"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="254"/>
        <source>Fatal error:</source>
        <translation>Error grave:</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="256"/>
        <source>Fatal error: unknown exception</source>
        <translation>Error grave: excepción desconocida</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="296"/>
        <location filename="../src/settings.cpp" line="602"/>
        <source>Current kernel doesn&apos;t support Squashfs, cannot continue.</source>
        <translation>El kernel actual no soporta Squashfs, no puede continuar.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="180"/>
        <source>Exception during initialization: %1</source>
        <translation>Excepción durante la inicialización: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="183"/>
        <source>Unknown exception during initialization</source>
        <translation>Excepción desconocida durante la inicialización</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="219"/>
        <source>Could not create work directory. </source>
        <translation>No se pudo crear el directorio de trabajo.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="248"/>
        <source>No supported filesystem found for the temp directory. Tried /tmp, /home, and the snapshot directory.</source>
        <translation>No se encontró ningún sistema de archivos compatible para el directorio temporal. Se han probado /tmp, /home y el directorio de instantáneas.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="266"/>
        <source>Could not create temp directory:</source>
        <translation>No se pudo crear el directorio temporal:</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="267"/>
        <source>Please check that the parent directory exists and is writable:</source>
        <translation>Compruebe que el directorio padre existe y puede escribir en el:</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="285"/>
        <source>Compression format &apos;%1&apos; is not supported by the current kernel</source>
        <translation>El formato de compresión &apos;%1&apos; no está soportado por el kernel actual</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="291"/>
        <source>Invalid cores setting: %1. Must be between 1 and %2</source>
        <translation>Configuración de núcleos no válida: %1. Debe estar 1 y %2</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="297"/>
        <source>Invalid throttle setting: %1. Must be between 0 and 20</source>
        <translation>Configuración del regulador de frecuencia no válida: %1. Debe estar entre 0 y 20</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="303"/>
        <source>Snapshot directory cannot be empty</source>
        <translation>El directorio de la instantánea no puede estar vacío</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="311"/>
        <source>Snapshot name cannot be empty</source>
        <translation>El nombre de la instantánea no puede estar vacío</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="317"/>
        <source>Snapshot name contains invalid characters: %1</source>
        <translation>El nombre de la instantánea contiene caracteres no válidos: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="323"/>
        <source>Kernel version cannot be empty</source>
        <translation>La versión del Kernel no puede estar vacía</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="328"/>
        <source>Kernel file not found: /boot/vmlinuz-%1</source>
        <translation>No se encontró el archivo del núcleo: /boot/vmlinuz-%1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="335"/>
        <source>Kernel %1 doesn&apos;t support Squashfs</source>
        <translation>Kernel %1 no soportado para Squashfs</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="366"/>
        <source>Exclusion file does not exist: %1</source>
        <translation>El archivo de exclusión no existe: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="375"/>
        <source>Unbalanced quotes in exclusion list</source>
        <translation>Comillas incompletas en la lista de exclusión</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="400"/>
        <source>Insufficient free space: %1 KiB available, minimum %2 KiB required</source>
        <translation>Espacio libre insuficiente: %1 KiB disponible, se requiere un mínimo de %2 KiB</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="407"/>
        <source>Insufficient free space in work directory: %1 KiB available, minimum %2 KiB required</source>
        <translation>Espacio libre insuficiente en el directorio de trabajo: %1 KiB disponible, se requiere un mínimo de %2 KiB</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="422"/>
        <source>Failed to determine number of CPU cores</source>
        <translation>No se ha podido determinar el número de núcleos de la CPU.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="428"/>
        <source>Configuration file does not exist: %1</source>
        <translation>El archivo de configuración no existe: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="429"/>
        <source>Using default settings</source>
        <translation>Usando la configuración por defecto</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="431"/>
        <source>Cannot read configuration file: %1</source>
        <translation>No se puede leer el archivo de configuración: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="432"/>
        <source>Error: %1</source>
        <translation>Error: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="442"/>
        <source>Required tool not found: %1</source>
        <translation>No se encontró la herramienta necesaria: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="451"/>
        <source>Required directory not found: %1</source>
        <translation>No se encontró el directorio necesario: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="470"/>
        <source>Initialization Error</source>
        <translation>Error de inicialización</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="471"/>
        <source>Failed to initialize application settings:

%1</source>
        <translation>No se pudo inicializar la configuración de la aplicación:

%1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="592"/>
        <source>Could not find a usable kernel</source>
        <translation>No se pudo encontrar un kernel utilizable</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="593"/>
        <source>Searched for kernel files in /boot/ but none were found or accessible.</source>
        <translation>Se buscaron archivos del núcleo en /boot/, pero no se encontró ninguno ni se pudo acceder a ellos.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="615"/>
        <source>No users found in the system</source>
        <translation>No se han encontrado usuarios en el sistema</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="618"/>
        <source>Failed to determine system information</source>
        <translation>No se pudo determinar la información del sistema</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="779"/>
        <source>Used space on / (root): </source>
        <translation>Espacio usado en / (root): </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="795"/>
        <source>estimated</source>
        <translation>estimado</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="800"/>
        <source>Used space on /home: </source>
        <translation>Espacio usado en /home: </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="861"/>
        <source>Free space on %1, where snapshot folder is placed: </source>
        <translation>Espacio libre en %1, donde se colocará la imagen del sistema: </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="865"/>
        <source>The free space should be sufficient to hold the compressed data from / and /home

      If necessary, you can create more available space
      by removing previous snapshots and saved copies:
      %1 snapshots are taking up %2 of disk space.
</source>
        <translation>El espacio libre debería ser suficiente para contener los datos comprimidos de / y /home

       Si es necesario, puede crear más espacio disponible
       eliminando imagenes del sistema anteriores y copias guardadas:
       Las imagenes %1 están ocupando %2 del espacio en disco.
</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="879"/>
        <source>Desktop</source>
        <translation>Escritorio</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="880"/>
        <source>Documents</source>
        <translation>Documentos</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="881"/>
        <source>Downloads</source>
        <translation>Descargas</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="882"/>
        <source>Flatpaks</source>
        <translation>Flatpaks</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="883"/>
        <source>Music</source>
        <translation>Música</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="884"/>
        <source>Networks</source>
        <translation>Redes</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="885"/>
        <source>Pictures</source>
        <translation>Imágenes</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="887"/>
        <source>Videos</source>
        <translation>Videos</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1012"/>
        <source>Error reading system configuration file: %1</source>
        <translation>Error al leer el archivo de configuración del sistema: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1020"/>
        <source>Error accessing user configuration</source>
        <translation>Error al acceder a la configuración del usuario</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1072"/>
        <source>Could not copy exclusion file from %1 to %2</source>
        <translation>No se pudo copiar el archivo de exclusión de %1 a %2.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1097"/>
        <source>Invalid stored cores setting (%1). Using detected CPU count: %2</source>
        <translation>Ajuste de núcleos no válido (%1). Usando el recuento de CPU detectadas: %2</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1191"/>
        <location filename="../src/settings.cpp" line="1287"/>
        <source>Output file %1 already exists. Please use another file name, or delete the existent file.</source>
        <translation>El archivo de salida %1 ya existe. Por favor, utilice otro nombre de archivo o elimine el archivo existente.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="73"/>
        <source>Could not load %1</source>
        <translation>No se pudo cargar %1</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <location filename="../src/about.cpp" line="107"/>
        <source>Changelog</source>
        <translation>Registro de cambios</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="98"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="119"/>
        <source>Could not load changelog.</source>
        <translation>No se pudo cargar el registro de cambios.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="53"/>
        <location filename="../src/about.cpp" line="122"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="77"/>
        <source>No diff output available.</source>
        <translation>No hay salida diff disponible.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="89"/>
        <source>Default exclusion file not found at %1.</source>
        <translation>No se ha encontrado el archivo de exclusión por defecto en %1.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="101"/>
        <source>Could not backup existing exclusion file to %1.</source>
        <translation>No se pudo hacer una copia de seguridad del archivo de exclusión existente en %1.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="105"/>
        <source>Could not remove existing exclusion file at %1.</source>
        <translation>No se pudo eliminar el archivo de exclusión existente en %1.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="112"/>
        <source>Could not copy default exclusion file from %1 to %2.</source>
        <translation>No se pudo copiar el archivo de exclusión por defecto de %1 a %2.</translation>
    </message>
</context>
<context>
    <name>Work</name>
    <message>
        <location filename="../src/work.cpp" line="218"/>
        <source>Cleaning...</source>
        <translation>Limpiando...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="239"/>
        <location filename="../src/work.cpp" line="770"/>
        <source>Done</source>
        <translation>Hecho</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="252"/>
        <source>Interrupted or failed to complete</source>
        <translation>Interrumpido o no se pudo completar</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="294"/>
        <location filename="../src/work.cpp" line="408"/>
        <location filename="../src/work.cpp" line="447"/>
        <location filename="../src/work.cpp" line="490"/>
        <location filename="../src/work.cpp" line="518"/>
        <location filename="../src/work.cpp" line="542"/>
        <location filename="../src/work.cpp" line="651"/>
        <location filename="../src/work.cpp" line="750"/>
        <location filename="../src/work.cpp" line="798"/>
        <location filename="../src/work.cpp" line="807"/>
        <location filename="../src/work.cpp" line="1063"/>
        <location filename="../src/work.cpp" line="1100"/>
        <location filename="../src/work.cpp" line="1136"/>
        <location filename="../src/work.cpp" line="1154"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="295"/>
        <source>There&apos;s not enough free space on your target disk, you need at least %1</source>
        <translation>No hay suficiente espacio libre en el disco de destino, necesita al menos %1</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="298"/>
        <source>You have %1 free space on %2</source>
        <translation>Tienes %1  de espacio libre en %2</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="301"/>
        <source>If you are sure you have enough free space rerun the program with -o/--override-size option</source>
        <translation>Si está seguro de que tiene suficiente espacio libre vuelva a ejecutar el programa con la opción -o/--override-size</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="389"/>
        <source>Copying the new-iso filesystem...</source>
        <translation>Copiando el sistema de archivos nueva-iso...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="408"/>
        <source>ISO template not found: </source>
        <translation>No se encontró la plantilla ISO: </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="440"/>
        <source>Arch ISO template is missing boot/ or efi/ directories.</source>
        <translation>En la plantilla ISO de Arch faltan los directorios boot/ o efi/.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="443"/>
        <source>Detected boot/ or efi/ under the work directory root; the template may have been extracted to the wrong location.</source>
        <translation>Se ha detectado la carpeta boot/ o efi/ en el directorio root de trabajo; es posible que la plantilla se haya extraído en una ubicación incorrecta.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="446"/>
        <source>Template: %1</source>
        <translation>Plantilla: %1</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="482"/>
        <source>Stale archiso initramfs detected, rebuilding...</source>
        <translation>Se ha detectado un archiso initramfs obsoleto, reconstruyéndose...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="484"/>
        <source>Found /boot/archiso.img built for kernel %1, but the selected kernel is %2.</source>
        <translation>Se encontró /boot/archiso.img compilado para el kernel %1, pero el kernel seleccionado es %2.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="488"/>
        <source>Rebuilding /boot/archiso.img failed. Please rebuild it manually or remove the stale file.</source>
        <translation>Se produjo un error al reconstruir /boot/archiso.img. Reconstruya lo manualmente o elimine el archivo obsoleto.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="500"/>
        <source>No /boot/archiso.img found, attempting to create one...</source>
        <translation>No se encontró /boot/archiso.img; intentando crear uno...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="505"/>
        <source>Warning</source>
        <translation>Advertencia</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="506"/>
        <source>Could not create /boot/archiso.img (is the &apos;archiso&apos; package installed?). Falling back to the regular initramfs — the resulting ISO will likely fail to boot (&quot;Failed to start Switch Root&quot;).</source>
        <translation>No se pudo crear /boot/archiso.img (¿está instalado el paquete &quot;archiso&quot;?). Se recurrirá al initramfs estándar; es probable que la ISO resultante no arranque (&quot;Error al iniciar switch root&quot;).</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="518"/>
        <source>Could not find an initramfs image to use.</source>
        <translation>No se pudo encontrar una imagen initramfs que se pueda utilizar.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="543"/>
        <source>--grub-mbr option specified but boot/grub/i386-pc/eltorito.img is missing from iso-template</source>
        <translation>Se ha especificado la opción --grub-mbr pero falta el archivo boot/grub/i386-pc/eltorito.img en la plantilla ISO.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="556"/>
        <source>Could not create temp directory. </source>
        <translation>No se pudo crear el directorio temporal. </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="648"/>
        <source>Squashing filesystem...</source>
        <translation>Comprimiendo el sistema de archivos...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="652"/>
        <source>Could not create linuxfs file, please check /var/log/%1.log</source>
        <translation>Ha sido imposible crear el archivo linuxfs, por favor lea /var/log/%1.log</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="747"/>
        <source>Creating CD/DVD image file...</source>
        <translation>Creando un archivo de imagen de CD/DVD...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="751"/>
        <source>Could not create ISO file, please check whether you have enough space on the destination partition.</source>
        <translation>No se pudo crear el archivo ISO, verifique si tiene suficiente espacio en la partición de destino.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="757"/>
        <source>Making hybrid iso</source>
        <translation>Creando un iso híbrido</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="776"/>
        <source>Success</source>
        <translation>Exitoso</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="777"/>
        <source>MX Snapshot completed successfully!</source>
        <translation>¡MX Snapshot se ha completado con exito!</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="778"/>
        <source>Snapshot took %1 to finish.</source>
        <translation>Snapshot tardó %1 en finalizar.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="779"/>
        <source>Thanks for using MX Snapshot, run MX Live USB Maker next!</source>
        <translation>Gracias por usar MX Snapshot, ¡ejecute MX Grabador de Live USB a continuación!</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="795"/>
        <location filename="../src/work.cpp" line="804"/>
        <source>Installing </source>
        <translation>Instalando </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="798"/>
        <location filename="../src/work.cpp" line="807"/>
        <source>Could not install </source>
        <translation>No se pudo instalar </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="817"/>
        <source>Calculating checksum...</source>
        <translation>Calculando suma de comprobación...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="858"/>
        <source>Building new initrd...</source>
        <translation>Construyendo nuevo initrd...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="961"/>
        <source>Rebuilding initramfs with: mkinitcpio %1</source>
        <translation>Recompilando el initramfs con: mkinitcpio %1</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="962"/>
        <source>Note: warnings about missing ipconfig, nfsmount, or nbd-client are harmless — those are only needed for network booting.</source>
        <translation>Nota: las advertencias sobre la falta de ipconfig, nfsmount o nbd-client son inofensivas; solo son necesarias para el arranque por red.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1064"/>
        <source>Could not create working directory. </source>
        <translation>No se pudo crear el directorio de trabajo. </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1101"/>
        <source>Could not prepare a safe bind-root overlay. Snapshot cannot continue.</source>
        <translation>No se pudo preparar una superposición segura de bind-root. La instantánea no puede continuar.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1137"/>
        <location filename="../src/work.cpp" line="1155"/>
        <source>Could not prepare the snapshot bind-root environment.</source>
        <translation>No se pudo preparar el entorno bind-root  de la instantánea.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1487"/>
        <source>Calculating total size of excluded files...</source>
        <translation>Calculando el tamaño total de los archivos excluidos...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1514"/>
        <source>Calculating size of root...</source>
        <translation>Calculando el tamaño de root...</translation>
    </message>
</context>
</TS>