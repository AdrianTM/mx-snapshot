<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="fr_BE">
<context>
    <name>Batchprocessing</name>
    <message>
        <location filename="../src/batchprocessing.cpp" line="50"/>
        <source>Error</source>
        <translation>Erreur</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="51"/>
        <source>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</source>
        <translation>Le noyau actuel ne supporte pas l’algorithme de compression choisi, veuillez éditer le fichier de configuration et sélectionner un algorithme différent.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="88"/>
        <source>The program will pause the build and open the boot menu in your text editor.</source>
        <translation>Le programme mettra en pause la compilation et ouvrira le menu de démarrage dans votre éditeur de texte.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="169"/>
        <source>Detected newer exclusion file at %1 compared to %2. Prompting for action.</source>
        <translation>Le fichier d’exclusion situé à %1 est plus récent que celui de %2. Une action de votre part est nécessaire.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="175"/>
        <source>s</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'show diff'</comment>
        <translation>a</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="176"/>
        <source>u</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'use updated default'</comment>
        <translation>u</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="177"/>
        <source>k</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'keep custom (update timestamp)'</comment>
        <translation>c</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="178"/>
        <source>q</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'quit'</comment>
        <translation>q</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="180"/>
        <source>show diff</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>afficher commande diff</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="181"/>
        <source>use updated default</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>utiliser le fichier par défaut mis à jour</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="182"/>
        <source>keep custom (update timestamp)</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>conserver le réglage personnalisé (mise à jour de l’horodatage)</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="183"/>
        <source>quit</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>quitter</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="186"/>
        <source>[%1]%2  [%3]%4  [%5]%6  [%7]%8: </source>
        <translation>[%1]%2  [%3]%4  [%5]%6  [%7]%8: </translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="191"/>
        <source>The exclusion file at %1 is newer than your configured file at %2.</source>
        <translation>Le fichier d’exclusion à %1 est plus récent que votre fichier configuré à %2.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="207"/>
        <source>Reverted to updated default exclusion file.</source>
        <translation>Rétablissement du fichier d’exclusion par défaut mis à jour.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="220"/>
        <source>Leaving custom exclusion file unchanged.</source>
        <translation>Maintien du fichier d’exclusion personnalisé sans modification.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="231"/>
        <source>Invalid choice. Please select again.</source>
        <translation>Choix incorrect. Veuillez refaire votre sélection.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="238"/>
        <source>This computer uses an NVIDIA graphics card. Are you planning to use the resulting ISO on the same computer or another computer with an NVIDIA card?</source>
        <translation>Cet ordinateur utilise une carte graphique NVIDIA. Prévoyez-vous d’utiliser l’ISO obtenu sur le même ordinateur ou sur un autre ordinateur équipé d’une carte NVIDIA?</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="248"/>
        <source>Note: If you use the resulting ISO on a computer without an NVIDIA card, you will likely need to remove &apos;xorg=nvidia&apos; from the boot options.</source>
        <translation>Remarque: si vous utilisez l’ISO résultant sur un ordinateur sans carte NVIDIA, vous devrez probablement supprimer « xorg=nvidia » des options de démarrage.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="251"/>
        <source>Note: If you use the resulting ISO on a computer with an NVIDIA card, you may need to add &apos;xorg=nvidia&apos; to the boot options.</source>
        <translation>Remarque: si vous utilisez l’ISO obtenu sur un ordinateur équipé d’une carte NVIDIA, vous devrez peut-être ajouter « xorg=nvidia » aux options de démarrage.</translation>
    </message>
</context>
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="142"/>
        <source>No elevation tool found (pkexec/gksu/sudo).</source>
        <translation>Impossible de trouver un outil d’élévation de privilèges (pkexec/gksu/sudo).</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="231"/>
        <source>Administrator Access Required</source>
        <translation>Accès administrateur•rice nécessaire</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="232"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation>Cette opération nécessite des privilèges d’administrateur•rice. Veuillez redémarrer l’application et saisir votre mot de passe lorsque cela vous est demandé.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <location filename="../src/mainwindow.cpp" line="391"/>
        <location filename="../src/mainwindow.cpp" line="843"/>
        <source>MX Snapshot</source>
        <translation>MX Instantané - MX Snapshot</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="33"/>
        <source>Optional customization</source>
        <translation>Personnalisation facultative</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="65"/>
        <source>Release version:</source>
        <translation>Version:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="79"/>
        <source>Boot options:</source>
        <translation>Options de démarrage:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="86"/>
        <source>Live kernel:</source>
        <translation>Noyau live:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="93"/>
        <source>Project name:</source>
        <translation>Nom du projet:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="100"/>
        <source>Release date:</source>
        <translation>Date de parution:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="107"/>
        <source>Release codename:</source>
        <translation>Nom de code de la version:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="133"/>
        <source>Current date</source>
        <translation>Date du jour</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="172"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Snapshot is a utility that creates a bootable image (ISO) of your working system that you can use for storage or distribution. You can continue working with undemanding applications while it is running.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Snapshot est un utilitaire qui crée une image amorçable (ISO) de votre système actuel pour que vous puissiez la conserver ou la distribuer. Vous pouvez utiliser d’autres applications légères pendant son fonctionnement.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="182"/>
        <source>Used space on / (root) and /home partitions:</source>
        <translation>Espace utilisé sur les partitions /(root) et /home:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="192"/>
        <source>Location and ISO name</source>
        <translation>Emplacement et nom de l’ISO</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="219"/>
        <source>Snapshot location:</source>
        <translation>Emplacement de l’instantané:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="226"/>
        <source>Select a different snapshot directory</source>
        <translation>Choisir un répertoire différent pour l’instantané</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="236"/>
        <location filename="../src/mainwindow.cpp" line="607"/>
        <source>Snapshot name:</source>
        <translation>Nom de l’instantané:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="360"/>
        <source>Type of snapshot:</source>
        <translation>Type d’instantané:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="367"/>
        <source>Preserving accounts (for personal backup)</source>
        <translation>Conservation des comptes (pour une sauvegarde personnelle)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This option will reset &amp;quot;demo&amp;quot; and &amp;quot;root&amp;quot; passwords to the MX Linux defaults and will not copy any personal accounts created.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Cette option réinitialisera les mots de passe &amp;quot;demo&amp;quot; et &amp;quot;root&amp;quot; aux valeurs par défauts de MX Linux et ne copiera pas les comptes personnels.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="380"/>
        <source>Resetting accounts (for distribution to others)</source>
        <translation>Réinitialisation des comptes (pour distribuer à d’autres personnes)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="451"/>
        <source>You can also exclude certain directories by ticking the common choices below, or by clicking on the button to directly edit /etc/mx-snapshot-exclude.list.</source>
        <translation>Vous pouvez aussi exclure certains répertoires en cochant les options courantes ci-dessous, ou en cliquant sur le bouton pour modifier directement  /etc/mx-snapshot-exclude.list.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="496"/>
        <source>sha512</source>
        <translation>sha512</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="519"/>
        <source>Throttle the I/O input rate by the given percentage.</source>
        <translation>Réduire le taux d’entrée des I/O - Entrées/Sorties - selon le pourcentage donné.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="525"/>
        <source>I/O throttle:</source>
        <translation>Limite des I/O - Entrées/Sorties:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="532"/>
        <source>Calculate checksums:</source>
        <translation>Calcul des sommes de contrôle:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="539"/>
        <source>ISO compression scheme:</source>
        <translation>Méthode de compression de l’ISO:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="546"/>
        <source>Number of CPU cores to use:</source>
        <translation>Nombre de cœurs du processeur à utiliser:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="553"/>
        <source>md5</source>
        <translation>md5</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="563"/>
        <source>Options:</source>
        <translation>Options:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="610"/>
        <source>Edit Exclusion File</source>
        <translation>Éditer le fichier d’exclusion</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="626"/>
        <location filename="../src/mainwindow.cpp" line="863"/>
        <source>Remove Custom Exclusion File</source>
        <translation>Supprimer le fichier d’exclusion personnalisé</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="679"/>
        <source>Pictures</source>
        <translation>Photos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="686"/>
        <source>Videos</source>
        <translation>Vidéos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="693"/>
        <source>All of the above</source>
        <translation>Tout ce qui précède</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="700"/>
        <source>exclude network configurations</source>
        <translation>exclure les configurations réseau</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="703"/>
        <source>Networks</source>
        <translation>Réseaux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="710"/>
        <source>Downloads</source>
        <translation>Téléchargements</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="717"/>
        <source>Desktop</source>
        <translation>Bureau</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="724"/>
        <source>Documents</source>
        <translation>Documents</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="731"/>
        <source>Flatpaks</source>
        <translation>Flatpaks</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="738"/>
        <source>Music</source>
        <translation>Musique</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="876"/>
        <source>About this application</source>
        <translation>À propos de cette application</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="879"/>
        <source>About...</source>
        <translation>À propos …</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="885"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="901"/>
        <source>Next</source>
        <translation>Suivant</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="926"/>
        <source>Display help </source>
        <translation>Afficher l’aide </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="929"/>
        <source>Help</source>
        <translation>Aide</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="935"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="948"/>
        <source>Quit application</source>
        <translation>Quitter l’application</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="951"/>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="957"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1011"/>
        <source>Back</source>
        <translation>Retour</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="353"/>
        <source>Select Release Date</source>
        <translation>Choisir la date de publication</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="397"/>
        <source>fastest, worst compression</source>
        <translation>compression la plus rapide et la plus mauvaise</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="397"/>
        <source>fast, worse compression</source>
        <translation>compression rapide et moins bonne</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="398"/>
        <source>slow, better compression</source>
        <translation>compression lente et bonne</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="398"/>
        <source>best compromise</source>
        <translation>meilleur compromis</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="399"/>
        <source>slowest, best compression</source>
        <translation>compression la plus lente et la meilleure</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="428"/>
        <source>Free space on %1, where snapshot folder is placed: </source>
        <translation>Espace libre disponible dans %1 où sera mis le dossier de l’instantané: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="431"/>
        <source>The free space should be sufficient to hold the compressed data from / and /home

      If necessary, you can create more available space by removing previous snapshots and saved copies: %1 snapshots are taking up %2 of disk space.</source>
        <translation>L’espace libre doit être suffisant pour contenir les données compressées de / et de /home.

      Si nécessaire, vous pouvez créer plus d’espace disponible en supprimant les instantanés précédents et les copies sauvegardées: les instantanés « snapshots » %1 occupent %2 de l’espace disque.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="443"/>
        <location filename="../src/mainwindow.cpp" line="444"/>
        <source>Installing </source>
        <translation>Installation </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="550"/>
        <source>Please wait.</source>
        <translation>Veuillez patienter …</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="552"/>
        <source>Please wait. Calculating used disk space...</source>
        <translation>Veuillez patienter. Calcul de l’espace disque utilisé …</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="274"/>
        <location filename="../src/mainwindow.cpp" line="586"/>
        <location filename="../src/mainwindow.cpp" line="593"/>
        <location filename="../src/mainwindow.cpp" line="675"/>
        <location filename="../src/mainwindow.cpp" line="686"/>
        <location filename="../src/mainwindow.cpp" line="928"/>
        <source>Error</source>
        <translation>Erreur</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="174"/>
        <location filename="../src/mainwindow.cpp" line="210"/>
        <source>Updated Exclusion List</source>
        <translation>Liste d’exclusion actualisée</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="177"/>
        <source>The exclusion file at %1 is newer than your configured file at %2.</source>
        <translation>Le fichier d’exclusion à %1 est plus récent que votre fichier configuré à %2.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="179"/>
        <source>Review the changes below. Keep your custom file or replace it with the updated default.</source>
        <translation>Examinez les modifications ci-dessous. Conservez votre fichier personnalisé ou remplacez-le par le fichier par défaut mis à jour.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="185"/>
        <source>Show Differences</source>
        <translation>Afficher les différences</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="191"/>
        <source>Keep Custom</source>
        <translation>Conserver le fichier personnalisé</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="197"/>
        <source>Use Updated Default</source>
        <translation>Utiliser le fichier par défaut mis à jour</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="498"/>
        <source>Done</source>
        <translation>Terminé</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="587"/>
        <source>Output file %1 already exists. Please use another file name, or delete the existent file.</source>
        <translation>Le nom de fichier %1 existe déjà. Veuillez utiliser un autre nom de fichier ou supprimer le fichier existant.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="594"/>
        <source>Insufficient free space. Please select a different snapshot directory or free up space.</source>
        <translation>Espace libre insuffisant. Veuillez sélectionner un autre répertoire ou libérer de l’espace.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="598"/>
        <source>Settings</source>
        <translation>Paramètres</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="604"/>
        <source>Snapshot will use the following settings:</source>
        <translation>Snapshot utilisera les paramètres suivants:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="606"/>
        <source>- Snapshot directory:</source>
        <translation>- Répertoire de l’instantané:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="607"/>
        <source>- Kernel to be used:</source>
        <translation>- Noyau à utiliser:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="631"/>
        <location filename="../src/mainwindow.cpp" line="640"/>
        <source>NVIDIA Detected</source>
        <translation>NVIDIA détecté</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="632"/>
        <source>This computer uses an NVIDIA graphics card. Are you planning to use the resulting ISO on the same computer or another computer with an NVIDIA card?</source>
        <translation>Cet ordinateur utilise une carte graphique NVIDIA. Prévoyez-vous d’utiliser l’ISO obtenu sur le même ordinateur ou sur un autre ordinateur équipé d’une carte NVIDIA?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="636"/>
        <source>NVIDIA Selected</source>
        <translation>NVIDIA sélectionné</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="637"/>
        <source>Note: If you use the resulting ISO on a computer without an NVIDIA card, you will likely need to remove &apos;xorg=nvidia&apos; from the boot options.</source>
        <translation>Remarque: si vous utilisez l’ISO résultant sur un ordinateur sans carte NVIDIA, vous devrez probablement supprimer « xorg=nvidia » des options de démarrage.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="641"/>
        <source>Note: If you use the resulting ISO on a computer with an NVIDIA card, you may need to add &apos;xorg=nvidia&apos; to the boot options.</source>
        <translation>Remarque: si vous utilisez l’ISO obtenu sur un ordinateur équipé d’une carte NVIDIA, vous devrez peut-être ajouter « xorg=nvidia » aux options de démarrage.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="275"/>
        <location filename="../src/mainwindow.cpp" line="676"/>
        <source>Could not replace the exclusion file with the updated default.</source>
        <translation>Impossible de remplacer le fichier d’exclusion par le fichier par défaut mis à jour.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="687"/>
        <source>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</source>
        <translation>Le noyau actuel ne supporte pas l’algorithme de compression choisi, veuillez éditer le fichier de configuration et sélectionner un algorithme différent.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="710"/>
        <source>Final chance</source>
        <translation>Dernière occasion d’arrêter le processus</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="712"/>
        <source>Snapshot now has all the information it needs to create an ISO from your running system.</source>
        <translation>Snapshot dispose désormais de toutes les informations nécessaires à la création du fichier ISO instantané de votre système.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="713"/>
        <source>It will take some time to finish, depending on the size of the installed system and the capacity of your computer.</source>
        <translation>Selon la taille de votre image et la puissance de votre ordinateur, le processus peut durer un certain temps.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="715"/>
        <source>OK to start?</source>
        <translation>Prêt à démarrer?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="824"/>
        <location filename="../src/mainwindow.cpp" line="719"/>
        <source>Shutdown computer when done.</source>
        <translation>Arrêter l’ordinateur une fois terminé.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="753"/>
        <source>Output</source>
        <translation>Résultats</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="773"/>
        <source>Close</source>
        <translation>Quitter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="827"/>
        <source>Edit Boot Menu</source>
        <translation>Éditer le menu de démarrage</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="828"/>
        <source>The program will now pause to allow you to edit any files in the work directory. Select Yes to edit the boot menu or select No to bypass this step and continue creating the snapshot.</source>
        <translation>Le programme va se mettre en pause afin de vous permettre d’éditer les fichiers du répertoire de travail. Veuillez choisir Yes pour éditer le menu de démarrage, ou No pour passer cette étape et continuer la création de l’instantané.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="864"/>
        <source>Revert the exclusion list to the default file? This will overwrite your current exclusions.</source>
        <translation>Rétablir la liste d’exclusion avec le fichier par défaut? Cela écrasera vos exclusions actuelles.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="896"/>
        <source>About %1</source>
        <translation>À propos %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="898"/>
        <source>Version: </source>
        <translation>Version: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="899"/>
        <source>Program for creating a live-CD from the running system for MX Linux</source>
        <translation>Programme créant un instantané du système MX Linux en fonctionnement sous forme d’un live CD.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="901"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="903"/>
        <source>%1 License</source>
        <translation>%1 Licence</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="916"/>
        <source>%1 Help</source>
        <translation>%1 Aide</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="921"/>
        <source>Select Snapshot Directory</source>
        <translation>Choisissez un répertoire pour l’instantané</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="929"/>
        <source>Insufficient free space in the selected directory. Please choose a different location.</source>
        <translation>Espace libre insuffisant dans le répertoire sélectionné. Veuillez choisir un autre emplacement.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="973"/>
        <source>Confirmation</source>
        <translation>Confirmation</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="973"/>
        <source>Are you sure you want to quit the application?</source>
        <translation>Êtes-vous sûr•e de vouloir quitter l’application?</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/main.cpp" line="96"/>
        <source>Tool used for creating a live-CD from the running system</source>
        <translation>Outil de création d’un live-CD à partir d’un système en cours de fonctionnement</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="100"/>
        <source>Use CLI only</source>
        <translation>Utiliser seulement CLI</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="104"/>
        <source>Number of CPU cores to be used.</source>
        <translation>Nombre de cœurs du processeur devant être utilisés.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="105"/>
        <source>Output directory</source>
        <translation>Répertoire de destination</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="106"/>
        <source>Output filename</source>
        <translation>Nom du fichier de destination</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="108"/>
        <source>Name a different kernel to use other than the default running kernel, use format returned by &apos;uname -r&apos;</source>
        <translation>Désignez un noyau différent devant être utilisé à la place du noyau fonctionnant par défaut, en utilisant le format renvoyé par « uname -r »</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="110"/>
        <source>Or the full path: %1</source>
        <translation>Ou le chemin entier: %1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>Compression level options.</source>
        <translation>Options du niveau de compression.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="114"/>
        <source>Use quotes: &quot;-Xcompression-level &lt;level&gt;&quot;, or &quot;-Xalgorithm &lt;algorithm&gt;&quot;, or &quot;-Xhc&quot;, see mksquashfs man page</source>
        <translation>Entourez ces options de guillemets: &quot;-Xcompression-level &lt;level&gt;&quot; ou &quot;-Xalgorithm &lt;algorithm&gt;&quot; ou &quot;-Xhc&quot;. Voir la page de manuel (man) consacrée à mksquashfs</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="118"/>
        <source>Create a monthly snapshot, add &apos;Month&apos; name in the ISO name, skip used space calculation</source>
        <translation>Créer un instantané mensuel, inclure le nom du « mois » dans le nom de l’ISO et ignorer le calcul de l’espace utilisé</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="119"/>
        <source>This option sets reset-accounts and compression to defaults, arguments changing those items will be ignored</source>
        <translation>Cette option définit les comptes de réinitialisation et la compression par défaut, les arguments modifiant ces éléments seront ignorés</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="121"/>
        <source>Optionally specify a suffix to add to the month name (e.g., &apos;1&apos; for &apos;July.1&apos;)</source>
        <translation>Vous pouvez éventuellement spécifier un suffixe à ajouter au nom du mois (par exemple, « 1 » pour « juillet.1 »).</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="122"/>
        <source>Don&apos;t calculate checksums for resulting ISO file</source>
        <translation>Ne pas calculer les sommes de contrôle pour le fichier ISO obtenu</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="123"/>
        <source>Skip calculating free space to see if the resulting ISO will fit</source>
        <translation>Ne pas calculer l’espace libre pour voir si l’ISO qui en résulte tiendra dans l’espace.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="124"/>
        <source>Option to fix issue with calculating checksums on preempt_rt kernels</source>
        <translation>Option permettant de régler les problèmes lors du calcul de la somme de contrôle des noyaux preempt_rt (noyaux temps réel)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="125"/>
        <source>Resetting accounts (for distribution to others)</source>
        <translation>Réinitialisation des comptes (pour distribuer à d’autres personnes)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="126"/>
        <source>Calculate checksums for resulting ISO file</source>
        <translation>Calculer les sommes de contrôle pour le fichier ISO obtenu</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="128"/>
        <source>Throttle the I/O input rate by the given percentage. This can be used to reduce the I/O and CPU consumption of Mksquashfs.</source>
        <translation>Réduire le taux d’entrée des I/O - Entrées/Sorties - selon le pourcentage donné. Cela peut être utilisé pour réduire les I/O et la consommation du CPU de Mksquashfs.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="131"/>
        <source>Work directory</source>
        <translation>Répertoire de travail</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="133"/>
        <source>Exclude main folders, valid choices: </source>
        <translation>Exclure les dossiers principaux, choix valables: </translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="135"/>
        <source>Use the option one time for each item you want to exclude</source>
        <translation>Répétez cette option pour chaque élément à exclure</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="138"/>
        <source>Compression format, valid choices: </source>
        <translation>Format de compression, choix valables: </translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="140"/>
        <source>Shutdown computer when done.</source>
        <translation>Arrêter l’ordinateur une fois terminé.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="141"/>
        <source>Use grub for legacy mbr iso boot instead of isolinux/syslinux.</source>
        <translation>Utiliser GRUB pour l’amorçage ISO MBR hérité (legacy) à la place d’ISOLINUX/SYSLINUX.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="217"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Vous êtes apparemment connecté en tant que root, veuillez vous déconnecter et vous connecter en tant qu’utilisateur•rice normal•e pour utiliser ce programme.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="232"/>
        <source>version:</source>
        <translation>version:</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="228"/>
        <source>You must run this program with sudo or pkexec.</source>
        <translation>Vous devez exécuter ce programme avec sudo ou pkexec.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="210"/>
        <source>MX Snapshot</source>
        <translation>MX Instantané - MX Snapshot</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="219"/>
        <location filename="../src/main.cpp" line="297"/>
        <location filename="../src/settings.cpp" line="594"/>
        <location filename="../src/settings.cpp" line="603"/>
        <location filename="../src/settings.cpp" line="1193"/>
        <location filename="../src/settings.cpp" line="1289"/>
        <source>Error</source>
        <translation>Erreur</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="254"/>
        <source>Fatal error:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="256"/>
        <source>Fatal error: unknown exception</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="296"/>
        <location filename="../src/settings.cpp" line="602"/>
        <source>Current kernel doesn&apos;t support Squashfs, cannot continue.</source>
        <translation>Le noyau actuel ne supporte pas Squashfs, impossible de continuer.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="180"/>
        <source>Exception during initialization: %1</source>
        <translation>Erreur lors de l’initialisation: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="183"/>
        <source>Unknown exception during initialization</source>
        <translation>Erreur inconnue lors de l’initialisation</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="219"/>
        <source>Could not create work directory. </source>
        <translation>Impossible de créer le répertoire de travail. </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="248"/>
        <source>No supported filesystem found for the temp directory. Tried /tmp, /home, and the snapshot directory.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="266"/>
        <source>Could not create temp directory:</source>
        <translation>Impossible de créer le répertoire temporaire:</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="267"/>
        <source>Please check that the parent directory exists and is writable:</source>
        <translation>Veuillez vérifier que le répertoire parent existe et qu’il est accessible en écriture:</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="285"/>
        <source>Compression format &apos;%1&apos; is not supported by the current kernel</source>
        <translation>Le format de compression « %1 » n’est pas pris en charge par le noyau actuel</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="291"/>
        <source>Invalid cores setting: %1. Must be between 1 and %2</source>
        <translation>Paramètre de cœurs non valide: %1. Doit être compris entre 1 et %2</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="297"/>
        <source>Invalid throttle setting: %1. Must be between 0 and 20</source>
        <translation>Réglage du régulateur (throttle) invalide: %1. Doit être compris entre 0 et 20</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="303"/>
        <source>Snapshot directory cannot be empty</source>
        <translation>Le répertoire Snapshot (Instantané) ne peut pas être vide</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="311"/>
        <source>Snapshot name cannot be empty</source>
        <translation>Le nom du snapshot (instantané) ne peut pas être vide</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="317"/>
        <source>Snapshot name contains invalid characters: %1</source>
        <translation>Le nom du snapshot (instantané) contient des caractères non valides: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="323"/>
        <source>Kernel version cannot be empty</source>
        <translation>La version du noyau ne peut pas être vide</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="328"/>
        <source>Kernel file not found: /boot/vmlinuz-%1</source>
        <translation>Fichier noyau introuvable: /boot/vmlinuz-%1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="335"/>
        <source>Kernel %1 doesn&apos;t support Squashfs</source>
        <translation>Le noyau %1 ne prend pas en charge Squashfs</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="366"/>
        <source>Exclusion file does not exist: %1</source>
        <translation>Le fichier d’exclusion n’existe pas: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="375"/>
        <source>Unbalanced quotes in exclusion list</source>
        <translation>Guillemets non équilibrés dans la liste d’exclusion</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="400"/>
        <source>Insufficient free space: %1 KiB available, minimum %2 KiB required</source>
        <translation>Espace libre insuffisant: %1 Ko (KiB) disponible, minimum %2 Ko (KiB) requis</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="407"/>
        <source>Insufficient free space in work directory: %1 KiB available, minimum %2 KiB required</source>
        <translation>Espace libre insuffisant dans le répertoire de travail: %1 Ko (KiB) disponible, minimum %2 Ko (KiB) requis</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="422"/>
        <source>Failed to determine number of CPU cores</source>
        <translation>Impossible de déterminer le nombre de cœurs du processeur</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="428"/>
        <source>Configuration file does not exist: %1</source>
        <translation>Le fichier de configuration n’existe pas: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="429"/>
        <source>Using default settings</source>
        <translation>Utilisation des paramètres par défaut</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="431"/>
        <source>Cannot read configuration file: %1</source>
        <translation>Impossible de lire le fichier de configuration: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="432"/>
        <source>Error: %1</source>
        <translation>Erreur: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="442"/>
        <source>Required tool not found: %1</source>
        <translation>Outil requis introuvable: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="451"/>
        <source>Required directory not found: %1</source>
        <translation>Répertoire requis introuvable: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="470"/>
        <source>Initialization Error</source>
        <translation>Erreur d’initialisation</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="471"/>
        <source>Failed to initialize application settings:

%1</source>
        <translation>Impossible d’initialiser les paramètres de l’application:

%1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="592"/>
        <source>Could not find a usable kernel</source>
        <translation>Impossible de trouver un noyau utilisable</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="593"/>
        <source>Searched for kernel files in /boot/ but none were found or accessible.</source>
        <translation>Recherche de fichiers du noyau dans /boot/, mais aucun n’a été trouvé ou n’était accessible.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="615"/>
        <source>No users found in the system</source>
        <translation>Aucun•e utilisateur•rice trouvé•e dans le système</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="618"/>
        <source>Failed to determine system information</source>
        <translation>Impossible de déterminer les informations système</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="779"/>
        <source>Used space on / (root): </source>
        <translation>Espace utilisé dans /(root): </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="795"/>
        <source>estimated</source>
        <translation>estimé</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="800"/>
        <source>Used space on /home: </source>
        <translation>Espace utilisé dans /home: </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="861"/>
        <source>Free space on %1, where snapshot folder is placed: </source>
        <translation>Espace libre disponible dans %1 où sera mis le dossier de l’instantané: </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="865"/>
        <source>The free space should be sufficient to hold the compressed data from / and /home

      If necessary, you can create more available space
      by removing previous snapshots and saved copies:
      %1 snapshots are taking up %2 of disk space.
</source>
        <translation>L’espace libre doit pouvoir contenir les données compressées de / et de /home

Si nécessaire, vous pouvez obtenir de l’espace supplémentaire en supprimant les instantanés et les copies créées auparavant:
Les instantanés « snapshots » %1 occupent %2 de l’espace disque.
</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="879"/>
        <source>Desktop</source>
        <translation>Bureau</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="880"/>
        <source>Documents</source>
        <translation>Documents</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="881"/>
        <source>Downloads</source>
        <translation>Téléchargements</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="882"/>
        <source>Flatpaks</source>
        <translation>Flatpaks</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="883"/>
        <source>Music</source>
        <translation>Musique</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="884"/>
        <source>Networks</source>
        <translation>Réseaux</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="885"/>
        <source>Pictures</source>
        <translation>Photos</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="887"/>
        <source>Videos</source>
        <translation>Vidéos</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1012"/>
        <source>Error reading system configuration file: %1</source>
        <translation>Erreur lors de la lecture du fichier de configuration du système: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1020"/>
        <source>Error accessing user configuration</source>
        <translation>Erreur lors de l’accès à la configuration de l’utilisateur•rice</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1072"/>
        <source>Could not copy exclusion file from %1 to %2</source>
        <translation>Impossible de copier le fichier d’exclusion de %1 vers %2</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1097"/>
        <source>Invalid stored cores setting (%1). Using detected CPU count: %2</source>
        <translation>Paramètre de cœurs mémorisés non valide (%1). Nombre de processeurs détectés utilisé: %2</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1191"/>
        <location filename="../src/settings.cpp" line="1287"/>
        <source>Output file %1 already exists. Please use another file name, or delete the existent file.</source>
        <translation>Le nom de fichier %1 existe déjà. Veuillez utiliser un autre nom de fichier ou supprimer le fichier existant.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="73"/>
        <source>Could not load %1</source>
        <translation>Impossible de charger %1</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>License</source>
        <translation>Licence</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <location filename="../src/about.cpp" line="107"/>
        <source>Changelog</source>
        <translation>Journal des modifications</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="98"/>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="119"/>
        <source>Could not load changelog.</source>
        <translation>Impossible de charger le journal des modifications.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="53"/>
        <location filename="../src/about.cpp" line="122"/>
        <source>&amp;Close</source>
        <translation>&amp;Quitter</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="77"/>
        <source>No diff output available.</source>
        <translation>La commande « diff » ne donne aucun résultat.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="89"/>
        <source>Default exclusion file not found at %1.</source>
        <translation>Fichier d’exclusion par défaut introuvable à %1.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="101"/>
        <source>Could not backup existing exclusion file to %1.</source>
        <translation>Impossible de sauvegarder le fichier d’exclusion existant vers %1.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="105"/>
        <source>Could not remove existing exclusion file at %1.</source>
        <translation>Impossible de supprimer le fichier d’exclusion existant à %1.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="112"/>
        <source>Could not copy default exclusion file from %1 to %2.</source>
        <translation>Impossible de copier le fichier d’exclusion par défaut de %1 vers %2.</translation>
    </message>
</context>
<context>
    <name>Work</name>
    <message>
        <location filename="../src/work.cpp" line="218"/>
        <source>Cleaning...</source>
        <translation>Nettoyage …</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="239"/>
        <location filename="../src/work.cpp" line="770"/>
        <source>Done</source>
        <translation>Terminé</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="252"/>
        <source>Interrupted or failed to complete</source>
        <translation>Interrompu ou non terminé</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="294"/>
        <location filename="../src/work.cpp" line="408"/>
        <location filename="../src/work.cpp" line="447"/>
        <location filename="../src/work.cpp" line="490"/>
        <location filename="../src/work.cpp" line="518"/>
        <location filename="../src/work.cpp" line="542"/>
        <location filename="../src/work.cpp" line="651"/>
        <location filename="../src/work.cpp" line="750"/>
        <location filename="../src/work.cpp" line="798"/>
        <location filename="../src/work.cpp" line="807"/>
        <location filename="../src/work.cpp" line="1063"/>
        <location filename="../src/work.cpp" line="1100"/>
        <location filename="../src/work.cpp" line="1136"/>
        <location filename="../src/work.cpp" line="1154"/>
        <source>Error</source>
        <translation>Erreur</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="295"/>
        <source>There&apos;s not enough free space on your target disk, you need at least %1</source>
        <translation>Il n’y a pas assez d’espace libre sur votre disque cible, vous avez besoin d’au moins %1</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="298"/>
        <source>You have %1 free space on %2</source>
        <translation>Vous avez %1 d’espace libre sur %2</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="301"/>
        <source>If you are sure you have enough free space rerun the program with -o/--override-size option</source>
        <translation>Si vous êtes certain•e d’avoir assez d’espace libre, relancez le programme avec l’option -o/--override-size</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="389"/>
        <source>Copying the new-iso filesystem...</source>
        <translation>Copie du nouveau système de fichiers iso en cours …</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="408"/>
        <source>ISO template not found: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="440"/>
        <source>Arch ISO template is missing boot/ or efi/ directories.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="443"/>
        <source>Detected boot/ or efi/ under the work directory root; the template may have been extracted to the wrong location.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="446"/>
        <source>Template: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="482"/>
        <source>Stale archiso initramfs detected, rebuilding...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="484"/>
        <source>Found /boot/archiso.img built for kernel %1, but the selected kernel is %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="488"/>
        <source>Rebuilding /boot/archiso.img failed. Please rebuild it manually or remove the stale file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="500"/>
        <source>No /boot/archiso.img found, attempting to create one...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="505"/>
        <source>Warning</source>
        <translation>Attention</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="506"/>
        <source>Could not create /boot/archiso.img (is the &apos;archiso&apos; package installed?). Falling back to the regular initramfs — the resulting ISO will likely fail to boot (&quot;Failed to start Switch Root&quot;).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="518"/>
        <source>Could not find an initramfs image to use.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="543"/>
        <source>--grub-mbr option specified but boot/grub/i386-pc/eltorito.img is missing from iso-template</source>
        <translation>Option --grub-mbr spécifiée mais le fichier boot/grub/i386-pc/eltorito.img est absent du modèle ISO</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="556"/>
        <source>Could not create temp directory. </source>
        <translation>Impossible de créer le répertoire temporaire. </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="648"/>
        <source>Squashing filesystem...</source>
        <translation>Création du système de fichiers compressé « SquashFS » …</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="652"/>
        <source>Could not create linuxfs file, please check /var/log/%1.log</source>
        <translation>Impossible de créer un fichier linuxfs, veuillez vérifier /var/log/%1.log</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="747"/>
        <source>Creating CD/DVD image file...</source>
        <translation>Création du fichier image pour CD/DVD …</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="751"/>
        <source>Could not create ISO file, please check whether you have enough space on the destination partition.</source>
        <translation>Impossible de créer le fichier ISO. Veuillez vérifier que l’espace sur la partition de destination est suffisant.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="757"/>
        <source>Making hybrid iso</source>
        <translation>Création d’une image ISO hybride</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="776"/>
        <source>Success</source>
        <translation>Installation réussie</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="777"/>
        <source>MX Snapshot completed successfully!</source>
        <translation>Le processus de MX Snapshot s’est terminé avec succès!</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="778"/>
        <source>Snapshot took %1 to finish.</source>
        <translation>Le processus de création de l’instantané s’est terminé en %1.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="779"/>
        <source>Thanks for using MX Snapshot, run MX Live USB Maker next!</source>
        <translation>Merci d’utiliser MX Instantané - MX Snapshot, lancez ensuite MX Live USB Création!</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="795"/>
        <location filename="../src/work.cpp" line="804"/>
        <source>Installing </source>
        <translation>Installation </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="798"/>
        <location filename="../src/work.cpp" line="807"/>
        <source>Could not install </source>
        <translation>Installation impossible </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="817"/>
        <source>Calculating checksum...</source>
        <translation>Calcul de la somme de contrôle …</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="858"/>
        <source>Building new initrd...</source>
        <translation>Nouvel initrd en cours de création …</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="961"/>
        <source>Rebuilding initramfs with: mkinitcpio %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="962"/>
        <source>Note: warnings about missing ipconfig, nfsmount, or nbd-client are harmless — those are only needed for network booting.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1064"/>
        <source>Could not create working directory. </source>
        <translation>Impossible de créer le répertoire de travail. </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1101"/>
        <source>Could not prepare a safe bind-root overlay. Snapshot cannot continue.</source>
        <translation>Impossible de préparer un overlay bind-root sécurisé. La création de l’instantané (snapshot) ne peut pas se poursuivre.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1137"/>
        <location filename="../src/work.cpp" line="1155"/>
        <source>Could not prepare the snapshot bind-root environment.</source>
        <translation>Impossible de préparer l’environnement bind-root pour l’instantané (snapshot). </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1487"/>
        <source>Calculating total size of excluded files...</source>
        <translation>Calcul de la taille totale des fichiers exclus …</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1514"/>
        <source>Calculating size of root...</source>
        <translation>Calcul de la taille de root …</translation>
    </message>
</context>
</TS>