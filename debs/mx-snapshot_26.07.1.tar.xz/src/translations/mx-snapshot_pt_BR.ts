<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="pt_BR">
<context>
    <name>Batchprocessing</name>
    <message>
        <location filename="../src/batchprocessing.cpp" line="50"/>
        <source>Error</source>
        <translation>Ocorreu um Erro</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="51"/>
        <source>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</source>
        <translation>O núcleo (kernel) atual não possui suporte ao algoritmo de compactação/compressão que foi selecionado. Por favor, edite o arquivo de configurações e selecione um algoritmo diferente.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="88"/>
        <source>The program will pause the build and open the boot menu in your text editor.</source>
        <translation>O programa irá parar a compilação e irá abrir o arquivo de configurações do menu de inicialização no editor de texto.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="169"/>
        <source>Detected newer exclusion file at %1 compared to %2. Prompting for action.</source>
        <translation>Detectado um arquivo de exclusão mais recente em %1 em comparação com %2. Solicitando ação.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="175"/>
        <source>s</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'show diff'</comment>
        <translation>s</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="176"/>
        <source>u</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'use updated default'</comment>
        <translation>u</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="177"/>
        <source>k</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'keep custom (update timestamp)'</comment>
        <translation>k</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="178"/>
        <source>q</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'quit'</comment>
        <translation>q</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="180"/>
        <source>show diff</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>mostrar diferença</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="181"/>
        <source>use updated default</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>usar padrão atualizado</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="182"/>
        <source>keep custom (update timestamp)</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>manter personalizado (atualizar carimbo de data/hora)</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="183"/>
        <source>quit</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>Sair</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="186"/>
        <source>[%1]%2  [%3]%4  [%5]%6  [%7]%8: </source>
        <translation>[%1]%2 [%3]%4 [%5]%6 [%7]%8: </translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="191"/>
        <source>The exclusion file at %1 is newer than your configured file at %2.</source>
        <translation>O arquivo de exclusão em %1 é mais recente do que o arquivo configurado em %2.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="207"/>
        <source>Reverted to updated default exclusion file.</source>
        <translation>O arquivo de exclusão padrão atualizado foi revertido.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="220"/>
        <source>Leaving custom exclusion file unchanged.</source>
        <translation>O arquivo de exclusão personalizado permanece inalterado.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="231"/>
        <source>Invalid choice. Please select again.</source>
        <translation>Opção inválida. Por favor, selecione novamente.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="238"/>
        <source>This computer uses an NVIDIA graphics card. Are you planning to use the resulting ISO on the same computer or another computer with an NVIDIA card?</source>
        <translation>Este computador utiliza uma placa de vídeo da NVIDIA. Você está planejando utilizar a imagem ISO resultante no mesmo computador ou em um outro computador que tem uma placa de vídeo da NVIDIA?</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="248"/>
        <source>Note: If you use the resulting ISO on a computer without an NVIDIA card, you will likely need to remove &apos;xorg=nvidia&apos; from the boot options.</source>
        <translation>Observação: Se você utilizar a imagem ISO resultante em um computador que não tem uma placa de vídeo da NVIDIA, provavelmente será necessário remover o parâmetro ‘xorg=nvidia’ das opções de inicialização.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="251"/>
        <source>Note: If you use the resulting ISO on a computer with an NVIDIA card, you may need to add &apos;xorg=nvidia&apos; to the boot options.</source>
        <translation>Observação: Se você utilizar a imagem ISO resultante em um computador que tem uma placa de vídeo da NVIDIA, pode ser necessário adicionar o parâmetro &apos;xorg=nvidia&apos; nas opções de inicialização.</translation>
    </message>
</context>
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="142"/>
        <source>No elevation tool found (pkexec/gksu/sudo).</source>
        <translation>Nenhuma ferramenta de elevação de privilégios encontrada (pkexec/gksu/sudo).</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="231"/>
        <source>Administrator Access Required</source>
        <translation>O acesso com as permissões de administrador é necessário</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="232"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation>Esta operação requer as permissões ou os privilégios de administrador. Por favor, reinicie o programa e digite a sua senha quando for solicitada.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <location filename="../src/mainwindow.cpp" line="391"/>
        <location filename="../src/mainwindow.cpp" line="843"/>
        <source>MX Snapshot</source>
        <translation>Snapshot do MX - Criador de Imagem ISO do Sistema Operacional</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="33"/>
        <source>Optional customization</source>
        <translation>Opções de Personalização</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="65"/>
        <source>Release version:</source>
        <translation>Versão do lançamento:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="79"/>
        <source>Boot options:</source>
        <translation>Opções de inicialização:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="86"/>
        <source>Live kernel:</source>
        <translation>Núcleo ativo:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="93"/>
        <source>Project name:</source>
        <translation>Nome do projeto:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="100"/>
        <source>Release date:</source>
        <translation>Data do lançamento:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="107"/>
        <source>Release codename:</source>
        <translation>Codinome do lançamento:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="133"/>
        <source>Current date</source>
        <translation>Data atual</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="172"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Snapshot is a utility that creates a bootable image (ISO) of your working system that you can use for storage or distribution. You can continue working with undemanding applications while it is running.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;O ‘Snapshot’ é um utilitário que permite criar uma imagem ISO inicializável (bootable) do seu sistema operacional em execução. Esta imagem
ISO pode ser utilizada para guardar/copiar o seu sistema operacional ou para distribuir para outras pessoas. Você pode continuar trabalhando
com programas que sejam pouco exigentes enquanto o ‘Snapshot’ estiver em execução.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="182"/>
        <source>Used space on / (root) and /home partitions:</source>
        <translation>O espaço utilizado nas partições / (‘root’ ou raiz) e /home (pasta pessoal) são:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="192"/>
        <source>Location and ISO name</source>
        <translation>Local e o nome da imagem ISO</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="219"/>
        <source>Snapshot location:</source>
        <translation>Local onde será armazenada a ISO:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="226"/>
        <source>Select a different snapshot directory</source>
        <translation>Selecionar uma outra pasta para a ISO</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="236"/>
        <location filename="../src/mainwindow.cpp" line="607"/>
        <source>Snapshot name:</source>
        <translation>Nome da imagem ISO:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="360"/>
        <source>Type of snapshot:</source>
        <translation>Tipo da imagem ISO:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="367"/>
        <source>Preserving accounts (for personal backup)</source>
        <translation>Preservar a(s) conta(s) do(s) usuário(s) e fazer uma cópia de segurança do Sistema Operacional para o uso pessoal</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This option will reset &amp;quot;demo&amp;quot; and &amp;quot;root&amp;quot; passwords to the MX Linux defaults and will not copy any personal accounts created.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Esta opção permite redefinir as senhas dos usuários ‘demo’ e ‘root’ para as senhas padrões do MX Linux e não irá copiar quaisquer contas pessoais que tenham sido criadas.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="380"/>
        <source>Resetting accounts (for distribution to others)</source>
        <translation>Redefinir as contas e as senhas dos usuários ‘demo’ e ‘root’ para distribuir a imagem ISO para outras pessoas</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="451"/>
        <source>You can also exclude certain directories by ticking the common choices below, or by clicking on the button to directly edit /etc/mx-snapshot-exclude.list.</source>
        <translation>Se você quiser pode selecionar as pastas que não serão incluídas na imagem ISO, ou pode clicar no botão ‘Editar o Arquivo de Exclusão’
para editar manualmente o arquivo de configurações ‘/etc/mx-snapshot-exclude.list’.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="496"/>
        <source>sha512</source>
        <translation>sha512</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="519"/>
        <source>Throttle the I/O input rate by the given percentage.</source>
        <translation>Acelerar a taxa de entrada da E/S ou I/O pelo valor da porcentagem fornecida.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="525"/>
        <source>I/O throttle:</source>
        <translation>Acelerador de E/S:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="532"/>
        <source>Calculate checksums:</source>
        <translation>Calcular a soma de verificação:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="539"/>
        <source>ISO compression scheme:</source>
        <translation>Esquema de compactação/compressão da ISO:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="546"/>
        <source>Number of CPU cores to use:</source>
        <translation>Quantidade de núcleos do processador a serem utilizados:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="553"/>
        <source>md5</source>
        <translation>md5</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="563"/>
        <source>Options:</source>
        <translation>Opções:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="610"/>
        <source>Edit Exclusion File</source>
        <translation>Editar o Arquivo de Exclusão</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="626"/>
        <location filename="../src/mainwindow.cpp" line="863"/>
        <source>Remove Custom Exclusion File</source>
        <translation>Remover arquivo de exclusão personalizado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="679"/>
        <source>Pictures</source>
        <translation>Imagens</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="686"/>
        <source>Videos</source>
        <translation>Vídeos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="693"/>
        <source>All of the above</source>
        <translation>Todos os itens acima</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="700"/>
        <source>exclude network configurations</source>
        <translation>Excluir as configurações de rede</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="703"/>
        <source>Networks</source>
        <translation>Redes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="710"/>
        <source>Downloads</source>
        <translation>Baixados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="717"/>
        <source>Desktop</source>
        <translation>Área de Trabalho</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="724"/>
        <source>Documents</source>
        <translation>Documentos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="731"/>
        <source>Flatpaks</source>
        <translation>Flatpaks</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="738"/>
        <source>Music</source>
        <translation>Músicas</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="876"/>
        <source>About this application</source>
        <translation>Sobre este aplicativo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="879"/>
        <source>About...</source>
        <translation>Sobre...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="885"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="901"/>
        <source>Next</source>
        <translation>Próximo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="926"/>
        <source>Display help </source>
        <translation>Exibir ajuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="929"/>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="935"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="948"/>
        <source>Quit application</source>
        <translation>Sair do aplicativo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="951"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="957"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1011"/>
        <source>Back</source>
        <translation>Anterior</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="353"/>
        <source>Select Release Date</source>
        <translation>Selecionar a data do lançamento</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="397"/>
        <source>fastest, worst compression</source>
        <translation>Mais rápido e com uma compactação pior</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="397"/>
        <source>fast, worse compression</source>
        <translation>Rápido e com uma compactação pior</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="398"/>
        <source>slow, better compression</source>
        <translation>Lento e com uma compactação melhor</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="398"/>
        <source>best compromise</source>
        <translation>A melhor opção</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="399"/>
        <source>slowest, best compression</source>
        <translation>Mais lento e com uma compactação ainda melhor</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="428"/>
        <source>Free space on %1, where snapshot folder is placed: </source>
        <translation>O espaço livre na %1 onde a pasta da imagem ISO está localizada no caminho possui </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="431"/>
        <source>The free space should be sufficient to hold the compressed data from / and /home

      If necessary, you can create more available space by removing previous snapshots and saved copies: %1 snapshots are taking up %2 of disk space.</source>
        <translation>O espaço livre deve ser suficiente para armazenar os dados compactados da / (raiz do sistema operacional ou ‘root’) e da /home (pasta
pessoal). Se for necessário, você pode liberar mais espaço excluindo as imagens ISOs antigas que foram criadas pelo programa ‘Snapshot’.
As %1 imagens ISOs estão ocupando %2 de espaço em disco.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="443"/>
        <location filename="../src/mainwindow.cpp" line="444"/>
        <source>Installing </source>
        <translation>Instalando</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="550"/>
        <source>Please wait.</source>
        <translation>Por favor, aguarde.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="552"/>
        <source>Please wait. Calculating used disk space...</source>
        <translation>Por favor, aguarde. Calculando o espaço em disco a ser utilizado...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="274"/>
        <location filename="../src/mainwindow.cpp" line="586"/>
        <location filename="../src/mainwindow.cpp" line="593"/>
        <location filename="../src/mainwindow.cpp" line="675"/>
        <location filename="../src/mainwindow.cpp" line="686"/>
        <location filename="../src/mainwindow.cpp" line="928"/>
        <source>Error</source>
        <translation>Ocorreu um Erro</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="174"/>
        <location filename="../src/mainwindow.cpp" line="210"/>
        <source>Updated Exclusion List</source>
        <translation>Lista de Exclusão Atualizada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="177"/>
        <source>The exclusion file at %1 is newer than your configured file at %2.</source>
        <translation>O arquivo de exclusão em %1 é mais recente do que o arquivo configurado em %2.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="179"/>
        <source>Review the changes below. Keep your custom file or replace it with the updated default.</source>
        <translation>Confira as alterações abaixo. Mantenha seu arquivo personalizado ou substitua-o pelo arquivo padrão atualizado.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="185"/>
        <source>Show Differences</source>
        <translation>Mostrar diferenças</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="191"/>
        <source>Keep Custom</source>
        <translation>Mantenha personalizado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="197"/>
        <source>Use Updated Default</source>
        <translation>Usar padrão atualizado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="498"/>
        <source>Done</source>
        <translation>Concluído</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="587"/>
        <source>Output file %1 already exists. Please use another file name, or delete the existent file.</source>
        <translation>O arquivo da saída %1 já existe. Por favor, utilize um outro nome para o arquivo ou exclua o arquivo existente.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="594"/>
        <source>Insufficient free space. Please select a different snapshot directory or free up space.</source>
        <translation>Espaço livre insuficiente. Selecione um diretório diferente para cópia pontual ou libere espaço.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="598"/>
        <source>Settings</source>
        <translation>Configurações</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="604"/>
        <source>Snapshot will use the following settings:</source>
        <translation>O ‘Snapshot’ utilizará as seguintes configurações para a imagem ISO:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="606"/>
        <source>- Snapshot directory:</source>
        <translation>- Pasta das imagens ISO:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="607"/>
        <source>- Kernel to be used:</source>
        <translation>- Núcleo/kernel a ser utilizado:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="631"/>
        <location filename="../src/mainwindow.cpp" line="640"/>
        <source>NVIDIA Detected</source>
        <translation>Uma placa de vídeo da NVIDIA foi detectada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="632"/>
        <source>This computer uses an NVIDIA graphics card. Are you planning to use the resulting ISO on the same computer or another computer with an NVIDIA card?</source>
        <translation>Este computador utiliza uma placa de vídeo da NVIDIA. Você está planejando utilizar a imagem ISO resultante no mesmo computador ou em um outro computador que tem uma placa de vídeo da NVIDIA?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="636"/>
        <source>NVIDIA Selected</source>
        <translation>Uma placa de vídeo da NVIDIA foi selecionada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="637"/>
        <source>Note: If you use the resulting ISO on a computer without an NVIDIA card, you will likely need to remove &apos;xorg=nvidia&apos; from the boot options.</source>
        <translation>Observação: Se você utilizar a imagem ISO resultante em um computador que não tem uma placa de vídeo da NVIDIA, provavelmente será necessário remover o parâmetro ‘xorg=nvidia’ das opções de inicialização.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="641"/>
        <source>Note: If you use the resulting ISO on a computer with an NVIDIA card, you may need to add &apos;xorg=nvidia&apos; to the boot options.</source>
        <translation>Observação: Se você utilizar a imagem ISO resultante em um computador que tem uma placa de vídeo da NVIDIA, pode ser necessário adicionar o parâmetro &apos;xorg=nvidia&apos; nas opções de inicialização.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="275"/>
        <location filename="../src/mainwindow.cpp" line="676"/>
        <source>Could not replace the exclusion file with the updated default.</source>
        <translation>Não foi possível substituir o arquivo de exclusão pelo arquivo padrão atualizado.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="687"/>
        <source>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</source>
        <translation>O núcleo (kernel) atual não é compatível com o algoritmo de compactação/compressão que foi selecionado. Por favor, edite o arquivo de configurações e escolha um algoritmo diferente.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="710"/>
        <source>Final chance</source>
        <translation>Esta é a sua última chance</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="712"/>
        <source>Snapshot now has all the information it needs to create an ISO from your running system.</source>
        <translation>O programa ‘Snapshot’ possui todas as informações necessárias para criar uma imagem ISO a partir do seu sistema operacional em execução.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="713"/>
        <source>It will take some time to finish, depending on the size of the installed system and the capacity of your computer.</source>
        <translation>O processo de criação da imagem ISO irá demorar algum tempo para finalizar. O tempo pode ser maior ou menor dependendo do tamanho do seu sistema operacional que está instalado e da capacidade de processamento do seu computador.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="715"/>
        <source>OK to start?</source>
        <translation>Você quer iniciar agora?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="824"/>
        <location filename="../src/mainwindow.cpp" line="719"/>
        <source>Shutdown computer when done.</source>
        <translation>Desligar o computador quando finalizar a criação da imagem ISO.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="753"/>
        <source>Output</source>
        <translation>Resultado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="773"/>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="827"/>
        <source>Edit Boot Menu</source>
        <translation>Editar o Menu de Inicialização</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="828"/>
        <source>The program will now pause to allow you to edit any files in the work directory. Select Yes to edit the boot menu or select No to bypass this step and continue creating the snapshot.</source>
        <translation>O programa irá parar agora para permitir que você edite quaisquer arquivos que estão na pasta de trabalho. Clique na opção ‘Sim’ para editar o menu de inicialização ou clique na opção ‘Não’ para ignorar esta etapa e continuar com a criação da imagem ISO.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="864"/>
        <source>Revert the exclusion list to the default file? This will overwrite your current exclusions.</source>
        <translation>Reverter a lista de exclusões para o arquivo padrão? Isso substituirá suas exclusões atuais.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="896"/>
        <source>About %1</source>
        <translation>Sobre o %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="898"/>
        <source>Version: </source>
        <translation>Versão: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="899"/>
        <source>Program for creating a live-CD from the running system for MX Linux</source>
        <translation>O ‘Snapshot’ é um programa que permite criar uma imagem ISO do sistema operacional MX Linux em execução, podendo a imagem ISO ser executada em uma mídia de CD/DVD/USB e ainda possibilita a instalação em um computador.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="901"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Direitos de Autor (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="903"/>
        <source>%1 License</source>
        <translation>Licença do %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="916"/>
        <source>%1 Help</source>
        <translation>Ajuda do %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="921"/>
        <source>Select Snapshot Directory</source>
        <translation>Selecione a Pasta para o Snapshot</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="929"/>
        <source>Insufficient free space in the selected directory. Please choose a different location.</source>
        <translation>Espaço livre insuficiente no diretório selecionado. Por favor, escolha um local diferente.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="973"/>
        <source>Confirmation</source>
        <translation>Confirmação</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="973"/>
        <source>Are you sure you want to quit the application?</source>
        <translation>Você tem certeza de que deseja encerrar o aplicativo?</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/main.cpp" line="96"/>
        <source>Tool used for creating a live-CD from the running system</source>
        <translation>Ferramenta utilizada para criar um CD/DVD executável a partir do sistema operacional em execução</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="100"/>
        <source>Use CLI only</source>
        <translation>Utilize apenas a Interface de Linha de Comando - CLI</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="104"/>
        <source>Number of CPU cores to be used.</source>
        <translation>Quantidade de núcleos do processador a serem utilizados.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="105"/>
        <source>Output directory</source>
        <translation>Pasta de saída</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="106"/>
        <source>Output filename</source>
        <translation>Nome do arquivo de saída</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="108"/>
        <source>Name a different kernel to use other than the default running kernel, use format returned by &apos;uname -r&apos;</source>
        <translation>Nomeie o núcleo (kernel) com um nome diferente do núcleo atual em execução, utilize o formato padrão exibido no resultado do comando ‘uname -r’ no emulador de terminal.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="110"/>
        <source>Or the full path: %1</source>
        <translation>Ou o caminho completo: %1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>Compression level options.</source>
        <translation>Opções de nível de compactação/compressão.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="114"/>
        <source>Use quotes: &quot;-Xcompression-level &lt;level&gt;&quot;, or &quot;-Xalgorithm &lt;algorithm&gt;&quot;, or &quot;-Xhc&quot;, see mksquashfs man page</source>
        <translation>Utilize as aspas: “-Xcompression-level &lt;level&gt;”, ou “-Xalgorithm &lt;algorithm&gt;”, ou “-Xhc”. Por favor, consulte a página do manual do ‘mksquashfs’</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="118"/>
        <source>Create a monthly snapshot, add &apos;Month&apos; name in the ISO name, skip used space calculation</source>
        <translation>Crie uma imagem ISO mensal com o ‘Snapshot’, adicione no nome da ISO, o nome do ‘mês’ e ignore o cálculo do espaço utilizado</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="119"/>
        <source>This option sets reset-accounts and compression to defaults, arguments changing those items will be ignored</source>
        <translation>Esta opção permite redefinir as contas e a compactação para os padrões, os argumentos que alteram estes itens serão ignorados</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="121"/>
        <source>Optionally specify a suffix to add to the month name (e.g., &apos;1&apos; for &apos;July.1&apos;)</source>
        <translation>Opcionalmente, especifique um sufixo para adicionar ao nome do mês. Por exemplo, o ‘1’ para ‘1º de julho’)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="122"/>
        <source>Don&apos;t calculate checksums for resulting ISO file</source>
        <translation>Não calcular a soma de verificação para o arquivo da imagem ISO resultante</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="123"/>
        <source>Skip calculating free space to see if the resulting ISO will fit</source>
        <translation>Ignorar o cálculo do espaço livre em disco que verifica se a ISO resultante caberá ou não no disco de armazenamento</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="124"/>
        <source>Option to fix issue with calculating checksums on preempt_rt kernels</source>
        <translation>Opção para corrigir o problema com o cálculo da soma de verificação nos núcleos/kernels ‘preempt_rt’</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="125"/>
        <source>Resetting accounts (for distribution to others)</source>
        <translation>Redefinir as contas e as senhas dos usuários ‘demo’ e ‘root’ para distribuir a imagem ISO para outras pessoas</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="126"/>
        <source>Calculate checksums for resulting ISO file</source>
        <translation>Calcular a soma de verificação para o arquivo da imagem ISO resultante</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="128"/>
        <source>Throttle the I/O input rate by the given percentage. This can be used to reduce the I/O and CPU consumption of Mksquashfs.</source>
        <translation>Acelerar a taxa de entrada da E/S ou I/O pelo valor da porcentagem fornecida. Esta opção pode ser utilizada para reduzir o consumo da E/S do processador e do ‘Mksquashfs’ (ferramenta para criar e anexar sistemas de arquivos ‘squashfs’).</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="131"/>
        <source>Work directory</source>
        <translation>Pasta de trabalho</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="133"/>
        <source>Exclude main folders, valid choices: </source>
        <translation>Exclua as pastas principais, as opções válidas são:</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="135"/>
        <source>Use the option one time for each item you want to exclude</source>
        <translation>Utilize a opção uma vez para cada item que você quer excluir</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="138"/>
        <source>Compression format, valid choices: </source>
        <translation>As opções válidas para o formato de compactação/compressão são:</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="140"/>
        <source>Shutdown computer when done.</source>
        <translation>Desligar o computador quando finalizar a criação da imagem ISO.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="141"/>
        <source>Use grub for legacy mbr iso boot instead of isolinux/syslinux.</source>
        <translation>Usar o GRUB para os arquivos de inicialização ISO legado (MBR) em vez do ‘isolinux/syslinux’.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="217"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Ao que parece, você está acessando a sessão com o usuário ‘root’. Por favor, saia da sessão atual e entre novamente com o usuário normal para utilizar este programa.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="232"/>
        <source>version:</source>
        <translation>Versão:</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="228"/>
        <source>You must run this program with sudo or pkexec.</source>
        <translation>Você tem que executar este programa com o comando ‘sudo’ ou o ‘pkexec’ para ter as permissões necessárias.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="210"/>
        <source>MX Snapshot</source>
        <translation>Snapshot do MX - Criador de Imagem ISO do Sistema Operacional</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="219"/>
        <location filename="../src/main.cpp" line="297"/>
        <location filename="../src/settings.cpp" line="594"/>
        <location filename="../src/settings.cpp" line="603"/>
        <location filename="../src/settings.cpp" line="1193"/>
        <location filename="../src/settings.cpp" line="1289"/>
        <source>Error</source>
        <translation>Ocorreu um Erro</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="254"/>
        <source>Fatal error:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="256"/>
        <source>Fatal error: unknown exception</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="296"/>
        <location filename="../src/settings.cpp" line="602"/>
        <source>Current kernel doesn&apos;t support Squashfs, cannot continue.</source>
        <translation>O núcleo (kernel) atual não é compatível com o ‘Squashfs’. Por isso, não é possível continuar.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="180"/>
        <source>Exception during initialization: %1</source>
        <translation>Exceto durante a inicialização do %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="183"/>
        <source>Unknown exception during initialization</source>
        <translation>Uma exceção que não é conhecida durante a inicialização</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="219"/>
        <source>Could not create work directory. </source>
        <translation>Não foi possível criar a pasta de trabalho.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="248"/>
        <source>No supported filesystem found for the temp directory. Tried /tmp, /home, and the snapshot directory.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="266"/>
        <source>Could not create temp directory:</source>
        <translation>Não foi possível criar a pasta temporária:</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="267"/>
        <source>Please check that the parent directory exists and is writable:</source>
        <translation>Por favor, verifique se a pasta pai existe e se é gravável:</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="285"/>
        <source>Compression format &apos;%1&apos; is not supported by the current kernel</source>
        <translation>O formato da compactação/compressão ‘%1’ não é compatível pelo núcleo (kernel) atual</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="291"/>
        <source>Invalid cores setting: %1. Must be between 1 and %2</source>
        <translation>A configuração dos núcleos (cores) %1 não é válidas. O valor deve estar entre 1 e %2</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="297"/>
        <source>Invalid throttle setting: %1. Must be between 0 and 20</source>
        <translation>A configuração da aceleração ‘%1’ não é válida. O valor deve estar entre 0 e 20</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="303"/>
        <source>Snapshot directory cannot be empty</source>
        <translation>A pasta das imagens ISOs (Snapshot) não pode estar vazia</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="311"/>
        <source>Snapshot name cannot be empty</source>
        <translation>O nome da imagem ISO não pode estar vazio</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="317"/>
        <source>Snapshot name contains invalid characters: %1</source>
        <translation>O nome da imagem ISO contém caracteres que não são válidos ‘%1’</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="323"/>
        <source>Kernel version cannot be empty</source>
        <translation>A versão do núcleo (kernel) não pode estar vazia</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="328"/>
        <source>Kernel file not found: /boot/vmlinuz-%1</source>
        <translation>O arquivo do núcleo (kernel) não foi encontrado no caminho ‘/boot/vmlinuz-%1’</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="335"/>
        <source>Kernel %1 doesn&apos;t support Squashfs</source>
        <translation>O núcleo (kernel) %1 não é compatível com o ‘Squashfs’</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="366"/>
        <source>Exclusion file does not exist: %1</source>
        <translation>O arquivo %1 a ser excluído não existe</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="375"/>
        <source>Unbalanced quotes in exclusion list</source>
        <translation>Existem cotações desbalanceadas na lista de exclusão</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="400"/>
        <source>Insufficient free space: %1 KiB available, minimum %2 KiB required</source>
        <translation>O espaço livre de %1 KiB que está disponível não é suficiente, o mínimo necessário é de %2 KiB</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="407"/>
        <source>Insufficient free space in work directory: %1 KiB available, minimum %2 KiB required</source>
        <translation>O espaço livre de %1 KiB que está disponível não é suficiente na pasta de trabalho, o mínimo necessário é de %2 KiB</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="422"/>
        <source>Failed to determine number of CPU cores</source>
        <translation>Ocorreu uma falha ao determinar o número de núcleos (cores) do processador</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="428"/>
        <source>Configuration file does not exist: %1</source>
        <translation>O arquivo de configurações %1 não existe</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="429"/>
        <source>Using default settings</source>
        <translation>Utilizando as configurações padrão</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="431"/>
        <source>Cannot read configuration file: %1</source>
        <translation>Não foi possível ler o arquivo de configurações %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="432"/>
        <source>Error: %1</source>
        <translation>Ocorreu o erro %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="442"/>
        <source>Required tool not found: %1</source>
        <translation>A ferramenta necessária %1 não foi encontrada</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="451"/>
        <source>Required directory not found: %1</source>
        <translation>A pasta %1 não foi encontrada</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="470"/>
        <source>Initialization Error</source>
        <translation>Ocorreu um erro na inicialização</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="471"/>
        <source>Failed to initialize application settings:

%1</source>
        <translation>Ocorreu uma falha ao inicializar as configurações do programa:

%1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="592"/>
        <source>Could not find a usable kernel</source>
        <translation>Não foi possível encontrar um núcleo/kernel utilizável</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="593"/>
        <source>Searched for kernel files in /boot/ but none were found or accessible.</source>
        <translation>Após pesquisar por arquivos dos núcleos (kernels) na pasta ‘/boot/’, nenhum núcleo foi encontrado ou está acessível.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="615"/>
        <source>No users found in the system</source>
        <translation>Nenhum usuário foi encontrado no sistema operacional</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="618"/>
        <source>Failed to determine system information</source>
        <translation>Ocorreu uma falha ao determinar as informações do sistema operacional</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="779"/>
        <source>Used space on / (root): </source>
        <translation>O espaço utilizado na / (raiz ou ‘root’) é de </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="795"/>
        <source>estimated</source>
        <translation>foi estimado</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="800"/>
        <source>Used space on /home: </source>
        <translation>O espaço utilizado na /home é de </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="861"/>
        <source>Free space on %1, where snapshot folder is placed: </source>
        <translation>O espaço livre na %1 onde a pasta que armazena a imagem ISO é de </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="865"/>
        <source>The free space should be sufficient to hold the compressed data from / and /home

      If necessary, you can create more available space
      by removing previous snapshots and saved copies:
      %1 snapshots are taking up %2 of disk space.
</source>
        <translation>O espaço livre deve ser suficiente para armazenar os dados compactados da / (raiz do sistema operacional ou ‘root’) e da /home (pasta
pessoal). Se for necessário, você pode liberar mais espaço excluindo as imagens ISOs antigas que foram criadas pelo programa ‘Snapshot’.
As %1 imagens ISOs estão ocupando %2 de espaço em disco.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="879"/>
        <source>Desktop</source>
        <translation>Área de Trabalho</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="880"/>
        <source>Documents</source>
        <translation>Documentos</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="881"/>
        <source>Downloads</source>
        <translation>Baixados</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="882"/>
        <source>Flatpaks</source>
        <translation>Flatpaks</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="883"/>
        <source>Music</source>
        <translation>Músicas</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="884"/>
        <source>Networks</source>
        <translation>Redes</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="885"/>
        <source>Pictures</source>
        <translation>Imagens</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="887"/>
        <source>Videos</source>
        <translation>Vídeos</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1012"/>
        <source>Error reading system configuration file: %1</source>
        <translation>Ocorreu um erro ao ler o arquivo de configurações %1 do sistema operacional</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1020"/>
        <source>Error accessing user configuration</source>
        <translation>Ocorreu um erro ao acessar as configurações do usuário</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1072"/>
        <source>Could not copy exclusion file from %1 to %2</source>
        <translation>Não foi possível copiar o arquivo de exclusão de %1 para %2.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1097"/>
        <source>Invalid stored cores setting (%1). Using detected CPU count: %2</source>
        <translation>Configuração de núcleos armazenados inválida (%1). Usando a contagem de CPUs detectada: %2</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1191"/>
        <location filename="../src/settings.cpp" line="1287"/>
        <source>Output file %1 already exists. Please use another file name, or delete the existent file.</source>
        <translation>O arquivo da saída %1 já existe. Por favor, utilize um outro nome para o arquivo ou exclua o arquivo existente.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="73"/>
        <source>Could not load %1</source>
        <translation>Não foi possível carregar o %1</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>License</source>
        <translation>Licença</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <location filename="../src/about.cpp" line="107"/>
        <source>Changelog</source>
        <translation>Relatório de Alterações</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="98"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="119"/>
        <source>Could not load changelog.</source>
        <translation>Não foi possível carregar o registro das alterações.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="53"/>
        <location filename="../src/about.cpp" line="122"/>
        <source>&amp;Close</source>
        <translation>&amp;Fechar</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="77"/>
        <source>No diff output available.</source>
        <translation>Nenhuma saída de diff disponível.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="89"/>
        <source>Default exclusion file not found at %1.</source>
        <translation>Arquivo de exclusão padrão não encontrado em% 1.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="101"/>
        <source>Could not backup existing exclusion file to %1.</source>
        <translation>Não foi possível fazer backup do arquivo de exclusão existente em %1.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="105"/>
        <source>Could not remove existing exclusion file at %1.</source>
        <translation>Não foi possível remover o arquivo de exclusão existente em %1.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="112"/>
        <source>Could not copy default exclusion file from %1 to %2.</source>
        <translation>Não foi possível copiar o arquivo de exclusão padrão de %1 para %2.</translation>
    </message>
</context>
<context>
    <name>Work</name>
    <message>
        <location filename="../src/work.cpp" line="218"/>
        <source>Cleaning...</source>
        <translation>Limpando...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="239"/>
        <location filename="../src/work.cpp" line="770"/>
        <source>Done</source>
        <translation>O processo foi realizado com sucesso</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="252"/>
        <source>Interrupted or failed to complete</source>
        <translation>O processo foi interrompido ou não foi concluído</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="294"/>
        <location filename="../src/work.cpp" line="408"/>
        <location filename="../src/work.cpp" line="447"/>
        <location filename="../src/work.cpp" line="490"/>
        <location filename="../src/work.cpp" line="518"/>
        <location filename="../src/work.cpp" line="542"/>
        <location filename="../src/work.cpp" line="651"/>
        <location filename="../src/work.cpp" line="750"/>
        <location filename="../src/work.cpp" line="798"/>
        <location filename="../src/work.cpp" line="807"/>
        <location filename="../src/work.cpp" line="1063"/>
        <location filename="../src/work.cpp" line="1100"/>
        <location filename="../src/work.cpp" line="1136"/>
        <location filename="../src/work.cpp" line="1154"/>
        <source>Error</source>
        <translation>Ocorreu um Erro</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="295"/>
        <source>There&apos;s not enough free space on your target disk, you need at least %1</source>
        <translation>Não há espaço livre suficiente no disco de destino, você precisa de pelo menos %1</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="298"/>
        <source>You have %1 free space on %2</source>
        <translation>Você tem %1 espaço livre em %2</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="301"/>
        <source>If you are sure you have enough free space rerun the program with -o/--override-size option</source>
        <translation>Se você tiver certeza de que tem espaço livre suficiente, execute novamente o programa com a opção ‘-o/--override-size’</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="389"/>
        <source>Copying the new-iso filesystem...</source>
        <translation>Copiar o sistema de arquivos da nova imagem ISO...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="408"/>
        <source>ISO template not found: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="440"/>
        <source>Arch ISO template is missing boot/ or efi/ directories.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="443"/>
        <source>Detected boot/ or efi/ under the work directory root; the template may have been extracted to the wrong location.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="446"/>
        <source>Template: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="482"/>
        <source>Stale archiso initramfs detected, rebuilding...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="484"/>
        <source>Found /boot/archiso.img built for kernel %1, but the selected kernel is %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="488"/>
        <source>Rebuilding /boot/archiso.img failed. Please rebuild it manually or remove the stale file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="500"/>
        <source>No /boot/archiso.img found, attempting to create one...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="505"/>
        <source>Warning</source>
        <translation>Aviso</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="506"/>
        <source>Could not create /boot/archiso.img (is the &apos;archiso&apos; package installed?). Falling back to the regular initramfs — the resulting ISO will likely fail to boot (&quot;Failed to start Switch Root&quot;).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="518"/>
        <source>Could not find an initramfs image to use.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="543"/>
        <source>--grub-mbr option specified but boot/grub/i386-pc/eltorito.img is missing from iso-template</source>
        <translation>Apesar do GRUB para MBR ter sido escolhido, infelizmente o arquivo ‘boot/grub/i386-pc/eltorito.img’ não está presente no modelo ISO</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="556"/>
        <source>Could not create temp directory. </source>
        <translation>Não foi possível criar a pasta temporária.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="648"/>
        <source>Squashing filesystem...</source>
        <translation>Comprimindo o sistema de arquivos...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="652"/>
        <source>Could not create linuxfs file, please check /var/log/%1.log</source>
        <translation>Não foi possível criar o arquivo ‘linuxfs’. Por favor, verifique o registro das alterações ‘/var/log/%1.log’</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="747"/>
        <source>Creating CD/DVD image file...</source>
        <translation>Criar o arquivo de imagem de CD/DVD...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="751"/>
        <source>Could not create ISO file, please check whether you have enough space on the destination partition.</source>
        <translation>Não foi possível criar o arquivo da imagem ISO. Por favor, verifique se há espaço suficiente na partição de destino.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="757"/>
        <source>Making hybrid iso</source>
        <translation>Criar uma imagem ISO híbrida</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="776"/>
        <source>Success</source>
        <translation>Sucesso</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="777"/>
        <source>MX Snapshot completed successfully!</source>
        <translation>O Snapshot ISO do MX concluiu com sucesso a criação da imagem ISO!</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="778"/>
        <source>Snapshot took %1 to finish.</source>
        <translation>O Snapshot ISO do MX demorou %1 para terminar.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="779"/>
        <source>Thanks for using MX Snapshot, run MX Live USB Maker next!</source>
        <translation>Obrigado por utilizar o Snapshot do MX. Em seguida, execute o programa Criador de Dispositivo USB Executável do MX ou ‘MX Live USB Maker’!</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="795"/>
        <location filename="../src/work.cpp" line="804"/>
        <source>Installing </source>
        <translation>Instalando</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="798"/>
        <location filename="../src/work.cpp" line="807"/>
        <source>Could not install </source>
        <translation>Não foi possível instalar</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="817"/>
        <source>Calculating checksum...</source>
        <translation>Calculando a soma de verificação...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="858"/>
        <source>Building new initrd...</source>
        <translation>Construindo o novo ‘initrd’...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="961"/>
        <source>Rebuilding initramfs with: mkinitcpio %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="962"/>
        <source>Note: warnings about missing ipconfig, nfsmount, or nbd-client are harmless — those are only needed for network booting.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1064"/>
        <source>Could not create working directory. </source>
        <translation>Não foi possível criar a pasta de trabalho.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1101"/>
        <source>Could not prepare a safe bind-root overlay. Snapshot cannot continue.</source>
        <translation>Não foi possível montar um outro diretório por cima do diretório raiz do sistema. Não é possível continuar.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1137"/>
        <location filename="../src/work.cpp" line="1155"/>
        <source>Could not prepare the snapshot bind-root environment.</source>
        <translation>Não foi possível montar o ambiente de captura do diretório raiz do sistema.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1487"/>
        <source>Calculating total size of excluded files...</source>
        <translation>Calculando o tamanho total dos arquivos excluídos...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1514"/>
        <source>Calculating size of root...</source>
        <translation>Calculando o tamanho da raiz (‘root’)...</translation>
    </message>
</context>
</TS>