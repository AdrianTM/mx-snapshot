<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="ja">
<context>
    <name>Batchprocessing</name>
    <message>
        <location filename="../src/batchprocessing.cpp" line="50"/>
        <source>Error</source>
        <translation>エラー</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="51"/>
        <source>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</source>
        <translation>現在のカーネルは選択された圧縮アルゴリズムをサポートしていないので、設定ファイルを編集して別のアルゴリズムを選択してください。</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="88"/>
        <source>The program will pause the build and open the boot menu in your text editor.</source>
        <translation>このプログラムでは、ビルドを一時停止し、テキストエディタでブートメニューを開きます。</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="169"/>
        <source>Detected newer exclusion file at %1 compared to %2. Prompting for action.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="175"/>
        <source>s</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'show diff'</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="176"/>
        <source>u</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'use updated default'</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="177"/>
        <source>k</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'keep custom (update timestamp)'</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="178"/>
        <source>q</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'quit'</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="180"/>
        <source>show diff</source>
        <comment>CLI excludes prompt option label</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="181"/>
        <source>use updated default</source>
        <comment>CLI excludes prompt option label</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="182"/>
        <source>keep custom (update timestamp)</source>
        <comment>CLI excludes prompt option label</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="183"/>
        <source>quit</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>中止</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="186"/>
        <source>[%1]%2  [%3]%4  [%5]%6  [%7]%8: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="191"/>
        <source>The exclusion file at %1 is newer than your configured file at %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="207"/>
        <source>Reverted to updated default exclusion file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="220"/>
        <source>Leaving custom exclusion file unchanged.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="231"/>
        <source>Invalid choice. Please select again.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="238"/>
        <source>This computer uses an NVIDIA graphics card. Are you planning to use the resulting ISO on the same computer or another computer with an NVIDIA card?</source>
        <translation>このコンピュータは NVIDIA グラフィックカードを使用しています。出来上がった ISO をこのコンピュータ、または NVIDIA カード搭載の別コンピュータで使用する予定はありますか？</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="248"/>
        <source>Note: If you use the resulting ISO on a computer without an NVIDIA card, you will likely need to remove &apos;xorg=nvidia&apos; from the boot options.</source>
        <translation>注意。出来上がった ISO を NVIDIA カード非搭載のコンピュータで使う場合、起動オプションの中から &apos;xorg=nvidia&apos; という記述を削除する必要があります。</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="251"/>
        <source>Note: If you use the resulting ISO on a computer with an NVIDIA card, you may need to add &apos;xorg=nvidia&apos; to the boot options.</source>
        <translation>注意。出来上がった ISO を NVIDIA カード搭載コンピュータで使う場合、起動オプションに &apos;xorg=nvidia&apos; を追加する必要があるかもしれません。</translation>
    </message>
</context>
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="142"/>
        <source>No elevation tool found (pkexec/gksu/sudo).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="231"/>
        <source>Administrator Access Required</source>
        <translation>アクセスするには管理者権限が必要です</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="232"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation>この操作には管理者権限が必要です。アプリケーションを再起動し、プロンプトが表示されたらパスワードを入力してください。</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <location filename="../src/mainwindow.cpp" line="391"/>
        <location filename="../src/mainwindow.cpp" line="843"/>
        <source>MX Snapshot</source>
        <translation>MX スナップショット</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="33"/>
        <source>Optional customization</source>
        <translation>カスタムオプション</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="65"/>
        <source>Release version:</source>
        <translation>リリースのバージョン:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="79"/>
        <source>Boot options:</source>
        <translation>起動オプション:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="86"/>
        <source>Live kernel:</source>
        <translation>ライブカーネル:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="93"/>
        <source>Project name:</source>
        <translation>プロジェクト名:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="100"/>
        <source>Release date:</source>
        <translation>リリースの日付</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="107"/>
        <source>Release codename:</source>
        <translation>リリースのコード名:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="133"/>
        <source>Current date</source>
        <translation>現在の日付</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="172"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Snapshot is a utility that creates a bootable image (ISO) of your working system that you can use for storage or distribution. You can continue working with undemanding applications while it is running.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;MX スナップショットは、稼働中のシステムからストレージへのインストールまたは他人へ配布する用途で、起動可能なイメージ (ISO) を作製するユーティリティです。少ない手順で作業を進める事ができます。&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="182"/>
        <source>Used space on / (root) and /home partitions:</source>
        <translation>/ (root) および /home パーティションの空き容量を使用します: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="192"/>
        <source>Location and ISO name</source>
        <translation>場所と ISO の名称</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="219"/>
        <source>Snapshot location:</source>
        <translation>スナップショットの保存場所:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="226"/>
        <source>Select a different snapshot directory</source>
        <translation>差分スナップショットのディレクトリを選択</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="236"/>
        <location filename="../src/mainwindow.cpp" line="607"/>
        <source>Snapshot name:</source>
        <translation>スナップショットのファイル名:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="360"/>
        <source>Type of snapshot:</source>
        <translation>スナップショットの種類:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="367"/>
        <source>Preserving accounts (for personal backup)</source>
        <translation>アカウントの保存 (個人的なバックアップ用途)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This option will reset &amp;quot;demo&amp;quot; and &amp;quot;root&amp;quot; passwords to the MX Linux defaults and will not copy any personal accounts created.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;このオプションでは、MX Linux の「demo」と「root」パスワードを既定にリセットします。また、作成した個人アカウントはコピーしません。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="380"/>
        <source>Resetting accounts (for distribution to others)</source>
        <translation>アカウントのリセット (他人へ配布する用途)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="451"/>
        <source>You can also exclude certain directories by ticking the common choices below, or by clicking on the button to directly edit /etc/mx-snapshot-exclude.list.</source>
        <translation>以下の一般的な選択肢にチェックを入れるか、またはボタンをクリックして /etc/mx-snapshot-exclude.list を直接編集することによっても、特定のディレクトリを除外することができます。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="496"/>
        <source>sha512</source>
        <translation>sha512</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="519"/>
        <source>Throttle the I/O input rate by the given percentage.</source>
        <translation>I/O 入力レートを指定したパーセンテージに制御します。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="525"/>
        <source>I/O throttle:</source>
        <translation>I/O スロットリング:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="532"/>
        <source>Calculate checksums:</source>
        <translation>チェックサムの生成:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="539"/>
        <source>ISO compression scheme:</source>
        <translation>ISO 圧縮方式：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="546"/>
        <source>Number of CPU cores to use:</source>
        <translation>使用する CPU コア数:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="553"/>
        <source>md5</source>
        <translation>md5</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="563"/>
        <source>Options:</source>
        <translation>オプション:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="610"/>
        <source>Edit Exclusion File</source>
        <translation>除外するファイルを編集</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="626"/>
        <location filename="../src/mainwindow.cpp" line="863"/>
        <source>Remove Custom Exclusion File</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="679"/>
        <source>Pictures</source>
        <translation>画像</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="686"/>
        <source>Videos</source>
        <translation>動画</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="693"/>
        <source>All of the above</source>
        <translation>上記すべて</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="700"/>
        <source>exclude network configurations</source>
        <translation>ネットワークの設定を除外します</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="703"/>
        <source>Networks</source>
        <translation>ネットワーク</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="710"/>
        <source>Downloads</source>
        <translation>ダウンロード</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="717"/>
        <source>Desktop</source>
        <translation>デスクトップ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="724"/>
        <source>Documents</source>
        <translation>文書</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="731"/>
        <source>Flatpaks</source>
        <translation>Flatpaks</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="738"/>
        <source>Music</source>
        <translation>音楽</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="876"/>
        <source>About this application</source>
        <translation>このアプリケーションについて</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="879"/>
        <source>About...</source>
        <translation>情報...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="885"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="901"/>
        <source>Next</source>
        <translation>次へ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="926"/>
        <source>Display help </source>
        <translation>ヘルプを表示</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="929"/>
        <source>Help</source>
        <translation>ヘルプ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="935"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="948"/>
        <source>Quit application</source>
        <translation>アプリケーションの終了</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="951"/>
        <source>Cancel</source>
        <translation>キャンセル</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="957"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1011"/>
        <source>Back</source>
        <translation>戻る</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="353"/>
        <source>Select Release Date</source>
        <translation>リリースの日付を選択</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="397"/>
        <source>fastest, worst compression</source>
        <translation>最も高速ですが低圧縮です</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="397"/>
        <source>fast, worse compression</source>
        <translation>高速ですがやや低圧縮です</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="398"/>
        <source>slow, better compression</source>
        <translation>低速ですが良く圧縮できます</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="398"/>
        <source>best compromise</source>
        <translation>最もバランスの良い選択です</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="399"/>
        <source>slowest, best compression</source>
        <translation>最も低速ですが高圧縮です</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="428"/>
        <source>Free space on %1, where snapshot folder is placed: </source>
        <translation>スナップショットのフォルダがある場所の空き容量 %1：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="431"/>
        <source>The free space should be sufficient to hold the compressed data from / and /home

      If necessary, you can create more available space by removing previous snapshots and saved copies: %1 snapshots are taking up %2 of disk space.</source>
        <translation>空き容量は / と /home の圧縮データを保持するのに十分でなくてはなりません。

      必要に応じて、以前作成したスナップショットや保存済みのコピーを削除して、使用可能な領域を増やすことができます。 %1 スナップショットはディスク領域の %2 を占有しています。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="443"/>
        <location filename="../src/mainwindow.cpp" line="444"/>
        <source>Installing </source>
        <translation>インストール中</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="550"/>
        <source>Please wait.</source>
        <translation>お待ちください。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="552"/>
        <source>Please wait. Calculating used disk space...</source>
        <translation>お待ちください。使用済みディスク容量を計算しています...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="274"/>
        <location filename="../src/mainwindow.cpp" line="586"/>
        <location filename="../src/mainwindow.cpp" line="593"/>
        <location filename="../src/mainwindow.cpp" line="675"/>
        <location filename="../src/mainwindow.cpp" line="686"/>
        <location filename="../src/mainwindow.cpp" line="928"/>
        <source>Error</source>
        <translation>エラー</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="174"/>
        <location filename="../src/mainwindow.cpp" line="210"/>
        <source>Updated Exclusion List</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="177"/>
        <source>The exclusion file at %1 is newer than your configured file at %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="179"/>
        <source>Review the changes below. Keep your custom file or replace it with the updated default.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="185"/>
        <source>Show Differences</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="191"/>
        <source>Keep Custom</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="197"/>
        <source>Use Updated Default</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="498"/>
        <source>Done</source>
        <translation>完了</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="587"/>
        <source>Output file %1 already exists. Please use another file name, or delete the existent file.</source>
        <translation>出力ファイル名 %1 はすでに存在します。別の名前を使用するか、すでにあるそのファイルを削除してください。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="594"/>
        <source>Insufficient free space. Please select a different snapshot directory or free up space.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="598"/>
        <source>Settings</source>
        <translation>設定中</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="604"/>
        <source>Snapshot will use the following settings:</source>
        <translation>スナップショットでは、今後以下の設定に従います。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="606"/>
        <source>- Snapshot directory:</source>
        <translation>- スナップショットのディレクトリ: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="607"/>
        <source>- Kernel to be used:</source>
        <translation>- 使用するカーネル: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="631"/>
        <location filename="../src/mainwindow.cpp" line="640"/>
        <source>NVIDIA Detected</source>
        <translation>NVIDIA を検出</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="632"/>
        <source>This computer uses an NVIDIA graphics card. Are you planning to use the resulting ISO on the same computer or another computer with an NVIDIA card?</source>
        <translation>このコンピュータは NVIDIA グラフィックカードを使用しています。出来上がった ISO をこのコンピュータ、または NVIDIA カード搭載の別コンピュータで使用する予定はありますか？</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="636"/>
        <source>NVIDIA Selected</source>
        <translation>NVIDIA を選択中</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="637"/>
        <source>Note: If you use the resulting ISO on a computer without an NVIDIA card, you will likely need to remove &apos;xorg=nvidia&apos; from the boot options.</source>
        <translation>注意。出来上がった ISO を NVIDIA カード非搭載のコンピュータで使う場合、起動オプションの中から &apos;xorg=nvidia&apos; という記述を削除する必要があります。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="641"/>
        <source>Note: If you use the resulting ISO on a computer with an NVIDIA card, you may need to add &apos;xorg=nvidia&apos; to the boot options.</source>
        <translation>注意。出来上がった ISO を NVIDIA カード搭載コンピュータで使う場合、起動オプションに &apos;xorg=nvidia&apos; を追加する必要があるかもしれません。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="275"/>
        <location filename="../src/mainwindow.cpp" line="676"/>
        <source>Could not replace the exclusion file with the updated default.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="687"/>
        <source>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</source>
        <translation>現在のカーネルは選択された圧縮アルゴリズムをサポートしていないので、設定ファイルを編集して別のアルゴリズムを選択してください。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="710"/>
        <source>Final chance</source>
        <translation>最終確認</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="712"/>
        <source>Snapshot now has all the information it needs to create an ISO from your running system.</source>
        <translation>MX スナップショットには現在、稼働しているシステムから ISO を生成するために必要な全情報を含んでいます。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="713"/>
        <source>It will take some time to finish, depending on the size of the installed system and the capacity of your computer.</source>
        <translation>作業完了までにかかる時間は、インストールを行うシステムのサイズとコンピュータの性能によって異なります。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="715"/>
        <source>OK to start?</source>
        <translation>OK で開始します</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="824"/>
        <location filename="../src/mainwindow.cpp" line="719"/>
        <source>Shutdown computer when done.</source>
        <translation>完了したらコンピュータをシャットダウンする。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="753"/>
        <source>Output</source>
        <translation>出力</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="773"/>
        <source>Close</source>
        <translation>閉じる</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="827"/>
        <source>Edit Boot Menu</source>
        <translation>起動メニューの編集</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="828"/>
        <source>The program will now pause to allow you to edit any files in the work directory. Select Yes to edit the boot menu or select No to bypass this step and continue creating the snapshot.</source>
        <translation>プログラムは、作業ディレクトリで任意ファイルを編集できるように、一時休止しています。「はい」を選んで起動メニューを編集するか、「いいえ」を選んでこのステップを飛ばしてスナップショットの作成を継続するかを選んでください。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="864"/>
        <source>Revert the exclusion list to the default file? This will overwrite your current exclusions.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="896"/>
        <source>About %1</source>
        <translation> %1 について</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="898"/>
        <source>Version: </source>
        <translation>バージョン: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="899"/>
        <source>Program for creating a live-CD from the running system for MX Linux</source>
        <translation>起動中の MX Linux を元にして Live CD を生成するプログラム</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="901"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="903"/>
        <source>%1 License</source>
        <translation>%1 ライセンス</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="916"/>
        <source>%1 Help</source>
        <translation>%1 のヘルプ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="921"/>
        <source>Select Snapshot Directory</source>
        <translation>スナップショットを保存するディレクトリを選択</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="929"/>
        <source>Insufficient free space in the selected directory. Please choose a different location.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="973"/>
        <source>Confirmation</source>
        <translation>確認</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="973"/>
        <source>Are you sure you want to quit the application?</source>
        <translation>本当にこのアプリを終了しますか？</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/main.cpp" line="96"/>
        <source>Tool used for creating a live-CD from the running system</source>
        <translation>稼働中のシステムから Live-CD を作成するツール</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="100"/>
        <source>Use CLI only</source>
        <translation>コマンドラインのみ使用する</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="104"/>
        <source>Number of CPU cores to be used.</source>
        <translation>使用する CPU のコアの数です</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="105"/>
        <source>Output directory</source>
        <translation>出力先のディレクトリ</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="106"/>
        <source>Output filename</source>
        <translation>出力先のファイル名</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="108"/>
        <source>Name a different kernel to use other than the default running kernel, use format returned by &apos;uname -r&apos;</source>
        <translation>別のカーネル名を指定して、既定で動作しているカーネル以外を使用します。なお、&apos;uname -r&apos; が返す書式を利用します。</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="110"/>
        <source>Or the full path: %1</source>
        <translation>またはフルパス： %1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>Compression level options.</source>
        <translation>圧縮レベルのオプション。</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="114"/>
        <source>Use quotes: &quot;-Xcompression-level &lt;level&gt;&quot;, or &quot;-Xalgorithm &lt;algorithm&gt;&quot;, or &quot;-Xhc&quot;, see mksquashfs man page</source>
        <translation>引用符を使って、 &quot;-Xcompression-level &lt;level&gt;&quot; または &quot;-Xalgorithm &lt;algorithm&gt;&quot; または &quot;-Xhc&quot; とします。詳しくは mksquashfs のマニュアルページを見てください。</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="118"/>
        <source>Create a monthly snapshot, add &apos;Month&apos; name in the ISO name, skip used space calculation</source>
        <translation>月毎のスナップショットの作成。ISO名に月名を追加し、使用済み容量の計算をスキップ。</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="119"/>
        <source>This option sets reset-accounts and compression to defaults, arguments changing those items will be ignored</source>
        <translation>このオプションは reset-accounts と compression を既定に設定し、これらの項目を変更する引数は無視します。</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="121"/>
        <source>Optionally specify a suffix to add to the month name (e.g., &apos;1&apos; for &apos;July.1&apos;)</source>
        <translation>オプションで、月名に追加する接尾辞を指定できます。（例えば、&apos;July.1&apos; の場合は &apos;1&apos; を指定します）</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="122"/>
        <source>Don&apos;t calculate checksums for resulting ISO file</source>
        <translation>作成した ISO ファイルのチェックサムを計算しない</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="123"/>
        <source>Skip calculating free space to see if the resulting ISO will fit</source>
        <translation>作成する ISO が収まるかどうかの、空き容量計算をスキップする</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="124"/>
        <source>Option to fix issue with calculating checksums on preempt_rt kernels</source>
        <translation>preempt_rt カーネルでのチェックサムに関する問題を修正するためのオプション</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="125"/>
        <source>Resetting accounts (for distribution to others)</source>
        <translation>アカウントのリセット (他人へ配布する用途向け)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="126"/>
        <source>Calculate checksums for resulting ISO file</source>
        <translation>作成したISOファイルのチェックサムを算出する</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="128"/>
        <source>Throttle the I/O input rate by the given percentage. This can be used to reduce the I/O and CPU consumption of Mksquashfs.</source>
        <translation>I/O入力レートを指定したパーセンテージに制御します。これは Mksquashfs の I/O と CPU の消費を低減する目的で使用できます。</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="131"/>
        <source>Work directory</source>
        <translation>作業用ディレクトリ</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="133"/>
        <source>Exclude main folders, valid choices: </source>
        <translation>メインフォルダの除外、有効にするオプション:</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="135"/>
        <source>Use the option one time for each item you want to exclude</source>
        <translation>除外したい項目毎に、１度だけ使用してください</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="138"/>
        <source>Compression format, valid choices: </source>
        <translation>有効にする圧縮形式の選択: </translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="140"/>
        <source>Shutdown computer when done.</source>
        <translation>完了したらコンピュータをシャットダウンする。</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="141"/>
        <source>Use grub for legacy mbr iso boot instead of isolinux/syslinux.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="217"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>root ユーザとしてログインしているようです。このプログラムを使用するには、一度ログアウトして通常のユーザとしてログインしてください。</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="232"/>
        <source>version:</source>
        <translation>バージョン:</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="228"/>
        <source>You must run this program with sudo or pkexec.</source>
        <translation>このプログラムは、sudo または pkexec で実行する必要があります。</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="210"/>
        <source>MX Snapshot</source>
        <translation>MX スナップショット</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="219"/>
        <location filename="../src/main.cpp" line="297"/>
        <location filename="../src/settings.cpp" line="594"/>
        <location filename="../src/settings.cpp" line="603"/>
        <location filename="../src/settings.cpp" line="1193"/>
        <location filename="../src/settings.cpp" line="1289"/>
        <source>Error</source>
        <translation>エラー</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="254"/>
        <source>Fatal error:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="256"/>
        <source>Fatal error: unknown exception</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="296"/>
        <location filename="../src/settings.cpp" line="602"/>
        <source>Current kernel doesn&apos;t support Squashfs, cannot continue.</source>
        <translation>現在のカーネルは Squashfs をサポートしてないので続行できません。</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="180"/>
        <source>Exception during initialization: %1</source>
        <translation>初期化中に例外が発生しました: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="183"/>
        <source>Unknown exception during initialization</source>
        <translation>初期化中に不明な例外が発生しました</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="219"/>
        <source>Could not create work directory. </source>
        <translation>作業用ディレクトリを作成できません。</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="248"/>
        <source>No supported filesystem found for the temp directory. Tried /tmp, /home, and the snapshot directory.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="266"/>
        <source>Could not create temp directory:</source>
        <translation>テンポラリディレクトリを作成できません:</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="267"/>
        <source>Please check that the parent directory exists and is writable:</source>
        <translation>親ディレクトリが存在し、書き込み可能かどうかをチェックしてください:</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="285"/>
        <source>Compression format &apos;%1&apos; is not supported by the current kernel</source>
        <translation>現在のカーネルは、圧縮形式 &apos;%1&apos; をサポートしません</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="291"/>
        <source>Invalid cores setting: %1. Must be between 1 and %2</source>
        <translation>無効なコア数設定: %1。1 から %2 の範囲にしてください</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="297"/>
        <source>Invalid throttle setting: %1. Must be between 0 and 20</source>
        <translation>無効なスロットル設定: %1。0 から 20 の範囲にしてください</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="303"/>
        <source>Snapshot directory cannot be empty</source>
        <translation>スナップショットディレクトリは空にできません</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="311"/>
        <source>Snapshot name cannot be empty</source>
        <translation>スナップショット名は空欄にできません</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="317"/>
        <source>Snapshot name contains invalid characters: %1</source>
        <translation>スナップショット名に次の無効な文字が含まれています: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="323"/>
        <source>Kernel version cannot be empty</source>
        <translation>カーネルのバージョンは空欄にできません</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="328"/>
        <source>Kernel file not found: /boot/vmlinuz-%1</source>
        <translation>カーネルファイルが見つかりません: /boot/vmlinuz-%1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="335"/>
        <source>Kernel %1 doesn&apos;t support Squashfs</source>
        <translation>カーネル %1 は Squashfs をサポートしません</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="366"/>
        <source>Exclusion file does not exist: %1</source>
        <translation>除外ファイルは存在しません: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="375"/>
        <source>Unbalanced quotes in exclusion list</source>
        <translation>除外リスト内の引用符がおかしいです</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="400"/>
        <source>Insufficient free space: %1 KiB available, minimum %2 KiB required</source>
        <translation>十分な空き容量がありません: %1 KiB が利用可能で、最小は %2 KiB 必要です</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="407"/>
        <source>Insufficient free space in work directory: %1 KiB available, minimum %2 KiB required</source>
        <translation>作業用ディレクトリ内の空き容量が不足です: %1 KiB の空き、最低 %2 KiB が必要</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="422"/>
        <source>Failed to determine number of CPU cores</source>
        <translation>CPU コア数の判定ができません</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="428"/>
        <source>Configuration file does not exist: %1</source>
        <translation>設定ファイルが存在しません: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="429"/>
        <source>Using default settings</source>
        <translation>既定の設定を使用する</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="431"/>
        <source>Cannot read configuration file: %1</source>
        <translation>設定ファイルを読み込めません: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="432"/>
        <source>Error: %1</source>
        <translation>エラー: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="442"/>
        <source>Required tool not found: %1</source>
        <translation>必要なツールが見つかりません: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="451"/>
        <source>Required directory not found: %1</source>
        <translation>指定のディレクトリが見つかりません: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="470"/>
        <source>Initialization Error</source>
        <translation>初期化エラー</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="471"/>
        <source>Failed to initialize application settings:

%1</source>
        <translation>アプリケーション設定の初期化に失敗しました:

%1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="592"/>
        <source>Could not find a usable kernel</source>
        <translation>使用可能なカーネルが見つかりません</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="593"/>
        <source>Searched for kernel files in /boot/ but none were found or accessible.</source>
        <translation>/boot/ ディレクトリ内でカーネルファイルを検索しましたが、見つからなかったかアクセス不可でした。</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="615"/>
        <source>No users found in the system</source>
        <translation>システム内にユーザーが見つかりません</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="618"/>
        <source>Failed to determine system information</source>
        <translation>システム情報が取得できません</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="779"/>
        <source>Used space on / (root): </source>
        <translation>/ (root) の空き容量: </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="795"/>
        <source>estimated</source>
        <translation>推定</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="800"/>
        <source>Used space on /home: </source>
        <translation>/home の空き容量: </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="861"/>
        <source>Free space on %1, where snapshot folder is placed: </source>
        <translation>スナップショットを作成するフォルダがある場所の空き容量 %1：</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="865"/>
        <source>The free space should be sufficient to hold the compressed data from / and /home

      If necessary, you can create more available space
      by removing previous snapshots and saved copies:
      %1 snapshots are taking up %2 of disk space.
</source>
        <translation>/ および /home の圧縮データを保管するには、十分な空き容量がないといけません。必要に応じて、以前生成したスナップショットや保存したコピーを削除することで空き容量を増やすことができます:　スナップショット %1 は空き容量の %2 を消費しています。</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="879"/>
        <source>Desktop</source>
        <translation>デスクトップ</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="880"/>
        <source>Documents</source>
        <translation>文書</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="881"/>
        <source>Downloads</source>
        <translation>ダウンロード</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="882"/>
        <source>Flatpaks</source>
        <translation>Flatpaks</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="883"/>
        <source>Music</source>
        <translation>音楽</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="884"/>
        <source>Networks</source>
        <translation>ネットワーク</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="885"/>
        <source>Pictures</source>
        <translation>画像</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="887"/>
        <source>Videos</source>
        <translation>動画</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1012"/>
        <source>Error reading system configuration file: %1</source>
        <translation>システム設定ファイルの読み込みエラー: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1020"/>
        <source>Error accessing user configuration</source>
        <translation>ユーザ設定へのアクセス中にエラーが発生しました</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1072"/>
        <source>Could not copy exclusion file from %1 to %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1097"/>
        <source>Invalid stored cores setting (%1). Using detected CPU count: %2</source>
        <translation>保存したコア設定は (%1) は無効です。検出した CPU 数 %2 を使用します。</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1191"/>
        <location filename="../src/settings.cpp" line="1287"/>
        <source>Output file %1 already exists. Please use another file name, or delete the existent file.</source>
        <translation>出力ファイル名 %1 はすでに存在します。別の名前を使用するか、すでにあるそのファイルを削除してください。</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="73"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>License</source>
        <translation>ライセンス</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <location filename="../src/about.cpp" line="107"/>
        <source>Changelog</source>
        <translation>更新履歴</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="98"/>
        <source>Cancel</source>
        <translation>キャンセル</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="119"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="53"/>
        <location filename="../src/about.cpp" line="122"/>
        <source>&amp;Close</source>
        <translation>閉じる(&amp;C)</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="77"/>
        <source>No diff output available.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="89"/>
        <source>Default exclusion file not found at %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="101"/>
        <source>Could not backup existing exclusion file to %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="105"/>
        <source>Could not remove existing exclusion file at %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="112"/>
        <source>Could not copy default exclusion file from %1 to %2.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Work</name>
    <message>
        <location filename="../src/work.cpp" line="218"/>
        <source>Cleaning...</source>
        <translation>クリーニング中...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="239"/>
        <location filename="../src/work.cpp" line="770"/>
        <source>Done</source>
        <translation>完了</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="252"/>
        <source>Interrupted or failed to complete</source>
        <translation>中断されたか、または完了できませんでした</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="294"/>
        <location filename="../src/work.cpp" line="408"/>
        <location filename="../src/work.cpp" line="447"/>
        <location filename="../src/work.cpp" line="490"/>
        <location filename="../src/work.cpp" line="518"/>
        <location filename="../src/work.cpp" line="542"/>
        <location filename="../src/work.cpp" line="651"/>
        <location filename="../src/work.cpp" line="750"/>
        <location filename="../src/work.cpp" line="798"/>
        <location filename="../src/work.cpp" line="807"/>
        <location filename="../src/work.cpp" line="1063"/>
        <location filename="../src/work.cpp" line="1100"/>
        <location filename="../src/work.cpp" line="1136"/>
        <location filename="../src/work.cpp" line="1154"/>
        <source>Error</source>
        <translation>エラー</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="295"/>
        <source>There&apos;s not enough free space on your target disk, you need at least %1</source>
        <translation>作成するディスクに十分な空き領域がありません。最低でも %1 必要です</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="298"/>
        <source>You have %1 free space on %2</source>
        <translation>%2 に %1 の空き領域があります</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="301"/>
        <source>If you are sure you have enough free space rerun the program with -o/--override-size option</source>
        <translation>充分な空き容量があると分かっているのであれば、-o/--override-size オプションを付けてプログラムを再実行してください。</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="389"/>
        <source>Copying the new-iso filesystem...</source>
        <translation>新たな iso ファイルシステムをコピー中...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="408"/>
        <source>ISO template not found: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="440"/>
        <source>Arch ISO template is missing boot/ or efi/ directories.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="443"/>
        <source>Detected boot/ or efi/ under the work directory root; the template may have been extracted to the wrong location.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="446"/>
        <source>Template: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="482"/>
        <source>Stale archiso initramfs detected, rebuilding...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="484"/>
        <source>Found /boot/archiso.img built for kernel %1, but the selected kernel is %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="488"/>
        <source>Rebuilding /boot/archiso.img failed. Please rebuild it manually or remove the stale file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="500"/>
        <source>No /boot/archiso.img found, attempting to create one...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="505"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="506"/>
        <source>Could not create /boot/archiso.img (is the &apos;archiso&apos; package installed?). Falling back to the regular initramfs — the resulting ISO will likely fail to boot (&quot;Failed to start Switch Root&quot;).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="518"/>
        <source>Could not find an initramfs image to use.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="543"/>
        <source>--grub-mbr option specified but boot/grub/i386-pc/eltorito.img is missing from iso-template</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="556"/>
        <source>Could not create temp directory. </source>
        <translation>temp ディレクトリを作成できませんでした。</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="648"/>
        <source>Squashing filesystem...</source>
        <translation>ファイルシステムに Squash を適用中...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="652"/>
        <source>Could not create linuxfs file, please check /var/log/%1.log</source>
        <translation>linuxfs ファイルを作成できませんでした。/var/log/%1.log をチェックしてください。</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="747"/>
        <source>Creating CD/DVD image file...</source>
        <translation>CD/DVD イメージファイルを生成中...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="751"/>
        <source>Could not create ISO file, please check whether you have enough space on the destination partition.</source>
        <translation>ISOファイルを作成できませんでした。パーティションに十分な空き容量があるかご確認ください。</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="757"/>
        <source>Making hybrid iso</source>
        <translation>ハイブリット ISO を作成中</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="776"/>
        <source>Success</source>
        <translation>成功</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="777"/>
        <source>MX Snapshot completed successfully!</source>
        <translation>MX スナップショットの作成に成功しました！</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="778"/>
        <source>Snapshot took %1 to finish.</source>
        <translation>スナップショットの作成が完了するまで %1 かかりました。</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="779"/>
        <source>Thanks for using MX Snapshot, run MX Live USB Maker next!</source>
        <translation>MX スナップショットをご利用いただきありがとうございました。続いて MX Live USB メーカ を起動してください！</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="795"/>
        <location filename="../src/work.cpp" line="804"/>
        <source>Installing </source>
        <translation>インストール中</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="798"/>
        <location filename="../src/work.cpp" line="807"/>
        <source>Could not install </source>
        <translation>インストールできません</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="817"/>
        <source>Calculating checksum...</source>
        <translation>チェックサムの計算中...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="858"/>
        <source>Building new initrd...</source>
        <translation>新しい initrd を構築中...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="961"/>
        <source>Rebuilding initramfs with: mkinitcpio %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="962"/>
        <source>Note: warnings about missing ipconfig, nfsmount, or nbd-client are harmless — those are only needed for network booting.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1064"/>
        <source>Could not create working directory. </source>
        <translation>作業用ディレクトリを作成できませんでした。</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1101"/>
        <source>Could not prepare a safe bind-root overlay. Snapshot cannot continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1137"/>
        <location filename="../src/work.cpp" line="1155"/>
        <source>Could not prepare the snapshot bind-root environment.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1487"/>
        <source>Calculating total size of excluded files...</source>
        <translation>除外するファイルの合計サイズを計算中です...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1514"/>
        <source>Calculating size of root...</source>
        <translation>root のサイズを計算中です...</translation>
    </message>
</context>
</TS>