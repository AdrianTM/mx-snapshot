<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="el">
<context>
    <name>Batchprocessing</name>
    <message>
        <location filename="../src/batchprocessing.cpp" line="53"/>
        <source>Error</source>
        <translation>Σφάλμα</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="54"/>
        <source>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</source>
        <translation>Ο ενεργός πυρήνας δεν υποστηρίζει τον επιλεγμένο αλγόριθμο συμπίεσης, παρακαλώ επεξεργαστείτε το αρχείο παραμέτρων επιλέγοντας διαφορετικό αλγόριθμο.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="101"/>
        <source>The program will pause the build and open the boot menu in your text editor.</source>
        <translation>Το πρόγραμμα θα σταματήσει και θα ανοίξει το μενού του φορτωτή εκκίνησης με τον επεξεργαστή κειμένου σας.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="114"/>
        <source>The boot-menu editor failed; the snapshot cannot continue with potentially unedited files.</source>
        <translation>Η επεξεργασία του μενού εκκίνησης απέτυχε, η δημιουργία του στιγμιότυπου δεν μπορεί να συνεχιστεί, ενδέχεται να υπάρχουν αρχεία που δεν έχουν υποστεί επεξεργασία.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="131"/>
        <source>Administrator access was not granted; the snapshot cannot continue.</source>
        <translation>Δεν χορηγήθηκε πρόσβαση διαχειριστή, η δημιουργία στιγμιότυπου δεν μπορεί να συνεχιστεί.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="258"/>
        <source>Detected newer exclusion file at %1 compared to %2. Prompting for action.</source>
        <translation>Ανιχνεύθηκε νεώτερο αρχείο εξαιρέσεων στο %1 σε σύγκριση με το %2. Ενέργειες.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="264"/>
        <source>s</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'show diff'</comment>
        <translation>s</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="265"/>
        <source>u</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'use updated default'</comment>
        <translation>u</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="266"/>
        <source>k</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'keep custom (update timestamp)'</comment>
        <translation>k</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="267"/>
        <source>q</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'quit'</comment>
        <translation>q</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="269"/>
        <source>show diff</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>εμφάνιση διαφορών</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="270"/>
        <source>use updated default</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>χρήση του ενημερωμένου</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="271"/>
        <source>keep custom (update timestamp)</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>διατήρηση του προσαρμοσμένου (ενημέρωση ημερομηνίας)</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="272"/>
        <source>quit</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>εγκατάλειψη</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="275"/>
        <source>[%1]%2  [%3]%4  [%5]%6  [%7]%8: </source>
        <translation>[%1]%2  [%3]%4  [%5]%6  [%7]%8: </translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="280"/>
        <source>The exclusion file at %1 is newer than your configured file at %2.</source>
        <translation>Το αρχείο εξαιρέσεων στο %1 είναι νεώτερο από το αρχείο που έχετε ρυθμίσει στο %2.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="296"/>
        <source>Reverted to updated default exclusion file.</source>
        <translation>Επαναφορά προεπιλεγμένων εξαιρέσεων στο ενημερωμένο αρχείο.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="313"/>
        <source>No input available to answer the exclusion file prompt; aborting without creating a snapshot.</source>
        <translation>Δεν υπάρχουν δεδομένα σχετικά με το αρχείο εξαίρεσης, η διαδικασία διακόπτεται χωρίς να δημιουργηθεί στιγμιότυπο.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="316"/>
        <source>Leaving custom exclusion file unchanged.</source>
        <translation>Διατήρηση του προσαρμοσμένου αρχείου εξαιρέσεων.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="327"/>
        <source>Invalid choice. Please select again.</source>
        <translation>Μη έγκυρη επιλογή. Παρακαλώ επιλέξτε πάλι.</translation>
    </message>
</context>
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="121"/>
        <source>No elevation tool found (pkexec/gksu/sudo).</source>
        <translation>Δεν βρέθηκε εργαλείο απόκτησης δικαιωμάτων (pkexec/gksu/sudo).</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="212"/>
        <source>Failed to start command: %1</source>
        <translation>Απέτυχε η εκκίνηση της εντολής: %1</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="283"/>
        <source>Administrator access was not granted (authentication cancelled or denied).</source>
        <translation>Δεν χορηγήθηκε πρόσβαση διαχειριστή (η πιστοποίηση ακυρώθηκε ή απορρίφθηκε).</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <location filename="../src/mainwindow.cpp" line="396"/>
        <location filename="../src/mainwindow.cpp" line="944"/>
        <source>MX Snapshot</source>
        <translation>MX Στιγμιότυπο εγκατάστασης</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="33"/>
        <source>Optional customization</source>
        <translation>Προαιρετική παραμετροποίηση</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="65"/>
        <source>Release version:</source>
        <translation>Έκδοση:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="79"/>
        <source>Boot options:</source>
        <translation>Ρυθμίσεις φορτωτή εκκίνησης:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="86"/>
        <source>Live kernel:</source>
        <translation>Ενεργός πυρήνας:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="93"/>
        <source>Project name:</source>
        <translation>Όνομα προϊόντος:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="100"/>
        <source>Release date:</source>
        <translation>Ημερομηνία κυκλοφορίας:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="107"/>
        <source>Release codename:</source>
        <translation>Κωδικό όνομα έκδοσης:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="133"/>
        <source>Current date</source>
        <translation>Σημερινή ημερομηνία</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="172"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Snapshot is a utility that creates a bootable image (ISO) of your working system that you can use for storage or distribution. You can continue working with undemanding applications while it is running.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Το στιγμιότυπο εγκατάστασης είναι εργαλείο δημιουργίας εικόνας (ISO) με δυνατότητα εκκίνησης του ενεργού συστήματος σας, μπορείτε να το χρησιμοποιήσετε για αποθήκευση ή διανομή. Κατά τη διάρκεια της λειτουργίας του, μπορείτε να συνεχίσετε την εργασία σας με εφαρμογές χωρίς ιδιαίτερες απαιτήσεις.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="182"/>
        <source>Used space on / (root) and /home partitions:</source>
        <translation>Χώρος που χρησιμοποιείται για το / (root) και το /home:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="192"/>
        <source>Location and ISO name</source>
        <translation>Τοποθεσία και όνομα του ISO</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="219"/>
        <source>Snapshot location:</source>
        <translation>Κατάλογος του στιγμιότυπου:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="226"/>
        <source>Select a different snapshot directory</source>
        <translation>Επιλογή διαφορετικού καταλόγου</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="236"/>
        <location filename="../src/mainwindow.cpp" line="644"/>
        <source>Snapshot name:</source>
        <translation>Όνομα του στιγμιότυπου:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="360"/>
        <source>Type of snapshot:</source>
        <translation>Μορφή στιγμιότυπου:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="367"/>
        <source>Preserving accounts (for personal backup)</source>
        <translation>Διατήρηση λογαριασμών (για τη δημιουργία προσωπικών αντιγράφων ασφαλείας)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This option will reset &amp;quot;demo&amp;quot; and &amp;quot;root&amp;quot; passwords to the MX Linux defaults and will not copy any personal accounts created.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;Αυτή η επιλογή.θα επαναφέρει τους κωδικούς &amp;quot;demo&amp;quot; και &amp;quot; root&amp;quot; στις προεπιλογές του MX Linux και δεν θα αντιγράψει προσωπικούς λογαριασμούς.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="380"/>
        <source>Resetting accounts (for distribution to others)</source>
        <translation>Επαναφορά λογαριασμών (για διανομή σε άλλους)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="451"/>
        <source>You can also exclude certain directories by ticking the common choices below, or by clicking on the button to directly edit /etc/mx-snapshot-exclude.list.</source>
        <translation>Μπορείτε να εξαιρέσετε καταλόγους επιλέγοντας το αντίστοιχο πλαίσιο στις πιο κάτω επιλογές ή κάνοντας κλικ στο κάτω κουμπί για να επεξεργαστείτε άμεσα το /etc/mx-snapshot-exclude.list.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="496"/>
        <source>sha512</source>
        <translation>sha512</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="519"/>
        <source>Throttle the I/O input rate by the given percentage.</source>
        <translation>Περιορισμός του ρυθμού I/O με το αναφερόμενο ποσοστό.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="525"/>
        <source>I/O throttle:</source>
        <translation>Περιορισμός I/O:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="532"/>
        <source>Calculate checksums:</source>
        <translation>Υπολογισμός αθροισμάτων ελέγχου:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="539"/>
        <source>ISO compression scheme:</source>
        <translation>Συμπίεση ISO:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="546"/>
        <source>Number of CPU cores to use:</source>
        <translation>Αριθμός πυρήνων CPU που θα χρησιμοποιηθούν:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="553"/>
        <source>md5</source>
        <translation>md5</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="563"/>
        <source>Options:</source>
        <translation>Επιλογές:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="610"/>
        <source>Edit Exclusion File</source>
        <translation>Επεξεργασία αρχείου εξαιρέσεων</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="626"/>
        <location filename="../src/mainwindow.cpp" line="969"/>
        <source>Remove Custom Exclusion File</source>
        <translation>Αφαίρεση του προσαρμοσμένου αρχείου εξαιρέσεων</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="679"/>
        <source>Pictures</source>
        <translation>Εικόνες</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="686"/>
        <source>Videos</source>
        <translation>Βίντεο</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="693"/>
        <source>All of the above</source>
        <translation>Όλα τα παραπάνω</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="700"/>
        <source>exclude network configurations</source>
        <translation>εξαίρεση παραμετροποίησης του δικτύου</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="703"/>
        <source>Networks</source>
        <translation>Δίκτυα</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="710"/>
        <source>Downloads</source>
        <translation>Λήψεις</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="717"/>
        <source>Desktop</source>
        <translation>Επιφάνεια εργασίας</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="724"/>
        <source>Documents</source>
        <translation>&apos;Εγγραφα</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="731"/>
        <source>Flatpaks</source>
        <translation>Flatpaks</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="738"/>
        <source>Music</source>
        <translation>Μουσική</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="881"/>
        <source>About this application</source>
        <translation>Περί της εφαρμογής</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="884"/>
        <source>About...</source>
        <translation>Περί...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="890"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1005"/>
        <source>Next</source>
        <translation>Επόμενο</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="906"/>
        <source>Display help </source>
        <translation>Εμφάνιση βοήθειας </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="909"/>
        <source>Help</source>
        <translation>Βοήθεια</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="915"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1030"/>
        <source>Quit application</source>
        <translation>Κλείσιμο εφαρμογής</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1033"/>
        <source>Cancel</source>
        <translation>Άκυρο</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1039"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="989"/>
        <source>Back</source>
        <translation>Πίσω</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="358"/>
        <source>Select Release Date</source>
        <translation>Επιλογή ημερομηνίας</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="402"/>
        <source>fastest, worst compression</source>
        <translation>ταχύτατη, χειρότερη συμπίεση</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="402"/>
        <source>fast, worse compression</source>
        <translation>γρήγορη, χειρότερη συμπίεση</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="403"/>
        <source>slow, better compression</source>
        <translation>αργή, καλή συμπίεση</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="403"/>
        <source>best compromise</source>
        <translation>η καλύτερη</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="404"/>
        <source>slowest, best compression</source>
        <translation>πιο αργή, καλύτερη συμπίεση</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="433"/>
        <source>Free space on %1, where snapshot folder is placed: </source>
        <translation>Ελεύθερος χώρος στο %1, όπου τοποθετείται ο φάκελος του στιγμιότυπου: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="436"/>
        <source>The free space should be sufficient to hold the compressed data from / and /home

      If necessary, you can create more available space by removing previous snapshots and saved copies: %1 snapshots are taking up %2 of disk space.</source>
        <translation>Ο ελεύθερος χώρος θα πρέπει να επαρκεί για να χωρέσει τα συμπιεσμένα δεδομένα από το / (root) και το /home

      Εάν είναι απαραίτητο, μπορείτε να δημιουργήσετε περισσότερο διαθέσιμο χώρο αφαιρώντας προηγούμενα στιγμιότυπα και αποθηκευμένα αντίγραφα: %1 στιγμιότυπα δεσμεύουν %2 χώρου στο δίσκο.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="448"/>
        <location filename="../src/mainwindow.cpp" line="449"/>
        <source>Installing </source>
        <translation>Εγκατάσταση </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="587"/>
        <source>Please wait.</source>
        <translation>Παρακαλώ περιμένετε.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="589"/>
        <source>Please wait. Calculating used disk space...</source>
        <translation>Παρακαλώ περιμένετε. Υπολογισμός χώρου του δίσκου...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="275"/>
        <location filename="../src/mainwindow.cpp" line="489"/>
        <location filename="../src/mainwindow.cpp" line="623"/>
        <location filename="../src/mainwindow.cpp" line="630"/>
        <location filename="../src/mainwindow.cpp" line="712"/>
        <location filename="../src/mainwindow.cpp" line="723"/>
        <location filename="../src/mainwindow.cpp" line="748"/>
        <location filename="../src/mainwindow.cpp" line="1034"/>
        <source>Error</source>
        <translation>Σφάλμα</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="175"/>
        <location filename="../src/mainwindow.cpp" line="211"/>
        <source>Updated Exclusion List</source>
        <translation>Ενημέρωση λίστας εξαιρέσεων</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="178"/>
        <source>The exclusion file at %1 is newer than your configured file at %2.</source>
        <translation>Το αρχείο εξαιρέσεων στο %1 είναι νεώτερο από το αρχείο που έχετε ρυθμίσει στο %2.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="180"/>
        <source>Review the changes below. Keep your custom file or replace it with the updated default.</source>
        <translation>Ελέγξτε τις παρακάτω αλλαγές. Διατηρήστε το προσαρμοσμένο αρχείο σας ή αντικαταστήστε το με το ενημερωμένο προεπιλεγμένο αρχείο.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="186"/>
        <source>Show Differences</source>
        <translation>Εμφάνιση διαφορών</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="192"/>
        <source>Keep Custom</source>
        <translation>Διατήρηση του προσαρμοσμένου</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="198"/>
        <source>Use Updated Default</source>
        <translation>Χρήση του ενημερωμένου</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="490"/>
        <source>Administrator access was not granted; the snapshot cannot continue.</source>
        <translation>Δεν χορηγήθηκε πρόσβαση διαχειριστή, η δημιουργία στιγμιότυπου δεν μπορεί να συνεχιστεί.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="522"/>
        <source>Done</source>
        <translation>Ολοκληρώθηκε</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="624"/>
        <source>Output file %1 already exists. Please use another file name, or delete the existent file.</source>
        <translation>Υπάρχει το αρχείο %1. Παρακαλώ χρησιμοποιήστε άλλο όνομα ή διαγράψτε το υπάρχον αρχείο.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="631"/>
        <source>Insufficient free space. Please select a different snapshot directory or free up space.</source>
        <translation>Ανεπαρκής ελεύθερος χώρος. Παρακαλώ επιλέξτε διαφορετικό κατάλογο ή ελευθερώστε χώρο.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="635"/>
        <source>Settings</source>
        <translation>Ρυθμίσεις</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="641"/>
        <source>Snapshot will use the following settings:</source>
        <translation>Το στιγμιότυπο θα χρησιμοποιήσει τις ακόλουθες ρυθμίσεις:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="643"/>
        <source>- Snapshot directory:</source>
        <translation>- Κατάλογος του στιγμιότυπου:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="644"/>
        <source>- Kernel to be used:</source>
        <translation>- Πυρήνας που θα χρησιμοποιηθεί:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="668"/>
        <location filename="../src/mainwindow.cpp" line="677"/>
        <source>NVIDIA Detected</source>
        <translation>Εντοπίστηκε NVIDIA</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="669"/>
        <source>This computer uses an NVIDIA graphics card. Are you planning to use the resulting ISO on the same computer or another computer with an NVIDIA card?</source>
        <translation>Αυτός ο υπολογιστής χρησιμοποιεί κάρτα γραφικών NVIDIA. Σχεδιάζετε να χρησιμοποιήσετε το ISO στον ίδιο ή σε άλλο υπολογιστή με κάρτα γραφικών NVIDIA;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="673"/>
        <source>NVIDIA Selected</source>
        <translation>Επιλέχτηκε NVIDIA</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="674"/>
        <source>Note: If you use the resulting ISO on a computer without an NVIDIA card, you will likely need to remove &apos;xorg=nvidia&apos; from the boot options.</source>
        <translation>Σημείωση: Αν χρησιμοποιήσετε το ISO σε υπολογιστή χωρίς κάρτα γραφικών NVIDIA, πιθανότατα θα πρέπει να αφαιρέσετε το &apos;xorg=nvidia&apos; από τις επιλογές εκκίνησης.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="678"/>
        <source>Note: If you use the resulting ISO on a computer with an NVIDIA card, you may need to add &apos;xorg=nvidia&apos; to the boot options.</source>
        <translation>Σημείωση: Αν χρησιμοποιήσετε το ISO σε υπολογιστή με κάρτα γραφικών NVIDIA, ίσως χρειαστεί να προσθέσετε το &apos;xorg=nvidia&apos; στις επιλογές εκκίνησης.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="276"/>
        <location filename="../src/mainwindow.cpp" line="713"/>
        <source>Could not replace the exclusion file with the updated default.</source>
        <translation>Δεν ήταν δυνατή η αντικατάσταση του αρχείου εξαιρέσεων με το ενημερωμένο αντίγραφο.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="724"/>
        <source>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</source>
        <translation>Ο ενεργός πυρήνας δεν υποστηρίζει τον επιλεγμένο αλγόριθμο συμπίεσης, παρακαλώ επεξεργαστείτε το αρχείο παραμέτρων και επιλέξτε διαφορετικό αλγόριθμο.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="744"/>
        <source>Cancelled</source>
        <translation>Άκυρο</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="745"/>
        <source>Administrator access is required to create a snapshot.</source>
        <translation>Απαιτείται πρόσβαση διαχειριστή για τη δημιουργία στιγμιότυπου.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="746"/>
        <source>The operation was cancelled. Select Next when you are ready to try again.</source>
        <translation>Η διαδικασία ακυρώθηκε. Επιλέξτε Επόμενο όταν είστε έτοιμοι να ξαναδοκιμάσετε.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="749"/>
        <source>Could not create the snapshot or work directory.</source>
        <translation>Δεν ήταν δυνατή η δημιουργία στιγμιότυπου ή του καταλόγου εργασίας.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="762"/>
        <source>Final chance</source>
        <translation>Τελευταία δυνατότητα</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="764"/>
        <source>Snapshot now has all the information it needs to create an ISO from your running system.</source>
        <translation>Το στιγμιότυπο έχει όλες τις πληροφορίες που χρειάζονται για τη δημιουργία ISO από το ενεργό σύστημα σας.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="765"/>
        <source>It will take some time to finish, depending on the size of the installed system and the capacity of your computer.</source>
        <translation>Θα χρειαστεί κάποιος χρόνος για να ολοκληρωθεί, ανάλογα με το μέγεθος του συστήματος και την ικανότητα του υπολογιστή σας.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="767"/>
        <source>OK to start?</source>
        <translation>Να ξεκινήσουμε;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="824"/>
        <location filename="../src/mainwindow.cpp" line="771"/>
        <source>Shutdown computer when done.</source>
        <translation>Τερματισμός του υπολογιστή όταν τελειώσει.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="805"/>
        <source>Output</source>
        <translation>Έξοδος</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="849"/>
        <source>Close</source>
        <translation>Κλείσιμο</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="924"/>
        <source>Edit Boot Menu</source>
        <translation>Επεξεργασία μενού του φορτωτή εκκίνησης</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="925"/>
        <source>The program will now pause to allow you to edit any files in the work directory. Select Yes to edit the boot menu or select No to bypass this step and continue creating the snapshot.</source>
        <translation>Το πρόγραμμα θα σταματήσει τώρα για να σας επιτρέψει να επεξεργαστείτε αρχεία στον κατάλογο εργασίας σας. Επιλέξτε Ναι για να επεξεργαστείτε το μενού του φορτωτή εκκίνησης ή Όχι για να παρακάμψετε αυτό το βήμα και να συνεχίσετε.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="970"/>
        <source>Revert the exclusion list to the default file? This will overwrite your current exclusions.</source>
        <translation>Επαναφορά της λίστας εξαιρέσεων στο προεπιλεγμένο αρχείο; Θα αντικατασταθούν οι υπάρχουσες εξαιρέσεις.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1002"/>
        <source>About %1</source>
        <translation>Περί του %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1004"/>
        <source>Version: </source>
        <translation>Έκδοση: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1005"/>
        <source>Program for creating a live-CD from the running system for MX Linux</source>
        <translation>Πρόγραμμα δημιουργίας live-CD από ενεργό σύστημα του MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1007"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Πνευματικά δικαιώματα (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1009"/>
        <source>%1 License</source>
        <translation>Άδεια %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1022"/>
        <source>%1 Help</source>
        <translation>Βοήθεια %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1027"/>
        <source>Select Snapshot Directory</source>
        <translation>Επιλογή καταλόγου για το στιγμιότυπο</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1035"/>
        <source>Insufficient free space in the selected directory. Please choose a different location.</source>
        <translation>Ανεπαρκής ελεύθερος χώρος στον επιλεγμένο κατάλογο. Επιλέξτε διαφορετική τοποθεσία.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1079"/>
        <source>Confirmation</source>
        <translation>Επιβεβαίωση</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1079"/>
        <source>Are you sure you want to quit the application?</source>
        <translation>Θέλετε σίγουρα να τερματίσετε την εφαρμογή;</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/main.cpp" line="109"/>
        <source>Tool used for creating a live-CD from the running system</source>
        <translation>Εργαλείο για τη δημιουργία live-CD από ενεργό σύστημα</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>Use CLI only</source>
        <translation>Χρήση διεπαφής με κείμενο</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="117"/>
        <source>Number of CPU cores to be used.</source>
        <translation>Αριθμός πυρήνων CPU που θα χρησιμοποιηθούν.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="118"/>
        <source>Output directory</source>
        <translation>Κατάλογος εξόδου</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="119"/>
        <source>Output filename</source>
        <translation>Όνομα αρχείου</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="121"/>
        <source>Name a different kernel to use other than the default running kernel, use format returned by &apos;uname -r&apos;</source>
        <translation>Δηλώστε διαφορετικό πυρήνα εκτός του προεπιλεγμένου ενεργού, χρησιμοποιώνατς τη μορφή που επιστρέφει η εντολή &apos;uname -r&apos;</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="123"/>
        <source>Or the full path: %1</source>
        <translation>Ή η ολόκληρη διαδρομή: %1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="126"/>
        <source>Compression level options.</source>
        <translation>Επιλογές επιπέδου συμπίεσης.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="127"/>
        <source>Use quotes: &quot;-Xcompression-level &lt;level&gt;&quot;, or &quot;-Xalgorithm &lt;algorithm&gt;&quot;, or &quot;-Xhc&quot;, see mksquashfs man page</source>
        <translation>Χρησιμοποιήστε εισαγωγικά: &quot;-Xcompression-level  &lt;level&gt; &quot;, ή &quot;-Xalgorithm &lt;algorithm&gt; &quot;, ή &quot;-Xhc&quot;, βλέπε man page mksquashfs</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="131"/>
        <source>Create a monthly snapshot, add &apos;Month&apos; name in the ISO name, skip used space calculation</source>
        <translation>Δημιουργία μηνιαίου στιγμιότυπου, προσθήκη του ονόματος &apos;Μήνας&apos; στο όνομα του ISO, παράλειψη υπολογισμού του χρησιμοποιημένου χώρου</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="132"/>
        <source>This option sets reset-accounts and compression to defaults, arguments changing those items will be ignored</source>
        <translation>Αυτή η επιλογή επαναφέρει τους λογαριασμούς και τη συμπίεση στις προεπιλογές, οι συνθήκες που αλλάζουν αυτά τα στοιχεία θα αγνοηθούν</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="134"/>
        <source>Optionally specify a suffix to add to the month name (e.g., &apos;1&apos; for &apos;July.1&apos;)</source>
        <translation>Προαιρετικά, καθορίστε και κατάληξη που θα προστεθεί στο όνομα του μήνα (πχ. &apos;1&apos; για &apos;Ιούλιος.1&apos;)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="135"/>
        <source>Don&apos;t calculate checksums for resulting ISO file</source>
        <translation>Χωρίς υπολογισμό αθροισμάτων ελέγχου για το αρχείο ISO που δημιουργείται</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="136"/>
        <source>Skip calculating free space to see if the resulting ISO will fit</source>
        <translation>Παράλειψη υπολογισμού του ελεύθερου χώρου για το αν χωρά το ISO που προκύπτει</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="137"/>
        <source>Option to fix issue with calculating checksums on preempt_rt kernels</source>
        <translation>Επιλογή για την επίλυση του προβλήματος με τον υπολογισμό αθροισμάτων ελέγχου στα preempt_rt kernels</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="138"/>
        <source>Resetting accounts (for distribution to others)</source>
        <translation>Επαναφορά λογαριασμών (για διανομή σε άλλους)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="139"/>
        <source>Calculate checksums for resulting ISO file</source>
        <translation>Υπολογισμός αθροισμάτων ελέγχου για το αρχείο ISO που δημιουργείται</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="141"/>
        <source>Throttle the I/O input rate by the given percentage. This can be used to reduce the I/O and CPU consumption of Mksquashfs.</source>
        <translation>Περιορισμός του ρυθμού I/O με το αναφερόμενο ποσοστό. Αυτό μπορεί να χρησιμοποιηθεί για να μειωθεί η χρήση I/O και CPU του Mksquashfs.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="144"/>
        <source>Work directory</source>
        <translation>Κατάλογος εργασίας</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="146"/>
        <source>Exclude main folders, valid choices: </source>
        <translation>Εξαίρεση κύριων φακέλων, έγκυρες επιλογές: </translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="148"/>
        <source>Use the option one time for each item you want to exclude</source>
        <translation>Χρησιμοποιήστε την επιλογή για κάθε στοιχείο που θέλετε να εξαιρέσετε</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="151"/>
        <source>Compression format, valid choices: </source>
        <translation>Μορφή συμπίεσης, έγκυρες επιλογές: </translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="153"/>
        <source>Shutdown computer when done.</source>
        <translation>Τερματισμός του υπολογιστή όταν τελειώσει.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="154"/>
        <source>Use grub for legacy mbr iso boot instead of isolinux/syslinux.</source>
        <translation>Χρήση του grub για την εκκίνηση του mbr iso αντί του isolinux/syslinux.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="155"/>
        <source>Add the &apos;xorg=nvidia&apos; boot option to the ISO (for booting on a system with an NVIDIA card).</source>
        <translation>Προσθέστε την επιλογή εκκίνησης &apos;xorg=nvidia&apos; στο ISO (για εκκίνηση σε σύστημα με κάρτα γραφικών NVIDIA).</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="163"/>
        <source>Optional suffix for a monthly snapshot; only valid together with --month.</source>
        <translation>Προαιρετικό επίθημα για το μηνιαίο στιγμιότυπο, ισχύει μόνο σε συνδυασμό με την επιλογή --month.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="196"/>
        <source>A single suffix positional argument is only valid together with --month.</source>
        <translation>Επιτρέπεται μόνο ένα επίθημα θέσης σε συνδυασμό με την επιλογή --month.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="255"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Φαίνεται ότι έχετε συνδεθεί ως διαχειριστής, αποσυνδεθείτε και συνδεθείτε ως απλός χρήστης για να χρησιμοποιήσετε αυτό το πρόγραμμα.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="270"/>
        <source>version:</source>
        <translation>έκδοση:</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="266"/>
        <source>You must run this program with sudo or pkexec.</source>
        <translation>Πρέπει να τρέξετε αυτό το πρόγραμμα με sudo η pkexec.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="235"/>
        <source>MX Snapshot</source>
        <translation>MX Στιγμιότυπο εγκατάστασης</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="770"/>
        <location filename="../src/settings.cpp" line="779"/>
        <location filename="../src/settings.cpp" line="1396"/>
        <location filename="../src/settings.cpp" line="1506"/>
        <location filename="../src/main.cpp" line="257"/>
        <location filename="../src/main.cpp" line="343"/>
        <source>Error</source>
        <translation>Σφάλμα</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="300"/>
        <source>Fatal error:</source>
        <translation>Σοβαρό σφάλμα:</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="302"/>
        <source>Fatal error: unknown exception</source>
        <translation>Σοβαρό σφάλμα: άγνωστη εξαίρεση</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="778"/>
        <location filename="../src/main.cpp" line="342"/>
        <source>Current kernel doesn&apos;t support Squashfs, cannot continue.</source>
        <translation>Ο ενεργός πυρήνας δεν υποστηρίζει Squashfs, δεν μπορεί να προχωρήσει.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="261"/>
        <source>Exception during initialization: %1</source>
        <translation>Εξαίρεση από την εκκίνηση: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="216"/>
        <source>Pending Arch bind-root cleanup state but installed-to-live-arch is missing: %1</source>
        <translation>Σε αναμονή της κατάστασης καθαρισμού bind-root στο Arch, αλλά λείπει το installed-to-live-arch: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="264"/>
        <source>Unknown exception during initialization</source>
        <translation>Άγνωστη εξαίρεση κατά την αρχικοποίηση</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="299"/>
        <source>Could not create work directory. </source>
        <translation>Δεν ήταν δυνατή η δημιουργία του καταλόγου εργασίας. </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="382"/>
        <source>No suitable filesystem found for the temp directory. Tried /tmp, /home, and the snapshot directory.</source>
        <translation>Δεν βρέθηκε κατάλληλο σύστημα αρχείων για το προσωρινό κατάλογο. Δοκιμάστηκαν οι κατάλογοι /tmp, /home και ο κατάλογος στιγμιότυπων.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="393"/>
        <source>Could not create temp directory:</source>
        <translation>Δεν ήταν δυνατή η δημιουργία του προσωρινού καταλόγου:</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="394"/>
        <source>Please check that the parent directory exists and is writable:</source>
        <translation>Παρακαλώ ελέγξτε αν υπάρχει ο γονικός κατάλογος και είναι εγγράψιμος:</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="412"/>
        <source>Compression format &apos;%1&apos; is not supported by the current kernel</source>
        <translation>Δεν υποστηρίζεται από τον ενεργό πυρήνα ο τύπος συμπίεσης &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="418"/>
        <source>Invalid cores setting: %1. Must be between 1 and %2</source>
        <translation>Μη έγκυρος αριθμός πυρήνων: %1. Πρέπει να είναι μεταξύ 1 και %2</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="427"/>
        <source>Invalid throttle setting: %1. Must be between 0 and 99</source>
        <translation>Μη έγκυρη ρύθμιση περιορισμού: %1. Πρέπει να είναι μεταξύ 0 και 99</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="433"/>
        <source>Snapshot directory cannot be empty</source>
        <translation>Το όνομα καταλόγου στιγμιότυπων δεν μπορεί να είναι κενό</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="441"/>
        <source>Snapshot name cannot be empty</source>
        <translation>Το όνομα του στιγμιότυπου δεν μπορεί να είναι κενό</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="447"/>
        <source>Snapshot name contains invalid characters: %1</source>
        <translation>Το όνομα του στιγμιότυπου περιέχει μη έγκυρους χαρακτήρες: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="453"/>
        <source>Kernel version cannot be empty</source>
        <translation>Η έκδοση του πυρήνα δεν μπορεί να είναι κενή</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="458"/>
        <source>Kernel file not found: /boot/vmlinuz-%1</source>
        <translation>Δεν βρέθηκε το αρχείο του πυρήνα: /boot/vmlinuz-%1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="465"/>
        <source>Kernel %1 doesn&apos;t support Squashfs</source>
        <translation>Ο πυρήνας %1 δεν υποστηρίζει Squashfs</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="496"/>
        <source>Exclusion file does not exist: %1</source>
        <translation>Δεν υπάρχει το αρχείο εξαιρέσεων: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="505"/>
        <source>Unbalanced quotes in exclusion list</source>
        <translation>Μη ισορροπημένες αναφορές στη λίστα εξαίρεσης</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="530"/>
        <source>Insufficient free space: %1 KiB available, minimum %2 KiB required</source>
        <translation>Ανεπαρκής ελεύθερος χώρος: διαθέσιμα %1 KiB, απαιτούνται τουλάχιστον %2</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="537"/>
        <source>Insufficient free space in work directory: %1 KiB available, minimum %2 KiB required</source>
        <translation>Ανεπαρκής ελεύθερος χώρος στο κατάλογο εργασίας: διαθέσιμα %1 KiB, απαιτούνται τουλάχιστον %2</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="552"/>
        <source>Failed to determine number of CPU cores</source>
        <translation>Απέτυχε ο προσδιορισμός αριθμού πυρήνων της CPU</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="558"/>
        <source>Configuration file does not exist: %1</source>
        <translation>Δεν υπάρχει το αρχείο παραμέτρων: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="559"/>
        <source>Using default settings</source>
        <translation>Χρήση των προεπιλεγμένων ρυθμίσεων</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="561"/>
        <source>Cannot read configuration file: %1</source>
        <translation>Δεν είναι δυνατή η ανάγνωση του αρχείου παραμέτρων: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="562"/>
        <source>Error: %1</source>
        <translation>Σφάλμα: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="572"/>
        <source>Required tool not found: %1</source>
        <translation>Δεν βρέθηκε το απαιτούμενο εργαλείο: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="581"/>
        <source>Required directory not found: %1</source>
        <translation>Δεν βρέθηκε ο απαιτούμενος κατάλογος: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="600"/>
        <source>Initialization Error</source>
        <translation>Σφάλμα εκκίνησης</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="601"/>
        <source>Failed to initialize application settings:

%1</source>
        <translation>Απέτυχε η προετοιμασία των ρυθμίσεων της εφαρμογής:

%1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="768"/>
        <source>Could not find a usable kernel</source>
        <translation>Δεν ήταν δυνατή η εύρεση χρήσιμου πυρήνα</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="769"/>
        <source>Searched for kernel files in /boot/ but none were found or accessible.</source>
        <translation>Αναζητήθηκαν αρχεία πυρήνα στο /boot/ αλλά δεν βρέθηκε κανένα ή κανένα δεν ήταν προσβάσιμο.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="791"/>
        <source>No users found in the system</source>
        <translation>Δεν βρέθηκαν χρήστες στο σύστημα</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="794"/>
        <source>Failed to determine system information</source>
        <translation>Απέτυχε ο έλεγχος πληροφοριών του συστήματος</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="964"/>
        <source>Used space on / (root): </source>
        <translation>Χώρος που χρησιμοποιεί το / (root): </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="980"/>
        <source>estimated</source>
        <translation>κατ&apos; εκτίμηση</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="987"/>
        <source>Used space on /home: </source>
        <translation>Χώρος που χρησιμοποιεί το /home: </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1048"/>
        <source>Free space on %1, where snapshot folder is placed: </source>
        <translation>Ελεύθερος χώρος στο %1, όπου τοποθετείται ο φάκελος του στιγμιότυπου: </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1052"/>
        <source>The free space should be sufficient to hold the compressed data from / and /home

      If necessary, you can create more available space
      by removing previous snapshots and saved copies:
      %1 snapshots are taking up %2 of disk space.
</source>
        <translation>Ο ελεύθερος χώρος πρέπει να είναι επαρκής για να χωρέσει τα συμπιεσμένα δεδομένα από το / (root) και το /home

      Εάν είναι απαραίτητο, μπορείτε να δημιουργήσετε περισσότερο χώρο
      αφαιρώντας προηγούμενα στιγμιότυπα και αποθηκευμένα αντίγραφα:
      %1 στιγμιότυπα καταλαμβάνουν %2 χώρο στο δίσκο.
</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1199"/>
        <source>Error reading system configuration file: %1</source>
        <translation>Σφάλμα ανάγνωσης του αρχείου παραμέτρων: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1208"/>
        <source>Error accessing user configuration</source>
        <translation>Σφάλμα πρόσβασης στις ρυθμίσεις του χρήστη</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1260"/>
        <source>Could not copy exclusion file from %1 to %2</source>
        <translation>Δεν ήταν δυνατή η αντιγραφή του αρχείου εξαιρέσεων από το %1 στο %2</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1283"/>
        <source>Unsupported compression &apos;%1&apos; in configuration, using zstd.</source>
        <translation>Δεν υποστηρίζεται  στη ρύθμιση η συμπίεση &apos;%1&apos;, χρησιμοποιείστε το zstd.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1293"/>
        <source>Invalid stored cores setting (%1). Using detected CPU count: %2</source>
        <translation>Μη έγκυρη αποθηκευμένη ρύθμιση πυρήνων (%1). Χρήση του αριθμού CPU: %2</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1303"/>
        <source>Invalid stored throttle setting (%1). Using 0.</source>
        <translation>Μη έγκυρη αποθηκευμένη ρύθμιση περιορισμού (%1). Χρησιμοποιείστε 0.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1394"/>
        <location filename="../src/settings.cpp" line="1504"/>
        <source>Output file %1 already exists. Please use another file name, or delete the existent file.</source>
        <translation>Το αρχείο %1 υπάρχει ήδη. Παρακαλώ χρησιμοποιήστε άλλο όνομα ή διαγράψτε το υπάρχον αρχείο.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="73"/>
        <source>Could not load %1</source>
        <translation>Δεν ήταν δυνατή η φόρτωση του %1</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>License</source>
        <translation>Άδεια</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <location filename="../src/about.cpp" line="107"/>
        <source>Changelog</source>
        <translation>Αρχείο αλλαγών</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="98"/>
        <source>Cancel</source>
        <translation>Άκυρο</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="119"/>
        <source>Could not load changelog.</source>
        <translation>Δεν ήταν δυνατή η φόρτωση του αρχείου αλλαγών.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="53"/>
        <location filename="../src/about.cpp" line="122"/>
        <source>&amp;Close</source>
        <translation>&amp;Κλείσιμο</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="78"/>
        <source>No diff output available.</source>
        <translation>Μη διαθέσιμες διαφορές.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="91"/>
        <source>Could not open default exclusion file at %1.</source>
        <translation>Δεν ήταν δυνατόν να ανοίξει το προεπιλεγμένο αρχείο εξαιρέσεων στο %1.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="97"/>
        <source>Could not create exclusion file directory at %1.</source>
        <translation>Δεν ήταν δυνατή η δημιουργία καταλόγου του αρχείου εξαιρέσεων στο %1.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="106"/>
        <source>Could not prepare exclusion file at %1.</source>
        <translation>Δεν ήταν δυνατή η δημιουργία του αρχείου εξαιρέσεων στο %1.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="123"/>
        <source>Could not read default exclusion file at %1.</source>
        <translation>Δεν ήταν δυνατή η ανάγνωση του προεπιλεγμένου αρχείου εξαιρέσεων στο %1.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="131"/>
        <source>Could not write exclusion file at %1.</source>
        <translation>Δεν ήταν δυνατή η εγγραφή του προεπιλεγμένου αρχείου εξαιρέσεων στο %1.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="113"/>
        <source>Could not backup existing exclusion file to %1.</source>
        <translation>Δεν ήταν δυνατή η δημιουργία αντιγράφου ασφαλείας του υπάρχοντος αρχείου εξαιρέσεων στο %1.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="139"/>
        <source>Could not copy default exclusion file from %1 to %2.</source>
        <translation>Δεν ήταν δυνατή η αντιγραφή του προεπιλεγμένου αρχείου εξαιρέσεων από το %1 στο %2.</translation>
    </message>
</context>
<context>
    <name>Work</name>
    <message>
        <location filename="../src/work.cpp" line="312"/>
        <source>Cleaning...</source>
        <translation>Εκκαθάριση...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="343"/>
        <location filename="../src/work.cpp" line="1131"/>
        <source>Done</source>
        <translation>Ολοκληρώθηκε</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="357"/>
        <source>Interrupted or failed to complete</source>
        <translation>Διακόπηκε ή απέτυχε η ολοκλήρωση</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="368"/>
        <location filename="../src/work.cpp" line="425"/>
        <location filename="../src/work.cpp" line="629"/>
        <location filename="../src/work.cpp" line="637"/>
        <location filename="../src/work.cpp" line="672"/>
        <location filename="../src/work.cpp" line="721"/>
        <location filename="../src/work.cpp" line="749"/>
        <location filename="../src/work.cpp" line="763"/>
        <location filename="../src/work.cpp" line="777"/>
        <location filename="../src/work.cpp" line="785"/>
        <location filename="../src/work.cpp" line="791"/>
        <location filename="../src/work.cpp" line="799"/>
        <location filename="../src/work.cpp" line="848"/>
        <location filename="../src/work.cpp" line="864"/>
        <location filename="../src/work.cpp" line="925"/>
        <location filename="../src/work.cpp" line="940"/>
        <location filename="../src/work.cpp" line="948"/>
        <location filename="../src/work.cpp" line="959"/>
        <location filename="../src/work.cpp" line="967"/>
        <location filename="../src/work.cpp" line="1084"/>
        <location filename="../src/work.cpp" line="1101"/>
        <location filename="../src/work.cpp" line="1114"/>
        <location filename="../src/work.cpp" line="1122"/>
        <location filename="../src/work.cpp" line="1183"/>
        <location filename="../src/work.cpp" line="1469"/>
        <location filename="../src/work.cpp" line="1477"/>
        <location filename="../src/work.cpp" line="1491"/>
        <location filename="../src/work.cpp" line="1530"/>
        <location filename="../src/work.cpp" line="1580"/>
        <location filename="../src/work.cpp" line="1604"/>
        <source>Error</source>
        <translation>Σφάλμα</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="369"/>
        <source>Administrator access was not granted; the snapshot cannot continue.</source>
        <translation>Δεν χορηγήθηκε πρόσβαση διαχειριστή, η δημιουργία στιγμιότυπου δεν μπορεί να συνεχιστεί.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="426"/>
        <source>There&apos;s not enough free space on your target disk, you need at least %1</source>
        <translation>Δεν υπάρχει αρκετός ελεύθερος χώρος στο δίσκο προορισμού σας, χρειάζεστε τουλάχιστον %1</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="429"/>
        <source>You have %1 free space on %2</source>
        <translation>Έχετε %1 ελεύθερο χώρο στο %2</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="432"/>
        <source>If you are sure you have enough free space rerun the program with -o/--override-size option</source>
        <translation>Εάν είστε βέβαιοι ότι έχετε αρκετό ελεύθερο χώρο, εκτελέστε ξανά το πρόγραμμα με την επιλογή -o/--override-size</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="610"/>
        <source>Copying the new-iso filesystem...</source>
        <translation>Αντιγραφή του συστήματος αρχείων...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="629"/>
        <source>ISO template not found: </source>
        <translation>Δεν βρέθηκε το πρότυπο ISO: </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="637"/>
        <location filename="../src/work.cpp" line="763"/>
        <source>Could not extract the ISO template: </source>
        <translation>Δεν ήταν δυνατή η εξαγωγή του προτύπου ISO: </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="665"/>
        <source>Arch ISO template is missing boot/ or efi/ directories.</source>
        <translation>Στο πρότυπο ISO του Arch λείπουν οι φάκελοι boot/ ή efi/.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="668"/>
        <source>Detected boot/ or efi/ under the work directory root; the template may have been extracted to the wrong location.</source>
        <translation>Οι φάκελοι boot/ ή efi/ εντοπίστηκαν στο root του καταλόγου εργασίας, ίσως το πρότυπο εξήχθη σε λάθος τοποθεσία.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="671"/>
        <source>Template: %1</source>
        <translation>Πρότυπο: %1</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="707"/>
        <source>Stale archiso initramfs detected, rebuilding...</source>
        <translation>Εντοπίστηκε παρωχημένο archiso initramfs, αναδημιουργία σε εξέλιξη...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="711"/>
        <source>Could not determine the kernel version of /boot/archiso.img (selected kernel is %1).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="714"/>
        <source>Found /boot/archiso.img built for kernel %1, but the selected kernel is %2.</source>
        <translation>Βρέθηκε το αρχείο /boot/archiso.img που έχει δημιουργηθεί για τον πυρήνα %1, αλλά ο επιλεγμένος πυρήνας είναι ο %2.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="718"/>
        <source>Rebuilding /boot/archiso.img failed; check the mkinitcpio output in the log for errors (e.g. a missing hook). Please fix them and rebuild it manually, or remove the stale file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="731"/>
        <source>No /boot/archiso.img found, attempting to create one...</source>
        <translation>Δεν βρέθηκε το αρχείο /boot/archiso.img, γίνεται προσπάθεια να δημιουργηθεί ένα...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="736"/>
        <location filename="../src/work.cpp" line="1173"/>
        <source>Warning</source>
        <translation>Προσοχή</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="737"/>
        <source>Could not create /boot/archiso.img (is the &apos;archiso&apos; package installed?). Falling back to the regular initramfs — the resulting ISO will likely fail to boot (&quot;Failed to start Switch Root&quot;).</source>
        <translation>Δεν ήταν δυνατή η δημιουργία του /boot/archiso.img (είναι εγκατεστημένο το πακέτο &apos;archiso&apos;;). Επιστροφή στο κανονικό initramfs — το ISO που θα προκύψει πιθανότατα δεν θα εκκινήσει (&quot;Αποτυχία εκκίνησης&quot;).</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="749"/>
        <source>Could not find an initramfs image to use.</source>
        <translation>Δεν ήταν δυνατή η εύρεση μιας εικόνας initramfs.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="778"/>
        <source>--grub-mbr option specified but boot/grub/i386-pc/eltorito.img is missing from iso-template</source>
        <translation>Έχει οριστεί η επιλογή --grub-mbr αλλά λείπει το αρχείο boot/grub/i386-pc/eltorito.img από το πρότυπο iso</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="786"/>
        <source>Could not copy the template initrd: </source>
        <translation>Δεν ήταν δυνατή η αντιγραφή του προτύπου initrd: </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="792"/>
        <source>Could not copy the kernel: </source>
        <translation>Δεν ήταν δυνατή η αντιγραφή του πυρήνα: </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="800"/>
        <location filename="../src/work.cpp" line="865"/>
        <location filename="../src/work.cpp" line="949"/>
        <location filename="../src/work.cpp" line="968"/>
        <source>Could not create the checksum for %1.</source>
        <translation>Δεν ήταν δυνατή η δημιουργία αθροίσματος ελέγχου για το %1.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="808"/>
        <source>Could not create temp directory. </source>
        <translation>Δεν ήταν δυνατή η δημιουργία του προσωρινού καταλόγου. </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="849"/>
        <source>Could not copy the kernel modules or programs into the initrd.</source>
        <translation>Δεν ήταν δυνατή η αντιγραφή αρθρωμάτων του πυρήνα ή προγραμμάτων στο initrd.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="915"/>
        <source>Squashing filesystem...</source>
        <translation>Συμπίεση αρχείων...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="926"/>
        <source>Could not create linuxfs file, please check /var/log/%1.log</source>
        <translation>Δεν ήταν δυνατή η δημιουργία του αρχείου linuxfs, παρακαλώ ελέγξτε το /var/log/%1.log</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="941"/>
        <location filename="../src/work.cpp" line="960"/>
        <source>Could not move %1 to the ISO directory.</source>
        <translation>Δεν ήταν δυνατή η μετακίνηση του %1 στο κατάλογο του ISO.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1075"/>
        <source>Creating CD/DVD image file...</source>
        <translation>Δημιουργία αρχείου εικόνας CD/DVD...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1085"/>
        <source>Could not create ISO file, please check whether you have enough space on the destination partition.</source>
        <translation>Δεν ήταν δυνατή η δημιουργία αρχείου ISO, παρακαλώ ελέγξτε αν έχετε αρκετό χώρο στο προορισμό.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1095"/>
        <source>Making hybrid iso</source>
        <translation>Δημιουργία υβριδικού ISO</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1102"/>
        <source>Could not make the ISO hybrid; it would not boot correctly from USB.</source>
        <translation>Δεν ήταν δυνατή η δημιουργία υβριδικού ISO, δεν θα εκκινούσε σωστά από USB.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1115"/>
        <location filename="../src/work.cpp" line="1123"/>
        <source>Could not create the %1 checksum for the ISO.</source>
        <translation>Δεν ήταν δυνατή η δημιουργία του αθροίσματος ελέγχου %1 για το ISO.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1136"/>
        <source>Success</source>
        <translation>Επιτυχία</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1137"/>
        <source>MX Snapshot completed successfully!</source>
        <translation>Το MX Στιγμιότυπο εγκατάστασης ολοκληρώθηκε με επιτυχία!</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1138"/>
        <source>Snapshot took %1 to finish.</source>
        <translation>Χρειάστηκαν %1 για να ολοκληρωθεί.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1139"/>
        <source>Thanks for using MX Snapshot, run MX Live USB Maker next!</source>
        <translation>Ευχαριστούμε που χρησιμοποιήσατε το MX Στιγμιότυπο εγκατάστασης, στη συνέχεια τρέξτε το MX Δημιουργία Live USB!</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1154"/>
        <location filename="../src/work.cpp" line="1180"/>
        <source>Installing </source>
        <translation>Εγκατάσταση </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1169"/>
        <source>paru not found; cannot install %1 from the AUR.</source>
        <translation>Το paru δεν βρέθηκε, δεν είναι δυνατή η εγκατάσταση του %1 από το AUR.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1174"/>
        <source>Could not install %1; continuing without the installer.</source>
        <translation>Δεν ήταν δυνατή η εγκατάσταση του %1, συνέχιση χωρίς το εγκαταστάτη.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1183"/>
        <source>Could not install </source>
        <translation>Δεν ήταν δυνατή η εγκατάσταση </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1193"/>
        <source>Calculating checksum...</source>
        <translation>Υπολογισμός αθροίσματος ελέγχου...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1244"/>
        <source>Building new initrd...</source>
        <translation>Δημιουργία νέου initrd ...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1342"/>
        <source>Rebuilding initramfs with: mkinitcpio %1</source>
        <translation>Αναδημιουργία του initramfs με την εντολή: mkinitcpio %1</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1469"/>
        <location filename="../src/work.cpp" line="1491"/>
        <source>Could not create the package list: </source>
        <translation>Δεν ήταν δυνατή η δημιουργία της λίστας πακέτων: </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1478"/>
        <source>Could not create working directory. </source>
        <translation>Δεν ήταν δυνατή η δημιουργία του καταλόγου εργασίας. </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1531"/>
        <source>Could not prepare a safe bind-root overlay. Snapshot cannot continue.</source>
        <translation>Δεν ήταν δυνατή η προετοιμασία ασφαλούς bind-root. Η δημιουργία του στιγμιότυπου δεν μπορεί να συνεχιστεί.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1581"/>
        <location filename="../src/work.cpp" line="1605"/>
        <source>Could not prepare the snapshot bind-root environment.</source>
        <translation>Δεν ήταν δυνατή η προετοιμασία περιβάλλοντος bind-root του στιγμιότυπου.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1944"/>
        <source>Calculating total size of excluded files...</source>
        <translation>Υπολογισμός συνολικού μεγέθους των εξαιρούμενων αρχείων...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1971"/>
        <source>Calculating size of root...</source>
        <translation>Υπολογισμός μεγέθους root...</translation>
    </message>
</context>
</TS>