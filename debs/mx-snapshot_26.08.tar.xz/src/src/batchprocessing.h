/**********************************************************************
 *  batchprocessing.h
 **********************************************************************
 * Copyright (C) 2020-2026 MX Authors
 *
 * Authors: Adrian
 *          MX Linux <http://mxlinux.org>
 *
 * This file is part of MX Snapshot.
 *
 * MX Snapshot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MX Snapshot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MX Snapshot.  If not, see <http://www.gnu.org/licenses/>.
 **********************************************************************/
#pragma once

#include <QTimer>

#include "settings.h"
#include "work.h"

class Batchprocessing : public QObject
{
    Q_OBJECT
public:
    explicit Batchprocessing(Settings *settings, QObject *parent = nullptr);

    void setConnections();

    // True once the snapshot pipeline ran to completion (Work::createIso()
    // finished); false for every early-abort path (space/config/elevation
    // failures), so callers can derive a real process exit code.
    [[nodiscard]] bool succeeded() const { return work.isDone(); }

public slots:
    static void progress();

private:
    Settings *settings;
    Work work;
    QTimer timer;

    void abortIfElevationDenied();
    void checkUpdatedDefaultExcludesCli();
    [[nodiscard]] QString colorizeDiffAnsi(const QString &diff) const;
    [[nodiscard]] bool isSourceExcludesNewer(QString &diffOutput) const;
    [[nodiscard]] bool resetCustomExcludesCli(const QString &configuredPath, const QString &sourcePath) const;

    void handleStreamChunk(QString &buffer, const QString &chunk, bool toStdout);
    void flushStreamLine(const QString &line, bool toStdout, bool isTransient);

    QString stdoutBuffer;
    QString stderrBuffer;
    bool progressLineActive = false;
};
