<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="de">
<context>
    <name>Batchprocessing</name>
    <message>
        <location filename="../src/batchprocessing.cpp" line="53"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="54"/>
        <source>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</source>
        <translation>Der installierte Kernel unterstützt den ausgewählten Kompressionsalgorithmus nicht; bitte die Konfigurationdatei bearbeiten und einen anderen Algorithmus auswählen.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="101"/>
        <source>The program will pause the build and open the boot menu in your text editor.</source>
        <translation>Das Programm pausiert, während das Bootmenü im Texteditor geöffnet wird.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="114"/>
        <source>The boot-menu editor failed; the snapshot cannot continue with potentially unedited files.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="131"/>
        <source>Administrator access was not granted; the snapshot cannot continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="258"/>
        <source>Detected newer exclusion file at %1 compared to %2. Prompting for action.</source>
        <translation>Es wurde eine neuere Ausnahmedatei auf %1 im Vergleich mit %2. Eingabe einer Reaktion erforderlich.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="264"/>
        <source>s</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'show diff'</comment>
        <translation>s</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="265"/>
        <source>u</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'use updated default'</comment>
        <translation>u</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="266"/>
        <source>k</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'keep custom (update timestamp)'</comment>
        <translation>k</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="267"/>
        <source>q</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'quit'</comment>
        <translation>q</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="269"/>
        <source>show diff</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>Unterschied anzeigen</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="270"/>
        <source>use updated default</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>Aktualisierte Voreinstellung verwenden</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="271"/>
        <source>keep custom (update timestamp)</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>Benutzerdefiniertes beibehalten (Zeitstempel aktualisieren)</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="272"/>
        <source>quit</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>Beenden</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="275"/>
        <source>[%1]%2  [%3]%4  [%5]%6  [%7]%8: </source>
        <translation>[%1]%2  [%3]%4  [%5]%6  [%7]%8: </translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="280"/>
        <source>The exclusion file at %1 is newer than your configured file at %2.</source>
        <translation>Die Ausnahmedatei auf %1 ist neuer als die konfigurierte Datei auf %2.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="296"/>
        <source>Reverted to updated default exclusion file.</source>
        <translation>Zurücksetzen auf die aktualisierte voreingestellte Ausnahmedatei.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="313"/>
        <source>No input available to answer the exclusion file prompt; aborting without creating a snapshot.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="316"/>
        <source>Leaving custom exclusion file unchanged.</source>
        <translation>Benutzerdefinierte Ausnahmedatei unverändert lassen.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="327"/>
        <source>Invalid choice. Please select again.</source>
        <translation>Ungültige Auswahl. Bitte neu versuchen.</translation>
    </message>
</context>
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="121"/>
        <source>No elevation tool found (pkexec/gksu/sudo).</source>
        <translation>Kein geeignetes Programm gefunden (pkexec/gksu/sudo).</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="212"/>
        <source>Failed to start command: %1</source>
        <translation>Befehl konnte nicht gestartet werden: %1</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="283"/>
        <source>Administrator access was not granted (authentication cancelled or denied).</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <location filename="../src/mainwindow.cpp" line="396"/>
        <location filename="../src/mainwindow.cpp" line="944"/>
        <source>MX Snapshot</source>
        <translation>MX-Schnappschuss</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="33"/>
        <source>Optional customization</source>
        <translation>Optionale Anpassungen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="65"/>
        <source>Release version:</source>
        <translation>Release Version:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="79"/>
        <source>Boot options:</source>
        <translation>Boot-Optionen:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="86"/>
        <source>Live kernel:</source>
        <translation>Live-Kernel:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="93"/>
        <source>Project name:</source>
        <translation>Projektname:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="100"/>
        <source>Release date:</source>
        <translation>Datum der Freigabe:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="107"/>
        <source>Release codename:</source>
        <translation>Codename der Freigabe:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="133"/>
        <source>Current date</source>
        <translation>Aktuelles Datum</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="172"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Snapshot is a utility that creates a bootable image (ISO) of your working system that you can use for storage or distribution. You can continue working with undemanding applications while it is running.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Mit &quot;snapshot&quot; können Sie sehr einfach ein bootfähiges Image (.ISO) Ihres modifizierten Arbeitssystems erzeugen für USB-stick oder CD-ROM. Das dient z.B. als Datensicherung oder kann auch weiter verteilt werden (z.B. modifizierte distro mit account reset). Während die snapshot-Erstellung im Hintergrund läuft, können Sie mit den davon nicht abhängigen Programmen weiter arbeiten, wenn Sie möchten.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="182"/>
        <source>Used space on / (root) and /home partitions:</source>
        <translation>Belegter Platz für / (root) und /home Partitionen:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="192"/>
        <source>Location and ISO name</source>
        <translation>Ort und Name der ISO-Datei</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="219"/>
        <source>Snapshot location:</source>
        <translation>Speicherort des Schnappschusses:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="226"/>
        <source>Select a different snapshot directory</source>
        <translation>Anderes Verzeichnis für den Schnappschuss wählen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="236"/>
        <location filename="../src/mainwindow.cpp" line="644"/>
        <source>Snapshot name:</source>
        <translation>Name des Schnappschusses:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="360"/>
        <source>Type of snapshot:</source>
        <translation>Art des Schnappschusses</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="367"/>
        <source>Preserving accounts (for personal backup)</source>
        <translation>Benutzerkonten beibehalten (z.B. wegen persönlichem Backup)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This option will reset &amp;quot;demo&amp;quot; and &amp;quot;root&amp;quot; passwords to the MX Linux defaults and will not copy any personal accounts created.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Diese Option setzt das Passwort von Benutzern &quot;demo&quot; und &quot;root&quot; auf die Vorgabe von MX Linux zurück (nämlich &quot;demo&quot; und &quot;root&quot;) aber kopiert keine anderen persönlich erstellten Benutzerkonten. Passwortänderung ohne Kenntnis des alten Passwortes ist auch jederzeit im boot-Menü möglich: F4 &quot;private&quot;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="380"/>
        <source>Resetting accounts (for distribution to others)</source>
        <translation>Account zurücksetzen (z.B. wegen Veröffentlichung als Distro)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="451"/>
        <source>You can also exclude certain directories by ticking the common choices below, or by clicking on the button to directly edit /etc/mx-snapshot-exclude.list.</source>
        <translation>Sie können bestimmte Verzeichnisse ausschließen, indem Sie diese in der vorgegebenen Auswahl ankreuzen, oder durch direktes Bearbeiten der Datei /etc/mx-snapshot-exclude.list, die sich mit einem Klick auf die Schaltfläche öffnet.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="496"/>
        <source>sha512</source>
        <translation>sha512</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="519"/>
        <source>Throttle the I/O input rate by the given percentage.</source>
        <translation>Drosselung der I/O-Eingangsrate um den angegebenen Prozentsatz.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="525"/>
        <source>I/O throttle:</source>
        <translation>I/O Drosselung:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="532"/>
        <source>Calculate checksums:</source>
        <translation>Prüfsummen berechnen:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="539"/>
        <source>ISO compression scheme:</source>
        <translation>ISO Kompressionschema :</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="546"/>
        <source>Number of CPU cores to use:</source>
        <translation>Anzahl der zu verwendenden CPU-Kerne:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="553"/>
        <source>md5</source>
        <translation>md5</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="563"/>
        <source>Options:</source>
        <translation>Auswahlmöglichkeiten:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="610"/>
        <source>Edit Exclusion File</source>
        <translation>Ausschluss-Datei bearbeiten</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="626"/>
        <location filename="../src/mainwindow.cpp" line="969"/>
        <source>Remove Custom Exclusion File</source>
        <translation>Benutzerdefinierte Ausnahmedatei entfernen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="679"/>
        <source>Pictures</source>
        <translation>Bilder</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="686"/>
        <source>Videos</source>
        <translation>Videos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="693"/>
        <source>All of the above</source>
        <translation>Alles hier genannte</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="700"/>
        <source>exclude network configurations</source>
        <translation> Netzwerkkonfigurationen ausschließen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="703"/>
        <source>Networks</source>
        <translation>Netzwerke</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="710"/>
        <source>Downloads</source>
        <translation>Downloads</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="717"/>
        <source>Desktop</source>
        <translation>Benutzeroberfläche</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="724"/>
        <source>Documents</source>
        <translation>Dokumente</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="731"/>
        <source>Flatpaks</source>
        <translation>Flatpaks</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="738"/>
        <source>Music</source>
        <translation>Musik</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="881"/>
        <source>About this application</source>
        <translation>Über dieses Programm</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="884"/>
        <source>About...</source>
        <translation>Über...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="890"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1005"/>
        <source>Next</source>
        <translation>Weiter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="906"/>
        <source>Display help </source>
        <translation>Hilfe anzeigen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="909"/>
        <source>Help</source>
        <translation>Hilfe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="915"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1030"/>
        <source>Quit application</source>
        <translation>Anwendung beenden</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1033"/>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1039"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="989"/>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="358"/>
        <source>Select Release Date</source>
        <translation>Freigabe-Datum auswählen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="402"/>
        <source>fastest, worst compression</source>
        <translation>schnellste, schlechteste Komprimierung</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="402"/>
        <source>fast, worse compression</source>
        <translation>schnelle, schlechte Komprimierung</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="403"/>
        <source>slow, better compression</source>
        <translation>langsame, bessere Komprimierung</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="403"/>
        <source>best compromise</source>
        <translation>bester Kompromiss</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="404"/>
        <source>slowest, best compression</source>
        <translation>langsamste, beste Komprimierung</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="433"/>
        <source>Free space on %1, where snapshot folder is placed: </source>
        <translation>Freier Platz auf %1, wo das Schnappschuss-Verzeichnis liegt:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="436"/>
        <source>The free space should be sufficient to hold the compressed data from / and /home

      If necessary, you can create more available space by removing previous snapshots and saved copies: %1 snapshots are taking up %2 of disk space.</source>
        <translation>Der freie Platz sollte ausreichen, um die komprimierten Daten von / und /home aufzunehmen

      Bei Bedarf können Sie mehr freien Platz gewinnen, indem Sie
gespeicherte Kopien von früheren Schnappschüssen löschen:
%1 Schnappschuss verbraucht %2 Festplattenplatz.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="448"/>
        <location filename="../src/mainwindow.cpp" line="449"/>
        <source>Installing </source>
        <translation>Installiere</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="587"/>
        <source>Please wait.</source>
        <translation>Bitte warten.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="589"/>
        <source>Please wait. Calculating used disk space...</source>
        <translation>Bitte warten. Berechne benötigten Platz auf Festplatte...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="275"/>
        <location filename="../src/mainwindow.cpp" line="489"/>
        <location filename="../src/mainwindow.cpp" line="623"/>
        <location filename="../src/mainwindow.cpp" line="630"/>
        <location filename="../src/mainwindow.cpp" line="712"/>
        <location filename="../src/mainwindow.cpp" line="723"/>
        <location filename="../src/mainwindow.cpp" line="748"/>
        <location filename="../src/mainwindow.cpp" line="1034"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="175"/>
        <location filename="../src/mainwindow.cpp" line="211"/>
        <source>Updated Exclusion List</source>
        <translation>Aktualisierte Ausnahmeliste</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="178"/>
        <source>The exclusion file at %1 is newer than your configured file at %2.</source>
        <translation>Die Ausnahmedatei auf %1 ist neuer als die konfigurierte Datei auf %2.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="180"/>
        <source>Review the changes below. Keep your custom file or replace it with the updated default.</source>
        <translation>Unten aufgeführte Änderungen überprüfen. Benutzerdefinierte Datei beibehalten oder durch die aktualisierte Voreinstellung ersetzen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="186"/>
        <source>Show Differences</source>
        <translation>Unterschiede anzeigen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="192"/>
        <source>Keep Custom</source>
        <translation>Benutzerdefinierte beibehalten</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="198"/>
        <source>Use Updated Default</source>
        <translation>Aktualisierte Voreinstellung verwenden</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="490"/>
        <source>Administrator access was not granted; the snapshot cannot continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="522"/>
        <source>Done</source>
        <translation>Fertig</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="624"/>
        <source>Output file %1 already exists. Please use another file name, or delete the existent file.</source>
        <translation>Die Ausgabedatei %1 existiert bereits. Bitte verwenden Sie einen anderen Dateinamen, oder löschen Sie die existierende Datei.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="631"/>
        <source>Insufficient free space. Please select a different snapshot directory or free up space.</source>
        <translation>Zu wenig freier Speicherplatz. Bitte anderes Verzeichnis für den Snapshot auswählen oder Speicherplatz freimachen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="635"/>
        <source>Settings</source>
        <translation>Einstellungen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="641"/>
        <source>Snapshot will use the following settings:</source>
        <translation>Der Schnappschuss wird folgende Einstellungen verwenden:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="643"/>
        <source>- Snapshot directory:</source>
        <translation>- Schnappschuss-Verzeichnis:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="644"/>
        <source>- Kernel to be used:</source>
        <translation>- Verwendeter Kernel:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="668"/>
        <location filename="../src/mainwindow.cpp" line="677"/>
        <source>NVIDIA Detected</source>
        <translation>NVIDIA-Grafikkarte wurde erkannt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="669"/>
        <source>This computer uses an NVIDIA graphics card. Are you planning to use the resulting ISO on the same computer or another computer with an NVIDIA card?</source>
        <translation>Dieser Computer verwendet eine NVIDIA Grafikkarte. Möchten Sie die erstellte ISO auf demselben Computer oder auf einem anderen Computer mit einer NVIDIA-Grafikkarte verwenden?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="673"/>
        <source>NVIDIA Selected</source>
        <translation>NVIDIA-Grafikkarte ausgewählt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="674"/>
        <source>Note: If you use the resulting ISO on a computer without an NVIDIA card, you will likely need to remove &apos;xorg=nvidia&apos; from the boot options.</source>
        <translation>Hinweis: Wenn Sie die erstellte ISO auf einem Computer ohne NVIDIA-Grafikkarte verwenden, müssen Sie gegebenfalls &quot;xorg=nvidia&quot; aus den Boot-Optionen entfernen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="678"/>
        <source>Note: If you use the resulting ISO on a computer with an NVIDIA card, you may need to add &apos;xorg=nvidia&apos; to the boot options.</source>
        <translation>Hinweis: Wenn Sie die erstellte ISO auf einem Computer mit einer NVIDIA-Grafikkarte verwenden, müssen Sie gegebenenfalls &quot;xorg=nvidia&quot; zu den Boot-Optionen hinzufügen. </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="276"/>
        <location filename="../src/mainwindow.cpp" line="713"/>
        <source>Could not replace the exclusion file with the updated default.</source>
        <translation>Auswahldatei konnte nicht durch die aktualisierte Voreinstellung ersetzt werden.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="724"/>
        <source>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</source>
        <translation>Der installierte Kernel unterstützt den ausgewählten Kompressionsalgorithmus nicht; bitte die Konfigurationdatei bearbeiten und einen anderen Algorithmus auswählen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="744"/>
        <source>Cancelled</source>
        <translation>Abgebrochen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="745"/>
        <source>Administrator access is required to create a snapshot.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="746"/>
        <source>The operation was cancelled. Select Next when you are ready to try again.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="749"/>
        <source>Could not create the snapshot or work directory.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="762"/>
        <source>Final chance</source>
        <translation>Letzte Chance</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="764"/>
        <source>Snapshot now has all the information it needs to create an ISO from your running system.</source>
        <translation>Das Schnappschuss-Programm hat jetzt alle nötigen Informationen, um ein ISO Ihres laufenden Systems zu erstellen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="765"/>
        <source>It will take some time to finish, depending on the size of the installed system and the capacity of your computer.</source>
        <translation>Abhängig von der Größe Ihres installierten Systems und der Leistungsfähigkeit des Computers wird es einige Zeit dauern, diesen Vorgang abzuschließen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="767"/>
        <source>OK to start?</source>
        <translation>Alles klar zum Loslegen?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="824"/>
        <location filename="../src/mainwindow.cpp" line="771"/>
        <source>Shutdown computer when done.</source>
        <translation>Den Computer ausschalten, wenn die Arbeit erledigt ist.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="805"/>
        <source>Output</source>
        <translation>Ausgabe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="849"/>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="924"/>
        <source>Edit Boot Menu</source>
        <translation>Boot-Menü bearbeiten</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="925"/>
        <source>The program will now pause to allow you to edit any files in the work directory. Select Yes to edit the boot menu or select No to bypass this step and continue creating the snapshot.</source>
        <translation>Das Programm wartet nun und ermöglicht, alle Dateien im Arbeitsverzeichnis zu bearbeiten.&quot;Yes&quot; wählen, um das Boot-Menü zu bearbeiten, oder &quot;No&quot;, um mit dem Erstellen des Schnappschusses fortzufahren.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="970"/>
        <source>Revert the exclusion list to the default file? This will overwrite your current exclusions.</source>
        <translation>Auswahlliste auf voreingestellte Datei zurücksetzen ? Derzeitige Ausnahmen werden dann überschrieben.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1002"/>
        <source>About %1</source>
        <translation>Über %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1004"/>
        <source>Version: </source>
        <translation>Version:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1005"/>
        <source>Program for creating a live-CD from the running system for MX Linux</source>
        <translation>Programm, um eine Live-CD Ihres mit MX Linux laufenden Systems zu erstellen.
Es wird eine .ISO-Datei erstellt, bootfähig auch von USB-Stick. Es ist typischerweise unnötig, das laufende System vorher extra zu remastern, was ca. 15 Minuten dauern würde. Alles, was im RAM zwischengespeichert ist, landet in der ISO-Datei, abzüglich der Ausschlüsse.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1007"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1009"/>
        <source>%1 License</source>
        <translation>%1 Lizenz</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1022"/>
        <source>%1 Help</source>
        <translation>%1 Hilfe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1027"/>
        <source>Select Snapshot Directory</source>
        <translation>Wähle Schnappschuss-Verzeichnis</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1035"/>
        <source>Insufficient free space in the selected directory. Please choose a different location.</source>
        <translation>Zu wenig freier Speicherplatz im ausgewählten Verzeichnis. Bitte anderes Verzeichnis auswählen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1079"/>
        <source>Confirmation</source>
        <translation>Bestätigung</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1079"/>
        <source>Are you sure you want to quit the application?</source>
        <translation>Sicherheitsabfrage: Programm wirklich beenden? </translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/main.cpp" line="109"/>
        <source>Tool used for creating a live-CD from the running system</source>
        <translation>Werkzeug zur Erzeugung einer Live-CD aus dem laufenden System heraus</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>Use CLI only</source>
        <translation>Nur CLI verwenden</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="117"/>
        <source>Number of CPU cores to be used.</source>
        <translation>Anzahl der verwendeten CPU-Kerne:</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="118"/>
        <source>Output directory</source>
        <translation>Zielverzeichnis</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="119"/>
        <source>Output filename</source>
        <translation>Name der Ausgabedatei</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="121"/>
        <source>Name a different kernel to use other than the default running kernel, use format returned by &apos;uname -r&apos;</source>
        <translation>Geben Sie bitte einen anderen als den aktiven Kernel des laufenden Systems an und benutzen Sie dafür das gleiche Format, das vom Befehl &apos;uname -r&apos; ausgegeben wird.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="123"/>
        <source>Or the full path: %1</source>
        <translation>Oder vollständige Pfadangabe: %1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="126"/>
        <source>Compression level options.</source>
        <translation>Optionen für die Kompressionsstufe.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="127"/>
        <source>Use quotes: &quot;-Xcompression-level &lt;level&gt;&quot;, or &quot;-Xalgorithm &lt;algorithm&gt;&quot;, or &quot;-Xhc&quot;, see mksquashfs man page</source>
        <translation>Verwenden Sie Anführungszeichen: &quot;-Xcompression-level &quot;, oder &quot;-Xalgorithm &quot;, oder &quot;-Xhc&quot;, siehe mksquashfs-Benutzerhandbuch</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="131"/>
        <source>Create a monthly snapshot, add &apos;Month&apos; name in the ISO name, skip used space calculation</source>
        <translation>Erzeuge einen Monatsschnappschuß, füge den aktuellen &apos;Monat&apos; in den Dateinamen des ISOs ein und übergehe die Größenberechnung.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="132"/>
        <source>This option sets reset-accounts and compression to defaults, arguments changing those items will be ignored</source>
        <translation>Diese Option setzt die Einstellung zum Zurücksetzen der Nutzerkonten und der Kompression auf Standardkonfiguration. Argumente, die diese Einstellungen ändern, werden ignoriert.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="134"/>
        <source>Optionally specify a suffix to add to the month name (e.g., &apos;1&apos; for &apos;July.1&apos;)</source>
        <translation>Optional kann an den Monatsnamen ein Suffix angehängt werden (z.B. &apos;Juli.1&apos;)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="135"/>
        <source>Don&apos;t calculate checksums for resulting ISO file</source>
        <translation>Keine Prüfsumme für die erzeugte ISO Datei generieren.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="136"/>
        <source>Skip calculating free space to see if the resulting ISO will fit</source>
        <translation>Berechnen des freien Speicherplatzes abbrechen, um zu sehen, ob die resultierende ISO passt.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="137"/>
        <source>Option to fix issue with calculating checksums on preempt_rt kernels</source>
        <translation>Option zum Beheben von Problemen der Prüfsummenberechung bei einem Kernel des Typs &quot;preempt_rt&quot;.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="138"/>
        <source>Resetting accounts (for distribution to others)</source>
        <translation>Account zurücksetzen (z.B. wegen Veröffentlichung als Distro)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="139"/>
        <source>Calculate checksums for resulting ISO file</source>
        <translation>Berechnen der Prüfsumme für die erzeugte ISO Datei.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="141"/>
        <source>Throttle the I/O input rate by the given percentage. This can be used to reduce the I/O and CPU consumption of Mksquashfs.</source>
        <translation>Drosselt die I/O-Eingangsrate um den angegebenen Prozentsatz. Dies kann verwendet werden, um den I/O- und CPU-Verbrauch von Mksquashfs zu reduzieren.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="144"/>
        <source>Work directory</source>
        <translation>Arbeitsverzeichnis</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="146"/>
        <source>Exclude main folders, valid choices: </source>
        <translation>Wahlmöglichkeiten für den Ausschluß von Hauptverzeichnissen:</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="148"/>
        <source>Use the option one time for each item you want to exclude</source>
        <translation>Diese Option einmal für jeden Eintrag, der ausgeschlossen werden soll, verwenden.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="151"/>
        <source>Compression format, valid choices: </source>
        <translation>Wahlmöglichkeiten für die Art der Kompression:</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="153"/>
        <source>Shutdown computer when done.</source>
        <translation>Den Computer ausschalten, wenn die Arbeit erledigt ist.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="154"/>
        <source>Use grub for legacy mbr iso boot instead of isolinux/syslinux.</source>
        <translation>GRUB verwenden für das - veraltete- Booten der Iso-Datei vom MBR anstelle von isolinux/syslinux.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="155"/>
        <source>Add the &apos;xorg=nvidia&apos; boot option to the ISO (for booting on a system with an NVIDIA card).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="163"/>
        <source>Optional suffix for a monthly snapshot; only valid together with --month.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="196"/>
        <source>A single suffix positional argument is only valid together with --month.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="255"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Sie sind als Administrator am System angemeldet. Bitte melden Sie sich ab und dann als normaler Benutzer wieder an, um dieses Programm zu verwenden.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="270"/>
        <source>version:</source>
        <translation>Version:</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="266"/>
        <source>You must run this program with sudo or pkexec.</source>
        <translation>Sie müssen dieses Programm mit sudo oder pkexec ausführen.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="235"/>
        <source>MX Snapshot</source>
        <translation>MX-Schnappschuss</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="257"/>
        <location filename="../src/main.cpp" line="343"/>
        <location filename="../src/settings.cpp" line="770"/>
        <location filename="../src/settings.cpp" line="779"/>
        <location filename="../src/settings.cpp" line="1396"/>
        <location filename="../src/settings.cpp" line="1506"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="300"/>
        <source>Fatal error:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="302"/>
        <source>Fatal error: unknown exception</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="342"/>
        <location filename="../src/settings.cpp" line="778"/>
        <source>Current kernel doesn&apos;t support Squashfs, cannot continue.</source>
        <translation>Der installierte Kernel unterstützt Squashfs nicht; Abbruch.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="261"/>
        <source>Exception during initialization: %1</source>
        <translation>Ausnahme während der Initialisierung: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="216"/>
        <source>Pending Arch bind-root cleanup state but installed-to-live-arch is missing: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="264"/>
        <source>Unknown exception during initialization</source>
        <translation>Unbekannte Ausnahme während der Initialisierung</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="299"/>
        <source>Could not create work directory. </source>
        <translation>Arbeitsverzeichnis konnte nicht angelegt werden.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="382"/>
        <source>No suitable filesystem found for the temp directory. Tried /tmp, /home, and the snapshot directory.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="393"/>
        <source>Could not create temp directory:</source>
        <translation>Temporäres Verzeichnis konnte nicht angelegt werden:</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="394"/>
        <source>Please check that the parent directory exists and is writable:</source>
        <translation>Bitte überprüfen, ob das übergeordnete Verzeichnis existiert und beschreibbar ist:</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="412"/>
        <source>Compression format &apos;%1&apos; is not supported by the current kernel</source>
        <translation>Kompressionsformat &apos;%1&apos; wird vom benutzten Kernel nicht unterstützt</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="418"/>
        <source>Invalid cores setting: %1. Must be between 1 and %2</source>
        <translation>Ungültige Kern-Angabe: %1. Muß zwischen 1 und %2 liegen</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="427"/>
        <source>Invalid throttle setting: %1. Must be between 0 and 99</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="433"/>
        <source>Snapshot directory cannot be empty</source>
        <translation>Das Snapshot-Verzeichnis kann nicht leer sein</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="441"/>
        <source>Snapshot name cannot be empty</source>
        <translation>Der Snapshot-Name kann nicht leer sein</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="447"/>
        <source>Snapshot name contains invalid characters: %1</source>
        <translation>Der Snapshot-Name enthält ungültige Zeichen: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="453"/>
        <source>Kernel version cannot be empty</source>
        <translation>Die Kernel-Version kann nicht leer sein</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="458"/>
        <source>Kernel file not found: /boot/vmlinuz-%1</source>
        <translation>Kerneldatei nicht gefunden: /boot/vmlinuz-%1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="465"/>
        <source>Kernel %1 doesn&apos;t support Squashfs</source>
        <translation>Kernel %1 unterstützt Squashfs nicht</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="496"/>
        <source>Exclusion file does not exist: %1</source>
        <translation>Ausnahmedatei existiert nicht: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="505"/>
        <source>Unbalanced quotes in exclusion list</source>
        <translation>unvollständiges Anführungszeichenpaar in Ausnahmeliste</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="530"/>
        <source>Insufficient free space: %1 KiB available, minimum %2 KiB required</source>
        <translation>Freier Speicherplatz nicht ausreichend: %1 KiB verfügbar, als Minimum %2 KiB nötig</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="537"/>
        <source>Insufficient free space in work directory: %1 KiB available, minimum %2 KiB required</source>
        <translation>Freier Speicherplatz im Arbeitsverzeichnis nicht ausreichend: %1 KiB verfügbar, als Minimum %2 KiB nötig</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="552"/>
        <source>Failed to determine number of CPU cores</source>
        <translation>Anzahl der CPU Kerne konnte nicht festgestellt werden</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="558"/>
        <source>Configuration file does not exist: %1</source>
        <translation>Konfigurationsdatei existiert nicht: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="559"/>
        <source>Using default settings</source>
        <translation>Voreinstellungen werden verwendet</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="561"/>
        <source>Cannot read configuration file: %1</source>
        <translation>Konfiguraionsdatei konnte nicht gelesen werden: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="562"/>
        <source>Error: %1</source>
        <translation>Fehler: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="572"/>
        <source>Required tool not found: %1</source>
        <translation>Benötigtes Programm konnte nicht gefunden werden: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="581"/>
        <source>Required directory not found: %1</source>
        <translation>Benötigtes Verzeichnis konnte nicht gefunden werden: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="600"/>
        <source>Initialization Error</source>
        <translation>Fehler beim Initialisieren</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="601"/>
        <source>Failed to initialize application settings:

%1</source>
        <translation>Fehler beim Initialisieren der Anwendungseinstellungen:

%1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="768"/>
        <source>Could not find a usable kernel</source>
        <translation>Kein verwendbarer Kernel vorhanden.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="769"/>
        <source>Searched for kernel files in /boot/ but none were found or accessible.</source>
        <translation>Suche nach Kerneldateien in /boot/ nicht erfolgreich oder die Dateien waren nicht nutzbar. </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="791"/>
        <source>No users found in the system</source>
        <translation>Keine Benutzer im System gefunden</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="794"/>
        <source>Failed to determine system information</source>
        <translation>Feststellung von Systeminformationen fehlgeschlagen</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="964"/>
        <source>Used space on / (root): </source>
        <translation>Benötigter Platz für das Wurzelverzeichnis &quot;/&quot; (root):</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="980"/>
        <source>estimated</source>
        <translation>geschätzt</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="987"/>
        <source>Used space on /home: </source>
        <translation>Benötigter Platz für /home:</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1048"/>
        <source>Free space on %1, where snapshot folder is placed: </source>
        <translation>Freier Platz auf %1, wo das Schnappschuss-Verzeichnis liegt:</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1052"/>
        <source>The free space should be sufficient to hold the compressed data from / and /home

      If necessary, you can create more available space
      by removing previous snapshots and saved copies:
      %1 snapshots are taking up %2 of disk space.
</source>
        <translation>Der freie Platz sollte für die komprimierten Daten von / und /home ausreichen.

Bei Bedarf können Sie Platz gewinnen, indem Sie
gespeicherte Kopien von früheren Schnappschüssen löschen:
%1 Schnappschuss verbraucht %2 Festplattenplatz.
</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1199"/>
        <source>Error reading system configuration file: %1</source>
        <translation>Fehler beim Auslesen der Systemkonfigurationsdatei: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1208"/>
        <source>Error accessing user configuration</source>
        <translation>Fehler beim Aufrufen der Benutzerkonfiguration</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1260"/>
        <source>Could not copy exclusion file from %1 to %2</source>
        <translation>Ausnahmedatei konnte nicht von %1 auf %2 kopiert werden</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1283"/>
        <source>Unsupported compression &apos;%1&apos; in configuration, using zstd.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1293"/>
        <source>Invalid stored cores setting (%1). Using detected CPU count: %2</source>
        <translation>Ungültige gespeicherte Kerneeinstellung (%1). Verwendung der festgestellten CPU Anzahl: %2</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1303"/>
        <source>Invalid stored throttle setting (%1). Using 0.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1394"/>
        <location filename="../src/settings.cpp" line="1504"/>
        <source>Output file %1 already exists. Please use another file name, or delete the existent file.</source>
        <translation>Die Ausgabedatei %1 existiert bereits. Bitte verwenden Sie einen anderen Dateinamen, oder löschen Sie die existierende Datei.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="73"/>
        <source>Could not load %1</source>
        <translation>%1 konnte nicht geladen werden.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>License</source>
        <translation>Lizenz</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <location filename="../src/about.cpp" line="107"/>
        <source>Changelog</source>
        <translation>Änderungsprotokoll</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="98"/>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="119"/>
        <source>Could not load changelog.</source>
        <translation>Änderungsprotokoll konnte nicht geladen werden.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="53"/>
        <location filename="../src/about.cpp" line="122"/>
        <source>&amp;Close</source>
        <translation>&amp;Schließen</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="78"/>
        <source>No diff output available.</source>
        <translation>Keine Ausgabe von Unterschieden verfügbar.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="91"/>
        <source>Could not open default exclusion file at %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="97"/>
        <source>Could not create exclusion file directory at %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="106"/>
        <source>Could not prepare exclusion file at %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="123"/>
        <source>Could not read default exclusion file at %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="131"/>
        <source>Could not write exclusion file at %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="113"/>
        <source>Could not backup existing exclusion file to %1.</source>
        <translation>Existierende Ausnahmedatei konnte nicht gesichert werden auf %1.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="139"/>
        <source>Could not copy default exclusion file from %1 to %2.</source>
        <translation>Voreingestellte Ausnahmedatei konnte nicht von %1 auf %2 kopiert werden.</translation>
    </message>
</context>
<context>
    <name>Work</name>
    <message>
        <location filename="../src/work.cpp" line="247"/>
        <source>Cleaning...</source>
        <translation>Bereinigung läuft...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="278"/>
        <location filename="../src/work.cpp" line="1060"/>
        <source>Done</source>
        <translation>Fertig</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="292"/>
        <source>Interrupted or failed to complete</source>
        <translation>Fertigstellung fehlgeschlagen oder Ausführung unterbrochen.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="303"/>
        <location filename="../src/work.cpp" line="360"/>
        <location filename="../src/work.cpp" line="564"/>
        <location filename="../src/work.cpp" line="572"/>
        <location filename="../src/work.cpp" line="607"/>
        <location filename="../src/work.cpp" line="650"/>
        <location filename="../src/work.cpp" line="678"/>
        <location filename="../src/work.cpp" line="692"/>
        <location filename="../src/work.cpp" line="706"/>
        <location filename="../src/work.cpp" line="714"/>
        <location filename="../src/work.cpp" line="720"/>
        <location filename="../src/work.cpp" line="728"/>
        <location filename="../src/work.cpp" line="777"/>
        <location filename="../src/work.cpp" line="793"/>
        <location filename="../src/work.cpp" line="854"/>
        <location filename="../src/work.cpp" line="869"/>
        <location filename="../src/work.cpp" line="877"/>
        <location filename="../src/work.cpp" line="888"/>
        <location filename="../src/work.cpp" line="896"/>
        <location filename="../src/work.cpp" line="1013"/>
        <location filename="../src/work.cpp" line="1030"/>
        <location filename="../src/work.cpp" line="1043"/>
        <location filename="../src/work.cpp" line="1051"/>
        <location filename="../src/work.cpp" line="1107"/>
        <location filename="../src/work.cpp" line="1398"/>
        <location filename="../src/work.cpp" line="1406"/>
        <location filename="../src/work.cpp" line="1420"/>
        <location filename="../src/work.cpp" line="1459"/>
        <location filename="../src/work.cpp" line="1509"/>
        <location filename="../src/work.cpp" line="1533"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="304"/>
        <source>Administrator access was not granted; the snapshot cannot continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="361"/>
        <source>There&apos;s not enough free space on your target disk, you need at least %1</source>
        <translation>Der Speicherplatz auf dem Ziellaufwerk reicht nicht aus. Es werden mindestens %1 benötigt.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="364"/>
        <source>You have %1 free space on %2</source>
        <translation>Auf %2 ist %1 Speicherplatz frei.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="367"/>
        <source>If you are sure you have enough free space rerun the program with -o/--override-size option</source>
        <translation>Wenn Sie sicher sind, genügend freien Speicherplatz zu haben, starten Sie das Programm erneut mit der Option -o/--override-size</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="545"/>
        <source>Copying the new-iso filesystem...</source>
        <translation>Kopiere Dateisystem für neue ISO...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="564"/>
        <source>ISO template not found: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="572"/>
        <location filename="../src/work.cpp" line="692"/>
        <source>Could not extract the ISO template: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="600"/>
        <source>Arch ISO template is missing boot/ or efi/ directories.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="603"/>
        <source>Detected boot/ or efi/ under the work directory root; the template may have been extracted to the wrong location.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="606"/>
        <source>Template: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="642"/>
        <source>Stale archiso initramfs detected, rebuilding...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="644"/>
        <source>Found /boot/archiso.img built for kernel %1, but the selected kernel is %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="648"/>
        <source>Rebuilding /boot/archiso.img failed. Please rebuild it manually or remove the stale file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="660"/>
        <source>No /boot/archiso.img found, attempting to create one...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="665"/>
        <location filename="../src/work.cpp" line="1097"/>
        <source>Warning</source>
        <translation>Warnung</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="666"/>
        <source>Could not create /boot/archiso.img (is the &apos;archiso&apos; package installed?). Falling back to the regular initramfs — the resulting ISO will likely fail to boot (&quot;Failed to start Switch Root&quot;).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="678"/>
        <source>Could not find an initramfs image to use.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="707"/>
        <source>--grub-mbr option specified but boot/grub/i386-pc/eltorito.img is missing from iso-template</source>
        <translation>--grub-mbr Optionen sind angegeben aber die Datei boot/grub/i386-pc/eltorito.img von iso-template fehlt</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="715"/>
        <source>Could not copy the template initrd: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="721"/>
        <source>Could not copy the kernel: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="729"/>
        <location filename="../src/work.cpp" line="794"/>
        <location filename="../src/work.cpp" line="878"/>
        <location filename="../src/work.cpp" line="897"/>
        <source>Could not create the checksum for %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="737"/>
        <source>Could not create temp directory. </source>
        <translation>Konnte kein Temporärverzeichnis anlegen.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="778"/>
        <source>Could not copy the kernel modules or programs into the initrd.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="844"/>
        <source>Squashing filesystem...</source>
        <translation>Komprimiere Dateisystem...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="855"/>
        <source>Could not create linuxfs file, please check /var/log/%1.log</source>
        <translation>Die Datei linuxfs konnte nicht erstellt werden, bitte /var/log/%1.log überprüfen</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="870"/>
        <location filename="../src/work.cpp" line="889"/>
        <source>Could not move %1 to the ISO directory.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1004"/>
        <source>Creating CD/DVD image file...</source>
        <translation>Erstelle Image-Datei der CD/DVD...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1014"/>
        <source>Could not create ISO file, please check whether you have enough space on the destination partition.</source>
        <translation>Die .ISO-Datei konnte nicht erstellt werden, überprüfen Sie bitte, ob genug Speicherplatz frei ist.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1024"/>
        <source>Making hybrid iso</source>
        <translation>Hybrid-ISO erstellen</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1031"/>
        <source>Could not make the ISO hybrid; it would not boot correctly from USB.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1044"/>
        <location filename="../src/work.cpp" line="1052"/>
        <source>Could not create the %1 checksum for the ISO.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1065"/>
        <source>Success</source>
        <translation>Erfolg</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1066"/>
        <source>MX Snapshot completed successfully!</source>
        <translation>MX-Schnappschuss erfolgreich abgeschlossen!</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1067"/>
        <source>Snapshot took %1 to finish.</source>
        <translation>Der Schnappschuss benötigte %1 .</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1068"/>
        <source>Thanks for using MX Snapshot, run MX Live USB Maker next!</source>
        <translation>Danke, daẞ Sie MX Snapshot benutzt haben. Jetzt geht&apos;s zum MX Live USB Maker!</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1083"/>
        <location filename="../src/work.cpp" line="1104"/>
        <source>Installing </source>
        <translation>Installiere</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1094"/>
        <source>paru not found; cannot install %1 from the AUR.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1098"/>
        <source>Could not install %1; continuing without the installer.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1107"/>
        <source>Could not install </source>
        <translation>Konnte nicht installieren</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1117"/>
        <source>Calculating checksum...</source>
        <translation>Generiere Prüfsumme...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1168"/>
        <source>Building new initrd...</source>
        <translation>Neue initrd Datei wird erstellt ....</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1271"/>
        <source>Rebuilding initramfs with: mkinitcpio %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1398"/>
        <location filename="../src/work.cpp" line="1420"/>
        <source>Could not create the package list: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1407"/>
        <source>Could not create working directory. </source>
        <translation>Konnte kein Arbeitsverzeichnis anlegen.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1460"/>
        <source>Could not prepare a safe bind-root overlay. Snapshot cannot continue.</source>
        <translation>Sicheres bind-root Overlay konnte nicht vorbereitet werden. Snapshot kann nicht weiter ausgeführt werden.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1510"/>
        <location filename="../src/work.cpp" line="1534"/>
        <source>Could not prepare the snapshot bind-root environment.</source>
        <translation>Die bind-root Umgebung für Snapshot konnte nicht vorbereitet werden.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1870"/>
        <source>Calculating total size of excluded files...</source>
        <translation>Berechne die Gesamtgröße der ausgeschlossenen Dateien ...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1897"/>
        <source>Calculating size of root...</source>
        <translation>Berechne die Größe von root ...</translation>
    </message>
</context>
</TS>