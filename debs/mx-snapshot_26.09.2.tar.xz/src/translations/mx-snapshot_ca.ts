<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="ca">
<context>
    <name>Batchprocessing</name>
    <message>
        <location filename="../src/batchprocessing.cpp" line="53"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="54"/>
        <source>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</source>
        <translation>El kernel actual no dona suport a l&apos;algoritme de compressió seleccionat, si us plau editeu el fitxer de configuració i trieu un algoritme diferent.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="101"/>
        <source>The program will pause the build and open the boot menu in your text editor.</source>
        <translation>El programa aturarà la construcció i obrirà el menú d&apos;arrencada al vostre editor de text.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="114"/>
        <source>The boot-menu editor failed; the snapshot cannot continue with potentially unedited files.</source>
        <translation>L&apos;editor boot-menu ha fallat; la instantània no pot continuar amb fitxers potencialment no editats.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="131"/>
        <source>Administrator access was not granted; the snapshot cannot continue.</source>
        <translation>No s&apos;ha garantit l&apos;accés com a administrador; la instantània no pot continuar.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="258"/>
        <source>Detected newer exclusion file at %1 compared to %2. Prompting for action.</source>
        <translation>S&apos;ha detectat un fitxer d&apos;exclusió més nou a %1 en comparació amb %2. Se sol·licita una acció.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="264"/>
        <source>s</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'show diff'</comment>
        <translation>s</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="265"/>
        <source>u</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'use updated default'</comment>
        <translation>u</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="266"/>
        <source>k</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'keep custom (update timestamp)'</comment>
        <translation>k</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="267"/>
        <source>q</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'quit'</comment>
        <translation>q</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="269"/>
        <source>show diff</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>Mostra les diferències</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="270"/>
        <source>use updated default</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>Usa el fitxer predeterminat actualitzat</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="271"/>
        <source>keep custom (update timestamp)</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>Mantén el personalitzat (actualitza la marca de temps)</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="272"/>
        <source>quit</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>Surt</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="275"/>
        <source>[%1]%2  [%3]%4  [%5]%6  [%7]%8: </source>
        <translation>[%1]%2  [%3]%4  [%5]%6  [%7]%8: </translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="280"/>
        <source>The exclusion file at %1 is newer than your configured file at %2.</source>
        <translation>El fitxer d&apos;exclusió a %1 és més nou que el fitxer configurat a %2.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="296"/>
        <source>Reverted to updated default exclusion file.</source>
        <translation>S&apos;ha revertit al fitxer actualitzat d&apos;exclusió per defecte.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="313"/>
        <source>No input available to answer the exclusion file prompt; aborting without creating a snapshot.</source>
        <translation>No hi ha resposta a la pregunta del fitxer d&apos;exclusions; s&apos;interromp sense crear la instantània.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="316"/>
        <source>Leaving custom exclusion file unchanged.</source>
        <translation>Es deixa el fitxer d&apos;exclusió personalitzat sense canvis.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="327"/>
        <source>Invalid choice. Please select again.</source>
        <translation>Opció no vàlida. Si us plau, seleccioneu un altre cop.</translation>
    </message>
</context>
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="121"/>
        <source>No elevation tool found (pkexec/gksu/sudo).</source>
        <translation>No s&apos;ha trobat cap eina d&apos;elevació (pkexec / gksu / sudo).</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="212"/>
        <source>Failed to start command: %1</source>
        <translation>Ha fallat en iniciar l&apos;ordre: %1</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="283"/>
        <source>Administrator access was not granted (authentication cancelled or denied).</source>
        <translation>No s&apos;ha garantit l&apos;accés com a administrador (autenticació cancel·lada o denegada).</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <location filename="../src/mainwindow.cpp" line="396"/>
        <location filename="../src/mainwindow.cpp" line="944"/>
        <source>MX Snapshot</source>
        <translation>MX Snapshot </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="33"/>
        <source>Optional customization</source>
        <translation>Personalització opcional</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="65"/>
        <source>Release version:</source>
        <translation>Versió de l&apos;edició:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="79"/>
        <source>Boot options:</source>
        <translation>Opcions d&apos;arrencada:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="86"/>
        <source>Live kernel:</source>
        <translation>Kernel autònom:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="93"/>
        <source>Project name:</source>
        <translation>Nom de projecte:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="100"/>
        <source>Release date:</source>
        <translation>Data de publicació:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="107"/>
        <source>Release codename:</source>
        <translation>Nom en clau de l&apos;edició:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="133"/>
        <source>Current date</source>
        <translation>Data actual</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="172"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Snapshot is a utility that creates a bootable image (ISO) of your working system that you can use for storage or distribution. You can continue working with undemanding applications while it is running.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Snapshot és una eina que crea una imatge autònoma (ISO) del vostre sistema en funcionament, que podeu usar per a emmagatzematge o distribució. Podeu continuar usant aplicacions poc intensives mentre s&apos;executa.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="182"/>
        <source>Used space on / (root) and /home partitions:</source>
        <translation>Espai usat a les particions / (arrel) i /home: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="192"/>
        <source>Location and ISO name</source>
        <translation>Ubicació i nom de l&apos;ISO</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="219"/>
        <source>Snapshot location:</source>
        <translation>Ubicació de la instantània:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="226"/>
        <source>Select a different snapshot directory</source>
        <translation>Trieu un directori diferent per a la instantània </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="236"/>
        <location filename="../src/mainwindow.cpp" line="644"/>
        <source>Snapshot name:</source>
        <translation>Nom de la instantània: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="360"/>
        <source>Type of snapshot:</source>
        <translation>Tipus d&apos;instantània: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="367"/>
        <source>Preserving accounts (for personal backup)</source>
        <translation>Preservant els comptes (còpia de seguretat personal) </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This option will reset &amp;quot;demo&amp;quot; and &amp;quot;root&amp;quot; passwords to the MX Linux defaults and will not copy any personal accounts created.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Aquesta opció inicialitzarà les contrasenyes per &amp;quot;demo&amp;quot; i &amp;quot;root&amp;quot; als valors per omissió de MX Linux i no copiarà cap compte personal que s&apos;hagi creat.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="380"/>
        <source>Resetting accounts (for distribution to others)</source>
        <translation>Es restableixen els comptes (per distribuir a tercers) </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="451"/>
        <source>You can also exclude certain directories by ticking the common choices below, or by clicking on the button to directly edit /etc/mx-snapshot-exclude.list.</source>
        <translation>També podeu excloure alguns directoris marcant les opcions comunes a sota, o clicant el botó per editar directament /etc/mx-snapshot-exclude.list.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="496"/>
        <source>sha512</source>
        <translation>sha512</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="519"/>
        <source>Throttle the I/O input rate by the given percentage.</source>
        <translation>Ajusta el règim d&apos;E/S amb el percentatge donat.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="525"/>
        <source>I/O throttle:</source>
        <translation>Ajust d&apos;E/S:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="532"/>
        <source>Calculate checksums:</source>
        <translation>Calcula les sumes de control:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="539"/>
        <source>ISO compression scheme:</source>
        <translation>Mètode de compressió de l&apos;ISO:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="546"/>
        <source>Number of CPU cores to use:</source>
        <translation>Nombre de nuclis de CPU a usar:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="553"/>
        <source>md5</source>
        <translation>md5</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="563"/>
        <source>Options:</source>
        <translation>Opcions:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="610"/>
        <source>Edit Exclusion File</source>
        <translation>Edita el fitxer d&apos;exclusions</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="626"/>
        <location filename="../src/mainwindow.cpp" line="969"/>
        <source>Remove Custom Exclusion File</source>
        <translation>Elimina el fitxer d&apos;exclusions personalitzat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="679"/>
        <source>Pictures</source>
        <translation>Imatges</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="686"/>
        <source>Videos</source>
        <translation>Vídeos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="693"/>
        <source>All of the above</source>
        <translation>Tots els esmentats</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="700"/>
        <source>exclude network configurations</source>
        <translation>exclou configuracions de xarxes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="703"/>
        <source>Networks</source>
        <translation>Xarxes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="710"/>
        <source>Downloads</source>
        <translation>Baixades </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="717"/>
        <source>Desktop</source>
        <translation>Escriptori</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="724"/>
        <source>Documents</source>
        <translation>Documents</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="731"/>
        <source>Flatpaks</source>
        <translation>Flatpaks</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="738"/>
        <source>Music</source>
        <translation>Música</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="881"/>
        <source>About this application</source>
        <translation>Quant a aquest programa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="884"/>
        <source>About...</source>
        <translation>Quant a...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="890"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1005"/>
        <source>Next</source>
        <translation>Següent</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="906"/>
        <source>Display help </source>
        <translation>Mostra l&apos;ajuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="909"/>
        <source>Help</source>
        <translation>Ajuda </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="915"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1030"/>
        <source>Quit application</source>
        <translation>Surt de l&apos;aplicació</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1033"/>
        <source>Cancel</source>
        <translation>Cancel·la</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1039"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="989"/>
        <source>Back</source>
        <translation>Enrere</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="358"/>
        <source>Select Release Date</source>
        <translation>Trieu la data de llançament</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="402"/>
        <source>fastest, worst compression</source>
        <translation>més ràpid, pitjor compressió</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="402"/>
        <source>fast, worse compression</source>
        <translation>ràpid, pitjor compressió</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="403"/>
        <source>slow, better compression</source>
        <translation>lent, millor compressió</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="403"/>
        <source>best compromise</source>
        <translation>millor compromís</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="404"/>
        <source>slowest, best compression</source>
        <translation>més lent, millor compressió</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="433"/>
        <source>Free space on %1, where snapshot folder is placed: </source>
        <translation>Espai lliure a %1, on es desarà la carpeta de la instantània: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="436"/>
        <source>The free space should be sufficient to hold the compressed data from / and /home

      If necessary, you can create more available space by removing previous snapshots and saved copies: %1 snapshots are taking up %2 of disk space.</source>
        <translation>Hauria d&apos;haver-hi prou espai lliure per allotjar les dades comprimides de / i /home.    Si cal, podeu crear més espai lliure disponible per allotjar les instantànies anteriors i les còpies desades: per %1 instantànies cal fins a %2 d&apos;espai de disc.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="448"/>
        <location filename="../src/mainwindow.cpp" line="449"/>
        <source>Installing </source>
        <translation>S&apos;instal·la </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="587"/>
        <source>Please wait.</source>
        <translation>Espereu, si us plau. </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="589"/>
        <source>Please wait. Calculating used disk space...</source>
        <translation>Espereu, si us plau. Calculant l&apos;espai de disc usat...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="275"/>
        <location filename="../src/mainwindow.cpp" line="489"/>
        <location filename="../src/mainwindow.cpp" line="623"/>
        <location filename="../src/mainwindow.cpp" line="630"/>
        <location filename="../src/mainwindow.cpp" line="712"/>
        <location filename="../src/mainwindow.cpp" line="723"/>
        <location filename="../src/mainwindow.cpp" line="748"/>
        <location filename="../src/mainwindow.cpp" line="1034"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="175"/>
        <location filename="../src/mainwindow.cpp" line="211"/>
        <source>Updated Exclusion List</source>
        <translation>Llista d&apos;exclusió actualitzada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="178"/>
        <source>The exclusion file at %1 is newer than your configured file at %2.</source>
        <translation>El fitxer d&apos;exclusió a %1 és més nou que el fitxer configurat a %2.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="180"/>
        <source>Review the changes below. Keep your custom file or replace it with the updated default.</source>
        <translation>Reviseu els canvis següents. Conserveu el fitxer personalitzat o substituïu-lo pel predeterminat actualitzat.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="186"/>
        <source>Show Differences</source>
        <translation>Mostra&apos;n les diferències</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="192"/>
        <source>Keep Custom</source>
        <translation>Mantén el fitxer personalitzat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="198"/>
        <source>Use Updated Default</source>
        <translation>Usa el fitxer predeterminat actualitzat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="490"/>
        <source>Administrator access was not granted; the snapshot cannot continue.</source>
        <translation>No s&apos;ha garantit l&apos;accés com a administrador; la instantània no pot continuar.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="522"/>
        <source>Done</source>
        <translation>Fet </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="624"/>
        <source>Output file %1 already exists. Please use another file name, or delete the existent file.</source>
        <translation>El fitxer de sortida %1 ja hi és. Si us plau, useu un altre nom de fitxer, o esborreu el fitxer existent.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="631"/>
        <source>Insufficient free space. Please select a different snapshot directory or free up space.</source>
        <translation>Espai lliure insuficient. Seleccioneu un directori d&apos;instantànies diferent o allibereu espai.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="635"/>
        <source>Settings</source>
        <translation>Paràmetres</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="641"/>
        <source>Snapshot will use the following settings:</source>
        <translation>La instantània usarà aquests paràmetres:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="643"/>
        <source>- Snapshot directory:</source>
        <translation>- Directori de la instantània: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="644"/>
        <source>- Kernel to be used:</source>
        <translation>- Kernel a usar: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="668"/>
        <location filename="../src/mainwindow.cpp" line="677"/>
        <source>NVIDIA Detected</source>
        <translation>Detectada NVIDIA</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="669"/>
        <source>This computer uses an NVIDIA graphics card. Are you planning to use the resulting ISO on the same computer or another computer with an NVIDIA card?</source>
        <translation>Aquest ordinador usa una targeta gràfica NVIDIA. Teniu previst usar l&apos;ISO obtingut en el mateix ordinador o un altre amb targeta NVIDIA?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="673"/>
        <source>NVIDIA Selected</source>
        <translation>Seleccionada NVIDIA</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="674"/>
        <source>Note: If you use the resulting ISO on a computer without an NVIDIA card, you will likely need to remove &apos;xorg=nvidia&apos; from the boot options.</source>
        <translation>Nota: Si voleu usar l&apos;ISO obtingut en un ordinador sense targeta NVIDIA, probablement necessitareu eliminar &apos;xorg=nvidia&apos; de les opcions d&apos;arrencada.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="678"/>
        <source>Note: If you use the resulting ISO on a computer with an NVIDIA card, you may need to add &apos;xorg=nvidia&apos; to the boot options.</source>
        <translation>Nota: Si useu l&apos;ISO obtingut en on ordinador amb targeta NVIDIA, probablement necessitareu afegir &apos;xorg=nvidia&apos; a les opcions d&apos;arrencada.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="276"/>
        <location filename="../src/mainwindow.cpp" line="713"/>
        <source>Could not replace the exclusion file with the updated default.</source>
        <translation>No s&apos;ha pogut substituir el fitxer d&apos;exclusió pel valor predeterminat actualitzat.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="724"/>
        <source>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</source>
        <translation>El kernel actual no dona suport a l&apos;algoritme de compressió seleccionat, si us plau editeu el fitxer de configuració i trieu un algoritme diferent.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="744"/>
        <source>Cancelled</source>
        <translation>Cancel·lat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="745"/>
        <source>Administrator access is required to create a snapshot.</source>
        <translation>Cal accés com a administrador per crear una instantània.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="746"/>
        <source>The operation was cancelled. Select Next when you are ready to try again.</source>
        <translation>S&apos;ha cancel·lat l&apos;operació. Trieu Següent quan estigueu a pint de tornar-ho a provar.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="749"/>
        <source>Could not create the snapshot or work directory.</source>
        <translation>No s&apos;ha pogut crear la instantània o el directori de treball. </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="762"/>
        <source>Final chance</source>
        <translation>Darrera oportunitat </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="764"/>
        <source>Snapshot now has all the information it needs to create an ISO from your running system.</source>
        <translation>La instantània ara té tota la informació necessària per crear un ISO a partir del vostre sistema en execució. </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="765"/>
        <source>It will take some time to finish, depending on the size of the installed system and the capacity of your computer.</source>
        <translation>Cal un cert temps per acabar, depenent de la mida del vostre sistema instal·lat i de la potència de l&apos;ordinador. </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="767"/>
        <source>OK to start?</source>
        <translation>D&apos;acord per començar?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="824"/>
        <location filename="../src/mainwindow.cpp" line="771"/>
        <source>Shutdown computer when done.</source>
        <translation>Tanca l&apos;ordinador en acabar.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="805"/>
        <source>Output</source>
        <translation>Sortida </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="849"/>
        <source>Close</source>
        <translation>Tanca</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="924"/>
        <source>Edit Boot Menu</source>
        <translation>Edita el Menú d&apos;Arrencada </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="925"/>
        <source>The program will now pause to allow you to edit any files in the work directory. Select Yes to edit the boot menu or select No to bypass this step and continue creating the snapshot.</source>
        <translation>El programa ara farà una pausa per permetre-us editar fitxers al directori de treball. Trieu Sí per editar el menú d&apos;arrencada, o No per saltar aquest pas i continuar creant la instantània. </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="970"/>
        <source>Revert the exclusion list to the default file? This will overwrite your current exclusions.</source>
        <translation>Revertir la llista d&apos;exclusions al fitxer per omissió? Això sobreescriurà les vostres exclusions actuals.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1002"/>
        <source>About %1</source>
        <translation>Quant a %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1004"/>
        <source>Version: </source>
        <translation>Versió: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1005"/>
        <source>Program for creating a live-CD from the running system for MX Linux</source>
        <translation>Programa de MX Linux per crear un CD autònom a partir del sistema en execució </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1007"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1009"/>
        <source>%1 License</source>
        <translation>Llicència de %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1022"/>
        <source>%1 Help</source>
        <translation>Ajuda de %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1027"/>
        <source>Select Snapshot Directory</source>
        <translation>Trieu el directori de la instantània </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1035"/>
        <source>Insufficient free space in the selected directory. Please choose a different location.</source>
        <translation>No hi ha prou espai lliure al directori seleccionat. Trieu una ubicació diferent.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1079"/>
        <source>Confirmation</source>
        <translation>Confirmació</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1079"/>
        <source>Are you sure you want to quit the application?</source>
        <translation>Segur que voleu sortir de l&apos;aplicació?</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/main.cpp" line="109"/>
        <source>Tool used for creating a live-CD from the running system</source>
        <translation>Eina per crear CD autònoms a partir del sistema en execució</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>Use CLI only</source>
        <translation>Usa només CLI</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="117"/>
        <source>Number of CPU cores to be used.</source>
        <translation>Nombre de nuclis d&apos;E/S que s&apos;usaran.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="118"/>
        <source>Output directory</source>
        <translation>Directori de sortida</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="119"/>
        <source>Output filename</source>
        <translation>Nom del fitxer de sortida</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="121"/>
        <source>Name a different kernel to use other than the default running kernel, use format returned by &apos;uname -r&apos;</source>
        <translation>Anomeneu un kernel diferent que l&apos;usat per omissió, useu el format que retorna l&apos;ordre &apos;uname -r&apos;</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="123"/>
        <source>Or the full path: %1</source>
        <translation>O el camí sencer: %1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="126"/>
        <source>Compression level options.</source>
        <translation>Opcions del nivell de compressió.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="127"/>
        <source>Use quotes: &quot;-Xcompression-level &lt;level&gt;&quot;, or &quot;-Xalgorithm &lt;algorithm&gt;&quot;, or &quot;-Xhc&quot;, see mksquashfs man page</source>
        <translation>Useu cometes dobles: &quot;-Xcompression-level &lt;level&gt;&quot;, o &quot;-Xalgorithm &lt;algorithm&gt;&quot;, o &quot;-Xhc&quot;, vegeu la pàgina man de mksquashfs</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="131"/>
        <source>Create a monthly snapshot, add &apos;Month&apos; name in the ISO name, skip used space calculation</source>
        <translation>Crea una instantània mensual, afegiu el nom &apos;Month&apos; al nom de la ISO, s&apos;omet l&apos;ús del càlcul de mida</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="132"/>
        <source>This option sets reset-accounts and compression to defaults, arguments changing those items will be ignored</source>
        <translation>Aquesta opció defineix reset-accounts i compression als valors per omissió, s&apos;ignoraran els arguments que canviïn aquests paràmetres</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="134"/>
        <source>Optionally specify a suffix to add to the month name (e.g., &apos;1&apos; for &apos;July.1&apos;)</source>
        <translation>Opcionalment, especifiqueu un sufix per afegir al nom del mes (per exemple, 1 per a juliol.1)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="135"/>
        <source>Don&apos;t calculate checksums for resulting ISO file</source>
        <translation>No calcula la suma de verificació per a l&apos;ISO resultant</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="136"/>
        <source>Skip calculating free space to see if the resulting ISO will fit</source>
        <translation>Ometre el càlcul d&apos;espai lliure per saber si el fitxer ISO resultant hi cap</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="137"/>
        <source>Option to fix issue with calculating checksums on preempt_rt kernels</source>
        <translation>Opció per esmenar el problema causat pel càlcul de les sumes de verificació als nuclis preempt_rt</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="138"/>
        <source>Resetting accounts (for distribution to others)</source>
        <translation>Es restableixen els comptes (per distribuir a tercers) </translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="139"/>
        <source>Calculate checksums for resulting ISO file</source>
        <translation>Calcula la suma de verificació per a l&apos;ISO resultant</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="141"/>
        <source>Throttle the I/O input rate by the given percentage. This can be used to reduce the I/O and CPU consumption of Mksquashfs.</source>
        <translation>Ajusta el règim d&apos;entrada d&apos;E/S amb el percentatge donat. Es pot usar per reduir l&apos;E/S i el consum de CPU de Mksquashfs.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="144"/>
        <source>Work directory</source>
        <translation>Directori de treball</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="146"/>
        <source>Exclude main folders, valid choices: </source>
        <translation>Exclou les carpetes principals, opcions vàlides: </translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="148"/>
        <source>Use the option one time for each item you want to exclude</source>
        <translation>Useu l&apos;opció un cop per cada ítem que vulgueu excloure</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="151"/>
        <source>Compression format, valid choices: </source>
        <translation>Format de compressió, opcions vàlides: </translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="153"/>
        <source>Shutdown computer when done.</source>
        <translation>Tanca l&apos;ordinador en acabar.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="154"/>
        <source>Use grub for legacy mbr iso boot instead of isolinux/syslinux.</source>
        <translation>Useu GRUB per l&apos;arrencada clàssica MBR en comptes de isolinux/syslinux.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="155"/>
        <source>Add the &apos;xorg=nvidia&apos; boot option to the ISO (for booting on a system with an NVIDIA card).</source>
        <translation>Afegiu l&apos;opció d&apos;arrencada &apos;xorg=nvidia&apos; a la ISO (per arrencar en un sistema amb targeta nVidia).</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="163"/>
        <source>Optional suffix for a monthly snapshot; only valid together with --month.</source>
        <translation>Sufix opcional per a d&apos;instantània mensual; només vàlid juntament amb --month.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="196"/>
        <source>A single suffix positional argument is only valid together with --month.</source>
        <translation>Un argument posicional amb un sol sufix només és vàlid juntament amb --month.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="255"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Sembla que esteu connectat com a administrador, si us plau sortiu i connecteu-vos com a usuari normal per usar aquest programa.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="270"/>
        <source>version:</source>
        <translation>versió:</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="266"/>
        <source>You must run this program with sudo or pkexec.</source>
        <translation>Cal executar aquest programa amb sudo o pkexec.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="235"/>
        <source>MX Snapshot</source>
        <translation>MX Snapshot </translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="257"/>
        <location filename="../src/main.cpp" line="343"/>
        <location filename="../src/settings.cpp" line="770"/>
        <location filename="../src/settings.cpp" line="779"/>
        <location filename="../src/settings.cpp" line="1396"/>
        <location filename="../src/settings.cpp" line="1506"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="300"/>
        <source>Fatal error:</source>
        <translation>Error fatal:</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="302"/>
        <source>Fatal error: unknown exception</source>
        <translation>Error fatal: excepció desconeguda</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="342"/>
        <location filename="../src/settings.cpp" line="778"/>
        <source>Current kernel doesn&apos;t support Squashfs, cannot continue.</source>
        <translation>El kernel actual no dona suport a Squashfs, no puc continuar.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="261"/>
        <source>Exception during initialization: %1</source>
        <translation>Excepció durant la inicialització: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="216"/>
        <source>Pending Arch bind-root cleanup state but installed-to-live-arch is missing: %1</source>
        <translation>Mentre l&apos;estat de neteja d&apos;Arch bind-root, però hi manca installed-to-live-arch: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="264"/>
        <source>Unknown exception during initialization</source>
        <translation>Excepció desconeguda durant la inicialització</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="299"/>
        <source>Could not create work directory. </source>
        <translation>No s&apos;ha pogut crear el directori de treball.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="382"/>
        <source>No suitable filesystem found for the temp directory. Tried /tmp, /home, and the snapshot directory.</source>
        <translation>No trobo un sistema de fitxers adequat per al directori temp. He provat /tmp, /home, i el directori de la instantània.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="393"/>
        <source>Could not create temp directory:</source>
        <translation>No s&apos;ha pogut crear el directori temporal:</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="394"/>
        <source>Please check that the parent directory exists and is writable:</source>
        <translation>Si us plau, comproveu que el directori principal existeixi i que s&apos;hi pugui escriure:</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="412"/>
        <source>Compression format &apos;%1&apos; is not supported by the current kernel</source>
        <translation>El format de compressió %1 no és compatible amb el nucli actual.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="418"/>
        <source>Invalid cores setting: %1. Must be between 1 and %2</source>
        <translation>Configuració de nuclis no vàlida: %1. Ha de ser entre 1 i %2.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="427"/>
        <source>Invalid throttle setting: %1. Must be between 0 and 99</source>
        <translation>Valor de l&apos;accelerador no vàlid: %1. Ha d&apos;estar entre 0 i 99</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="433"/>
        <source>Snapshot directory cannot be empty</source>
        <translation>El directori d&apos;instantànies no pot estar buit.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="441"/>
        <source>Snapshot name cannot be empty</source>
        <translation>El nom de la instantània no pot estar buit.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="447"/>
        <source>Snapshot name contains invalid characters: %1</source>
        <translation>El nom de la instantània conté caràcters no vàlids: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="453"/>
        <source>Kernel version cannot be empty</source>
        <translation>La versió del nucli no pot estar buida.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="458"/>
        <source>Kernel file not found: /boot/vmlinuz-%1</source>
        <translation>No s&apos;ha trobat el fitxer del nucli: /boot/vmlinuz-%1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="465"/>
        <source>Kernel %1 doesn&apos;t support Squashfs</source>
        <translation>El nucli %1 no admet Squashfs.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="496"/>
        <source>Exclusion file does not exist: %1</source>
        <translation>El fitxer d&apos;exclusió no existeix: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="505"/>
        <source>Unbalanced quotes in exclusion list</source>
        <translation>Cites desequilibrades a la llista d&apos;exclusions</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="530"/>
        <source>Insufficient free space: %1 KiB available, minimum %2 KiB required</source>
        <translation>Espai lliure insuficient: %1 KiB disponible, el mínim requerit és de %2 KiB.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="537"/>
        <source>Insufficient free space in work directory: %1 KiB available, minimum %2 KiB required</source>
        <translation>Espai lliure insuficient al directori de treball: %1 KiB disponible, el mínim requerit és de %2 KiB.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="552"/>
        <source>Failed to determine number of CPU cores</source>
        <translation>No s&apos;ha pogut determinar el nombre de nuclis de CPU.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="558"/>
        <source>Configuration file does not exist: %1</source>
        <translation>El fitxer de configuració no existeix: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="559"/>
        <source>Using default settings</source>
        <translation>S&apos;usa la configuració predeterminada.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="561"/>
        <source>Cannot read configuration file: %1</source>
        <translation>No es pot llegir el fitxer de configuració: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="562"/>
        <source>Error: %1</source>
        <translation>Error: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="572"/>
        <source>Required tool not found: %1</source>
        <translation>No s&apos;ha trobat l&apos;eina necessària: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="581"/>
        <source>Required directory not found: %1</source>
        <translation>No s&apos;ha trobat el directori requerit: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="600"/>
        <source>Initialization Error</source>
        <translation>Error d&apos;inicialització</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="601"/>
        <source>Failed to initialize application settings:

%1</source>
        <translation>No s&apos;ha pogut iniciar la configuració de l&apos;aplicació:

%1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="768"/>
        <source>Could not find a usable kernel</source>
        <translation>No he trobat un kernel utilitzable</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="769"/>
        <source>Searched for kernel files in /boot/ but none were found or accessible.</source>
        <translation>S&apos;han cercat fitxers del nucli a /boot/, però no s&apos;han trobat ni s&apos;hi pot accedir.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="791"/>
        <source>No users found in the system</source>
        <translation>No s&apos;han trobat usuaris al sistema.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="794"/>
        <source>Failed to determine system information</source>
        <translation>No s&apos;ha pogut determinar la informació del sistema.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="964"/>
        <source>Used space on / (root): </source>
        <translation>Espai usat a / (arrel): </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="980"/>
        <source>estimated</source>
        <translation>estimat</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="987"/>
        <source>Used space on /home: </source>
        <translation>Espai usat a /home: </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1048"/>
        <source>Free space on %1, where snapshot folder is placed: </source>
        <translation>Espai lliure a %1, on es desarà la instantània: </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1052"/>
        <source>The free space should be sufficient to hold the compressed data from / and /home

      If necessary, you can create more available space
      by removing previous snapshots and saved copies:
      %1 snapshots are taking up %2 of disk space.
</source>
        <translation>L&apos;espai lliure hauria de ser suficient per encabir-hi les dades comprimides de / i /home.      Si cal, podeu disposar de més espai si suprimiu instantànies      anteriors i còpies desades:       %1 instantànies usen fins a %2 d&apos;espai de disc.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1199"/>
        <source>Error reading system configuration file: %1</source>
        <translation>Error en llegir el fitxer de configuració del sistema: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1208"/>
        <source>Error accessing user configuration</source>
        <translation>Error en accedir a la configuració de l&apos;usuari</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1260"/>
        <source>Could not copy exclusion file from %1 to %2</source>
        <translation>No puc copiar el fitxer d&apos;exclusions de %1 a %2</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1283"/>
        <source>Unsupported compression &apos;%1&apos; in configuration, using zstd.</source>
        <translation>Compressió &apos;%1&apos; a la configuració no suportada, s&apos;usarà zstd.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1293"/>
        <source>Invalid stored cores setting (%1). Using detected CPU count: %2</source>
        <translation>Paràmetre de nuclis desat no vàlid (%1). Usant el compte de CPUs detectat, compte: %2</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1303"/>
        <source>Invalid stored throttle setting (%1). Using 0.</source>
        <translation>Valor desat de l&apos;accelerador no vàlid (%1). S&apos;usarà 0.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1394"/>
        <location filename="../src/settings.cpp" line="1504"/>
        <source>Output file %1 already exists. Please use another file name, or delete the existent file.</source>
        <translation>El fitxer de sortida %1 ja hi és. Si us plau, useu un altre nom de fitxer, o esborreu el fitxer existent.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="73"/>
        <source>Could not load %1</source>
        <translation>No s&apos;ha pogut carregar %1</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>License</source>
        <translation>Llicència</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <location filename="../src/about.cpp" line="107"/>
        <source>Changelog</source>
        <translation>Registre de canvis</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="98"/>
        <source>Cancel</source>
        <translation>Cancel·la</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="119"/>
        <source>Could not load changelog.</source>
        <translation>No s&apos;ha pogut carregar el registre de canvis.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="53"/>
        <location filename="../src/about.cpp" line="122"/>
        <source>&amp;Close</source>
        <translation>Tan&amp;ca </translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="78"/>
        <source>No diff output available.</source>
        <translation>No hi ha sortida de diferències disponible.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="91"/>
        <source>Could not open default exclusion file at %1.</source>
        <translation>No puc obrir el fitxer d&apos;exclusió per omissió a %1.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="97"/>
        <source>Could not create exclusion file directory at %1.</source>
        <translation>No uc crear el directori dels fitxers d&apos;exclusió a %1.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="106"/>
        <source>Could not prepare exclusion file at %1.</source>
        <translation>No puc preparar el fitxer d&apos;exclusió a %1.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="123"/>
        <source>Could not read default exclusion file at %1.</source>
        <translation>No puc llegir el fitxer d&apos;exclusió per omissió a %1.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="131"/>
        <source>Could not write exclusion file at %1.</source>
        <translation>No puc escriure el fitxer d&apos;exclusió a %1.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="113"/>
        <source>Could not backup existing exclusion file to %1.</source>
        <translation>No s&apos;ha pogut fer una còpia de seguretat del fitxer d&apos;exclusió existent a %1.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="139"/>
        <source>Could not copy default exclusion file from %1 to %2.</source>
        <translation>No puc copiar el fitxer d&apos;exclusions per omissió de %1 a %2.</translation>
    </message>
</context>
<context>
    <name>Work</name>
    <message>
        <location filename="../src/work.cpp" line="247"/>
        <source>Cleaning...</source>
        <translation>Endreçant... </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="278"/>
        <location filename="../src/work.cpp" line="1060"/>
        <source>Done</source>
        <translation>Fet </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="292"/>
        <source>Interrupted or failed to complete</source>
        <translation>Aturat o fallat en completar </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="303"/>
        <location filename="../src/work.cpp" line="360"/>
        <location filename="../src/work.cpp" line="564"/>
        <location filename="../src/work.cpp" line="572"/>
        <location filename="../src/work.cpp" line="607"/>
        <location filename="../src/work.cpp" line="650"/>
        <location filename="../src/work.cpp" line="678"/>
        <location filename="../src/work.cpp" line="692"/>
        <location filename="../src/work.cpp" line="706"/>
        <location filename="../src/work.cpp" line="714"/>
        <location filename="../src/work.cpp" line="720"/>
        <location filename="../src/work.cpp" line="728"/>
        <location filename="../src/work.cpp" line="777"/>
        <location filename="../src/work.cpp" line="793"/>
        <location filename="../src/work.cpp" line="854"/>
        <location filename="../src/work.cpp" line="869"/>
        <location filename="../src/work.cpp" line="877"/>
        <location filename="../src/work.cpp" line="888"/>
        <location filename="../src/work.cpp" line="896"/>
        <location filename="../src/work.cpp" line="1013"/>
        <location filename="../src/work.cpp" line="1030"/>
        <location filename="../src/work.cpp" line="1043"/>
        <location filename="../src/work.cpp" line="1051"/>
        <location filename="../src/work.cpp" line="1107"/>
        <location filename="../src/work.cpp" line="1398"/>
        <location filename="../src/work.cpp" line="1406"/>
        <location filename="../src/work.cpp" line="1420"/>
        <location filename="../src/work.cpp" line="1459"/>
        <location filename="../src/work.cpp" line="1509"/>
        <location filename="../src/work.cpp" line="1533"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="304"/>
        <source>Administrator access was not granted; the snapshot cannot continue.</source>
        <translation>No s&apos;ha garantit l&apos;accés com a administrador; la instantània no pot continuar.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="361"/>
        <source>There&apos;s not enough free space on your target disk, you need at least %1</source>
        <translation>No hi ha prou espai lliure al vostre disc objectiu, us cal com a mínim %1</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="364"/>
        <source>You have %1 free space on %2</source>
        <translation>Teniu un espai lliure de %1  a %2</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="367"/>
        <source>If you are sure you have enough free space rerun the program with -o/--override-size option</source>
        <translation>Si teniu la seguretat de tenir prou espai lliure, torneu a executar el programa amb l&apos;opció -o/--override-size </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="545"/>
        <source>Copying the new-iso filesystem...</source>
        <translation>Copiant el sistema de fitxers del nou-iso: </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="564"/>
        <source>ISO template not found: </source>
        <translation>No he trobat la plantilla ISO: </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="572"/>
        <location filename="../src/work.cpp" line="692"/>
        <source>Could not extract the ISO template: </source>
        <translation>No puc extreure la plantilla del ISO: </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="600"/>
        <source>Arch ISO template is missing boot/ or efi/ directories.</source>
        <translation>La plantilla ISO Arch no té els directoris boot/ o efi/.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="603"/>
        <source>Detected boot/ or efi/ under the work directory root; the template may have been extracted to the wrong location.</source>
        <translation>Detectats boot/ o efi/ a l&apos;arrel del directori de treball; la plantilla potser s&apos;ha extret a la ubicació equivocada.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="606"/>
        <source>Template: %1</source>
        <translation>Plantilla: %1 </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="642"/>
        <source>Stale archiso initramfs detected, rebuilding...</source>
        <translation>Detectat un archiso initramfs vell, reconstruint...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="644"/>
        <source>Found /boot/archiso.img built for kernel %1, but the selected kernel is %2.</source>
        <translation>Trobada una /boot/archiso.img feta per al kernel %1, però el kernel seleccionat és el %2.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="648"/>
        <source>Rebuilding /boot/archiso.img failed. Please rebuild it manually or remove the stale file.</source>
        <translation>Ha fallat la reconstrucció de /boot/archiso.img . Si us plau, reconstruïu-lo manualment o elimineu el fitxer vell.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="660"/>
        <source>No /boot/archiso.img found, attempting to create one...</source>
        <translation>No he trobat la /boot/archiso.img, intentant crear-ne una...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="665"/>
        <location filename="../src/work.cpp" line="1097"/>
        <source>Warning</source>
        <translation>Atenció </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="666"/>
        <source>Could not create /boot/archiso.img (is the &apos;archiso&apos; package installed?). Falling back to the regular initramfs — the resulting ISO will likely fail to boot (&quot;Failed to start Switch Root&quot;).</source>
        <translation>No puc crear /boot/archiso.img (està instal·lat el paquet &apos;archiso&apos;?). Retornant a l &apos;initramfs normal — El ISO resultant probablement fallarà en arrencar (&quot;Falla en iniciar Switch Root&quot;).</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="678"/>
        <source>Could not find an initramfs image to use.</source>
        <translation>No trobo una imatge  initramfs per usar.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="707"/>
        <source>--grub-mbr option specified but boot/grub/i386-pc/eltorito.img is missing from iso-template</source>
        <translation>--s&apos;ha especificat l&apos;opció grub-mbr però no hi ha boot/grub/i386-pc/eltorito.img a l&apos;iso-template</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="715"/>
        <source>Could not copy the template initrd: </source>
        <translation>No puc copiar la plantilla initrd: </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="721"/>
        <source>Could not copy the kernel: </source>
        <translation>No puc copiar el kernel: </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="729"/>
        <location filename="../src/work.cpp" line="794"/>
        <location filename="../src/work.cpp" line="878"/>
        <location filename="../src/work.cpp" line="897"/>
        <source>Could not create the checksum for %1.</source>
        <translation>No puc crear la suma de verificació per %1.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="737"/>
        <source>Could not create temp directory. </source>
        <translation>No puc crear el directori temporal.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="778"/>
        <source>Could not copy the kernel modules or programs into the initrd.</source>
        <translation>No puct copiar els mòduls del kernel o programes dins de initrd.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="844"/>
        <source>Squashing filesystem...</source>
        <translation>Compactant el sistema de fitxers... </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="855"/>
        <source>Could not create linuxfs file, please check /var/log/%1.log</source>
        <translation>No he pogut crear el fitxer linuxfs, si us plau comproveu /var/log/%1.log</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="870"/>
        <location filename="../src/work.cpp" line="889"/>
        <source>Could not move %1 to the ISO directory.</source>
        <translation>Mo puc moure %1 al directori ISO.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1004"/>
        <source>Creating CD/DVD image file...</source>
        <translation>Creant el fitxer d&apos;imatge CD/DVD...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1014"/>
        <source>Could not create ISO file, please check whether you have enough space on the destination partition.</source>
        <translation>No he pogut crear el fitxer ISO; si us plau, comproveu que hi hagi prou espai a la partició de destinació.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1024"/>
        <source>Making hybrid iso</source>
        <translation>Creant imatge ISO híbrida </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1031"/>
        <source>Could not make the ISO hybrid; it would not boot correctly from USB.</source>
        <translation>No puc crear l&apos;ISO híbrid; no arrencaria correctament des d&apos;un USB.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1044"/>
        <location filename="../src/work.cpp" line="1052"/>
        <source>Could not create the %1 checksum for the ISO.</source>
        <translation>No puc crear la suma de verificació %1 per a la ISO.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1065"/>
        <source>Success</source>
        <translation>Èxit</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1066"/>
        <source>MX Snapshot completed successfully!</source>
        <translation>MX Snapshot completat amb èxit!</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1067"/>
        <source>Snapshot took %1 to finish.</source>
        <translation>Snapshot ha necessitat %1 per acabar.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1068"/>
        <source>Thanks for using MX Snapshot, run MX Live USB Maker next!</source>
        <translation>Gràcies per usar MX Snapshot, executeu MX Live USB Maker ara!</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1083"/>
        <location filename="../src/work.cpp" line="1104"/>
        <source>Installing </source>
        <translation>S&apos;instal·la </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1094"/>
        <source>paru not found; cannot install %1 from the AUR.</source>
        <translation>No he trobat paru: no es pot instal·lar  %1 de l&apos;AUR.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1098"/>
        <source>Could not install %1; continuing without the installer.</source>
        <translation>No he pogut instal·lar %1; continuo sense l&apos;instal·lador.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1107"/>
        <source>Could not install </source>
        <translation>No s&apos;ha pogut instal·lar </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1117"/>
        <source>Calculating checksum...</source>
        <translation>Calculant la suma de verificació...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1168"/>
        <source>Building new initrd...</source>
        <translation>Generant nou initrd...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1271"/>
        <source>Rebuilding initramfs with: mkinitcpio %1</source>
        <translation>Reconstruint intramfs amb mkinitcpio %1</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1398"/>
        <location filename="../src/work.cpp" line="1420"/>
        <source>Could not create the package list: </source>
        <translation>No puc crear la llista de paquets.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1407"/>
        <source>Could not create working directory. </source>
        <translation>No puc crear el directori de treball.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1460"/>
        <source>Could not prepare a safe bind-root overlay. Snapshot cannot continue.</source>
        <translation>No s&apos;ha pogut preparar una superposició d&apos;arrel de vinculació segura. La instantània no pot continuar.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1510"/>
        <location filename="../src/work.cpp" line="1534"/>
        <source>Could not prepare the snapshot bind-root environment.</source>
        <translation>No s&apos;ha pogut preparar l&apos;entorn d&apos;arrel de vinculació de la instantània.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1870"/>
        <source>Calculating total size of excluded files...</source>
        <translation>Calculant la mida total dels fitxers exclosos...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1897"/>
        <source>Calculating size of root...</source>
        <translation>Calculant la mida de l&apos;arrel...</translation>
    </message>
</context>
</TS>