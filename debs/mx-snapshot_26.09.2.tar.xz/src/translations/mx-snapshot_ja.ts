<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="ja">
<context>
    <name>Batchprocessing</name>
    <message>
        <location filename="../src/batchprocessing.cpp" line="53"/>
        <source>Error</source>
        <translation>エラー</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="54"/>
        <source>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</source>
        <translation>現在のカーネルは選択された圧縮アルゴリズムをサポートしていないので、設定ファイルを編集して別のアルゴリズムを選択してください。</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="101"/>
        <source>The program will pause the build and open the boot menu in your text editor.</source>
        <translation>このプログラムでは、ビルドを一時停止し、テキストエディタでブートメニューを開きます。</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="114"/>
        <source>The boot-menu editor failed; the snapshot cannot continue with potentially unedited files.</source>
        <translation>ブートメニューエディタの処理に失敗しました。編集していないファイルが残っている可能性があるので、スナップショットは処理を続行できません。</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="131"/>
        <source>Administrator access was not granted; the snapshot cannot continue.</source>
        <translation>管理者権限が付与されなかったので、スナップショットの処理は続行できません。</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="258"/>
        <source>Detected newer exclusion file at %1 compared to %2. Prompting for action.</source>
        <translation>%2 と比較して、%1 に新規の除外ファイルを検出しました。対処方法について確認します。</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="264"/>
        <source>s</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'show diff'</comment>
        <translation>s</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="265"/>
        <source>u</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'use updated default'</comment>
        <translation>u</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="266"/>
        <source>k</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'keep custom (update timestamp)'</comment>
        <translation>k</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="267"/>
        <source>q</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'quit'</comment>
        <translation>q</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="269"/>
        <source>show diff</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>差分の表示</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="270"/>
        <source>use updated default</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>更新された既定値を使用する</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="271"/>
        <source>keep custom (update timestamp)</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>カスタム設定の維持（タイムスタンプを更新）</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="272"/>
        <source>quit</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>中止</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="275"/>
        <source>[%1]%2  [%3]%4  [%5]%6  [%7]%8: </source>
        <translation>[%1]%2  [%3]%4  [%5]%6  [%7]%8: </translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="280"/>
        <source>The exclusion file at %1 is newer than your configured file at %2.</source>
        <translation>%1 の除外ファイルは、%2 の設定ファイルよりも新しいものです。</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="296"/>
        <source>Reverted to updated default exclusion file.</source>
        <translation>更新済みの既定の除外ファイルに戻しました。</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="313"/>
        <source>No input available to answer the exclusion file prompt; aborting without creating a snapshot.</source>
        <translation>除外ファイルに対するプロンプトへの応答がなかったので、スナップショットの作成を中止します。</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="316"/>
        <source>Leaving custom exclusion file unchanged.</source>
        <translation>カスタムの除外ファイルは変更しません。</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="327"/>
        <source>Invalid choice. Please select again.</source>
        <translation>無効な選択です。もう一度選択してください。</translation>
    </message>
</context>
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="121"/>
        <source>No elevation tool found (pkexec/gksu/sudo).</source>
        <translation>権限昇格ツール（pkexec/gksu/sudo）が見つかりません。</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="212"/>
        <source>Failed to start command: %1</source>
        <translation>コマンド %1 の起動に失敗しました</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="283"/>
        <source>Administrator access was not granted (authentication cancelled or denied).</source>
        <translation>管理者権限が付与されませんでした（認証がキャンセルまたは拒否されました）。</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <location filename="../src/mainwindow.cpp" line="396"/>
        <location filename="../src/mainwindow.cpp" line="944"/>
        <source>MX Snapshot</source>
        <translation>MX スナップショット</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="33"/>
        <source>Optional customization</source>
        <translation>カスタムオプション</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="65"/>
        <source>Release version:</source>
        <translation>リリースのバージョン:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="79"/>
        <source>Boot options:</source>
        <translation>起動オプション:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="86"/>
        <source>Live kernel:</source>
        <translation>ライブカーネル:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="93"/>
        <source>Project name:</source>
        <translation>プロジェクト名:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="100"/>
        <source>Release date:</source>
        <translation>リリースの日付</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="107"/>
        <source>Release codename:</source>
        <translation>リリースのコード名:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="133"/>
        <source>Current date</source>
        <translation>現在の日付</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="172"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Snapshot is a utility that creates a bootable image (ISO) of your working system that you can use for storage or distribution. You can continue working with undemanding applications while it is running.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;MX スナップショットは、稼働中のシステムからストレージへのインストールまたは他人へ配布する用途で、起動可能なイメージ (ISO) を作製するユーティリティです。少ない手順で作業を進める事ができます。&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="182"/>
        <source>Used space on / (root) and /home partitions:</source>
        <translation>/ (root) および /home パーティションの空き容量を使用します: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="192"/>
        <source>Location and ISO name</source>
        <translation>場所と ISO の名称</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="219"/>
        <source>Snapshot location:</source>
        <translation>スナップショットの保存場所:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="226"/>
        <source>Select a different snapshot directory</source>
        <translation>差分スナップショットのディレクトリを選択</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="236"/>
        <location filename="../src/mainwindow.cpp" line="644"/>
        <source>Snapshot name:</source>
        <translation>スナップショットのファイル名:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="360"/>
        <source>Type of snapshot:</source>
        <translation>スナップショットの種類:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="367"/>
        <source>Preserving accounts (for personal backup)</source>
        <translation>アカウントの保存 (個人的なバックアップ用途)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This option will reset &amp;quot;demo&amp;quot; and &amp;quot;root&amp;quot; passwords to the MX Linux defaults and will not copy any personal accounts created.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;このオプションでは、MX Linux の「demo」と「root」パスワードを既定にリセットします。また、作成した個人アカウントはコピーしません。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="380"/>
        <source>Resetting accounts (for distribution to others)</source>
        <translation>アカウントのリセット (他人へ配布する用途)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="451"/>
        <source>You can also exclude certain directories by ticking the common choices below, or by clicking on the button to directly edit /etc/mx-snapshot-exclude.list.</source>
        <translation>以下の一般的な選択肢にチェックを入れるか、またはボタンをクリックして /etc/mx-snapshot-exclude.list を直接編集することによっても、特定のディレクトリを除外することができます。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="496"/>
        <source>sha512</source>
        <translation>sha512</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="519"/>
        <source>Throttle the I/O input rate by the given percentage.</source>
        <translation>I/O 入力レートを指定したパーセンテージに制御します。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="525"/>
        <source>I/O throttle:</source>
        <translation>I/O スロットリング:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="532"/>
        <source>Calculate checksums:</source>
        <translation>チェックサムの生成:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="539"/>
        <source>ISO compression scheme:</source>
        <translation>ISO 圧縮方式：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="546"/>
        <source>Number of CPU cores to use:</source>
        <translation>使用する CPU コア数:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="553"/>
        <source>md5</source>
        <translation>md5</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="563"/>
        <source>Options:</source>
        <translation>オプション:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="610"/>
        <source>Edit Exclusion File</source>
        <translation>除外するファイルを編集</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="626"/>
        <location filename="../src/mainwindow.cpp" line="969"/>
        <source>Remove Custom Exclusion File</source>
        <translation>カスタム除外ファイルの削除</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="679"/>
        <source>Pictures</source>
        <translation>画像</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="686"/>
        <source>Videos</source>
        <translation>動画</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="693"/>
        <source>All of the above</source>
        <translation>上記すべて</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="700"/>
        <source>exclude network configurations</source>
        <translation>ネットワークの設定を除外します</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="703"/>
        <source>Networks</source>
        <translation>ネットワーク</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="710"/>
        <source>Downloads</source>
        <translation>ダウンロード</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="717"/>
        <source>Desktop</source>
        <translation>デスクトップ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="724"/>
        <source>Documents</source>
        <translation>文書</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="731"/>
        <source>Flatpaks</source>
        <translation>Flatpaks</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="738"/>
        <source>Music</source>
        <translation>音楽</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="881"/>
        <source>About this application</source>
        <translation>このアプリケーションについて</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="884"/>
        <source>About...</source>
        <translation>情報...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="890"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1005"/>
        <source>Next</source>
        <translation>次へ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="906"/>
        <source>Display help </source>
        <translation>ヘルプを表示</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="909"/>
        <source>Help</source>
        <translation>ヘルプ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="915"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1030"/>
        <source>Quit application</source>
        <translation>アプリケーションの終了</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1033"/>
        <source>Cancel</source>
        <translation>キャンセル</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1039"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="989"/>
        <source>Back</source>
        <translation>戻る</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="358"/>
        <source>Select Release Date</source>
        <translation>リリースの日付を選択</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="402"/>
        <source>fastest, worst compression</source>
        <translation>最も高速ですが低圧縮です</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="402"/>
        <source>fast, worse compression</source>
        <translation>高速ですがやや低圧縮です</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="403"/>
        <source>slow, better compression</source>
        <translation>低速ですが良く圧縮できます</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="403"/>
        <source>best compromise</source>
        <translation>最もバランスの良い選択です</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="404"/>
        <source>slowest, best compression</source>
        <translation>最も低速ですが高圧縮です</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="433"/>
        <source>Free space on %1, where snapshot folder is placed: </source>
        <translation>スナップショットのフォルダがある場所の空き容量 %1：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="436"/>
        <source>The free space should be sufficient to hold the compressed data from / and /home

      If necessary, you can create more available space by removing previous snapshots and saved copies: %1 snapshots are taking up %2 of disk space.</source>
        <translation>空き容量は / と /home の圧縮データを保持するのに十分でなくてはなりません。

      必要に応じて、以前作成したスナップショットや保存済みのコピーを削除して、使用可能な領域を増やすことができます。 %1 スナップショットはディスク領域の %2 を占有しています。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="448"/>
        <location filename="../src/mainwindow.cpp" line="449"/>
        <source>Installing </source>
        <translation>インストール中</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="587"/>
        <source>Please wait.</source>
        <translation>お待ちください。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="589"/>
        <source>Please wait. Calculating used disk space...</source>
        <translation>お待ちください。使用済みディスク容量を計算しています...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="275"/>
        <location filename="../src/mainwindow.cpp" line="489"/>
        <location filename="../src/mainwindow.cpp" line="623"/>
        <location filename="../src/mainwindow.cpp" line="630"/>
        <location filename="../src/mainwindow.cpp" line="712"/>
        <location filename="../src/mainwindow.cpp" line="723"/>
        <location filename="../src/mainwindow.cpp" line="748"/>
        <location filename="../src/mainwindow.cpp" line="1034"/>
        <source>Error</source>
        <translation>エラー</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="175"/>
        <location filename="../src/mainwindow.cpp" line="211"/>
        <source>Updated Exclusion List</source>
        <translation>更新済みの除外リスト</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="178"/>
        <source>The exclusion file at %1 is newer than your configured file at %2.</source>
        <translation>%1 の除外ファイルは、%2 の設定ファイルよりも新しいものです。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="180"/>
        <source>Review the changes below. Keep your custom file or replace it with the updated default.</source>
        <translation>以下の変更内容を確認してください。カスタムファイルをそのまま残すか、更新済みの既定ファイルへ置き換えてください。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="186"/>
        <source>Show Differences</source>
        <translation>相違点の表示</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="192"/>
        <source>Keep Custom</source>
        <translation>カスタムを保持</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="198"/>
        <source>Use Updated Default</source>
        <translation>更新した既定を使用</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="490"/>
        <source>Administrator access was not granted; the snapshot cannot continue.</source>
        <translation>管理者権限が付与されなかったので、スナップショットの処理は続行できません。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="522"/>
        <source>Done</source>
        <translation>完了</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="624"/>
        <source>Output file %1 already exists. Please use another file name, or delete the existent file.</source>
        <translation>出力ファイル名 %1 はすでに存在します。別の名前を使用するか、すでにあるそのファイルを削除してください。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="631"/>
        <source>Insufficient free space. Please select a different snapshot directory or free up space.</source>
        <translation>空き容量が不足しています。スナップショットに別のディレクトリを選択するか、空き容量を確保してください。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="635"/>
        <source>Settings</source>
        <translation>設定中</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="641"/>
        <source>Snapshot will use the following settings:</source>
        <translation>スナップショットでは、今後以下の設定に従います。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="643"/>
        <source>- Snapshot directory:</source>
        <translation>- スナップショットのディレクトリ: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="644"/>
        <source>- Kernel to be used:</source>
        <translation>- 使用するカーネル: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="668"/>
        <location filename="../src/mainwindow.cpp" line="677"/>
        <source>NVIDIA Detected</source>
        <translation>NVIDIA を検出</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="669"/>
        <source>This computer uses an NVIDIA graphics card. Are you planning to use the resulting ISO on the same computer or another computer with an NVIDIA card?</source>
        <translation>このコンピュータは NVIDIA グラフィックカードを使用しています。出来上がった ISO をこのコンピュータ、または NVIDIA カード搭載の別コンピュータで使用する予定はありますか？</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="673"/>
        <source>NVIDIA Selected</source>
        <translation>NVIDIA を選択中</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="674"/>
        <source>Note: If you use the resulting ISO on a computer without an NVIDIA card, you will likely need to remove &apos;xorg=nvidia&apos; from the boot options.</source>
        <translation>注意。出来上がった ISO を NVIDIA カード非搭載のコンピュータで使う場合、起動オプションの中から &apos;xorg=nvidia&apos; という記述を削除する必要があります。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="678"/>
        <source>Note: If you use the resulting ISO on a computer with an NVIDIA card, you may need to add &apos;xorg=nvidia&apos; to the boot options.</source>
        <translation>注意。出来上がった ISO を NVIDIA カード搭載コンピュータで使う場合、起動オプションに &apos;xorg=nvidia&apos; を追加する必要があるかもしれません。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="276"/>
        <location filename="../src/mainwindow.cpp" line="713"/>
        <source>Could not replace the exclusion file with the updated default.</source>
        <translation>除外ファイルを更新済みの既定ファイルで置き換えることができませんでした。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="724"/>
        <source>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</source>
        <translation>現在のカーネルは選択された圧縮アルゴリズムをサポートしていないので、設定ファイルを編集して別のアルゴリズムを選択してください。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="744"/>
        <source>Cancelled</source>
        <translation>中止しました</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="745"/>
        <source>Administrator access is required to create a snapshot.</source>
        <translation>スナップショットの作成には、管理者権限が必要です。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="746"/>
        <source>The operation was cancelled. Select Next when you are ready to try again.</source>
        <translation>操作を取り消しました。もう一度実行するには、準備を整えてから「次へ」を選択してください。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="749"/>
        <source>Could not create the snapshot or work directory.</source>
        <translation>スナップショット用のディレクトリまたは作業用のディレクトリを作成できません。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="762"/>
        <source>Final chance</source>
        <translation>最終確認</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="764"/>
        <source>Snapshot now has all the information it needs to create an ISO from your running system.</source>
        <translation>MX スナップショットには現在、稼働しているシステムから ISO を生成するために必要な全情報を含んでいます。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="765"/>
        <source>It will take some time to finish, depending on the size of the installed system and the capacity of your computer.</source>
        <translation>作業完了までにかかる時間は、インストールを行うシステムのサイズとコンピュータの性能によって異なります。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="767"/>
        <source>OK to start?</source>
        <translation>OK で開始します</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="824"/>
        <location filename="../src/mainwindow.cpp" line="771"/>
        <source>Shutdown computer when done.</source>
        <translation>完了したらコンピュータをシャットダウンする。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="805"/>
        <source>Output</source>
        <translation>出力</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="849"/>
        <source>Close</source>
        <translation>閉じる</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="924"/>
        <source>Edit Boot Menu</source>
        <translation>起動メニューの編集</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="925"/>
        <source>The program will now pause to allow you to edit any files in the work directory. Select Yes to edit the boot menu or select No to bypass this step and continue creating the snapshot.</source>
        <translation>プログラムは、作業ディレクトリで任意ファイルを編集できるように、一時休止しています。「はい」を選んで起動メニューを編集するか、「いいえ」を選んでこのステップを飛ばしてスナップショットの作成を継続するかを選んでください。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="970"/>
        <source>Revert the exclusion list to the default file? This will overwrite your current exclusions.</source>
        <translation>除外リストを既定のファイルに戻しますか？ この操作によって、現在の除外リストを上書きします。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1002"/>
        <source>About %1</source>
        <translation> %1 について</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1004"/>
        <source>Version: </source>
        <translation>バージョン: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1005"/>
        <source>Program for creating a live-CD from the running system for MX Linux</source>
        <translation>起動中の MX Linux を元にして Live CD を生成するプログラム</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1007"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1009"/>
        <source>%1 License</source>
        <translation>%1 ライセンス</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1022"/>
        <source>%1 Help</source>
        <translation>%1 のヘルプ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1027"/>
        <source>Select Snapshot Directory</source>
        <translation>スナップショットを保存するディレクトリを選択</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1035"/>
        <source>Insufficient free space in the selected directory. Please choose a different location.</source>
        <translation>選択したディレクトリでは空き容量が不足です。別の場所を選択してください。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1079"/>
        <source>Confirmation</source>
        <translation>確認</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1079"/>
        <source>Are you sure you want to quit the application?</source>
        <translation>本当にこのアプリを終了しますか？</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/main.cpp" line="109"/>
        <source>Tool used for creating a live-CD from the running system</source>
        <translation>稼働中のシステムから Live-CD を作成するツール</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>Use CLI only</source>
        <translation>コマンドラインのみ使用する</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="117"/>
        <source>Number of CPU cores to be used.</source>
        <translation>使用する CPU のコアの数です</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="118"/>
        <source>Output directory</source>
        <translation>出力先のディレクトリ</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="119"/>
        <source>Output filename</source>
        <translation>出力先のファイル名</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="121"/>
        <source>Name a different kernel to use other than the default running kernel, use format returned by &apos;uname -r&apos;</source>
        <translation>別のカーネル名を指定して、既定で動作しているカーネル以外を使用します。なお、&apos;uname -r&apos; が返す書式を利用します。</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="123"/>
        <source>Or the full path: %1</source>
        <translation>またはフルパス： %1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="126"/>
        <source>Compression level options.</source>
        <translation>圧縮レベルのオプション。</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="127"/>
        <source>Use quotes: &quot;-Xcompression-level &lt;level&gt;&quot;, or &quot;-Xalgorithm &lt;algorithm&gt;&quot;, or &quot;-Xhc&quot;, see mksquashfs man page</source>
        <translation>引用符を使って、 &quot;-Xcompression-level &lt;level&gt;&quot; または &quot;-Xalgorithm &lt;algorithm&gt;&quot; または &quot;-Xhc&quot; とします。詳しくは mksquashfs のマニュアルページを見てください。</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="131"/>
        <source>Create a monthly snapshot, add &apos;Month&apos; name in the ISO name, skip used space calculation</source>
        <translation>月毎のスナップショットの作成。ISO名に月名を追加し、使用済み容量の計算をスキップ。</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="132"/>
        <source>This option sets reset-accounts and compression to defaults, arguments changing those items will be ignored</source>
        <translation>このオプションは reset-accounts と compression を既定に設定し、これらの項目を変更する引数は無視します。</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="134"/>
        <source>Optionally specify a suffix to add to the month name (e.g., &apos;1&apos; for &apos;July.1&apos;)</source>
        <translation>オプションで、月名に追加する接尾辞を指定できます。（例えば、&apos;July.1&apos; の場合は &apos;1&apos; を指定します）</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="135"/>
        <source>Don&apos;t calculate checksums for resulting ISO file</source>
        <translation>作成した ISO ファイルのチェックサムを計算しない</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="136"/>
        <source>Skip calculating free space to see if the resulting ISO will fit</source>
        <translation>作成する ISO が収まるかどうかの、空き容量計算をスキップする</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="137"/>
        <source>Option to fix issue with calculating checksums on preempt_rt kernels</source>
        <translation>preempt_rt カーネルでのチェックサムに関する問題を修正するためのオプション</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="138"/>
        <source>Resetting accounts (for distribution to others)</source>
        <translation>アカウントのリセット (他人へ配布する用途向け)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="139"/>
        <source>Calculate checksums for resulting ISO file</source>
        <translation>作成したISOファイルのチェックサムを算出する</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="141"/>
        <source>Throttle the I/O input rate by the given percentage. This can be used to reduce the I/O and CPU consumption of Mksquashfs.</source>
        <translation>I/O入力レートを指定したパーセンテージに制御します。これは Mksquashfs の I/O と CPU の消費を低減する目的で使用できます。</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="144"/>
        <source>Work directory</source>
        <translation>作業用ディレクトリ</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="146"/>
        <source>Exclude main folders, valid choices: </source>
        <translation>メインフォルダの除外、有効にするオプション:</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="148"/>
        <source>Use the option one time for each item you want to exclude</source>
        <translation>除外したい項目毎に、１度だけ使用してください</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="151"/>
        <source>Compression format, valid choices: </source>
        <translation>有効にする圧縮形式の選択: </translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="153"/>
        <source>Shutdown computer when done.</source>
        <translation>完了したらコンピュータをシャットダウンする。</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="154"/>
        <source>Use grub for legacy mbr iso boot instead of isolinux/syslinux.</source>
        <translation>レガシー MBR ISO ブートには、isolinux/syslinux の代わりに grub を使用する</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="155"/>
        <source>Add the &apos;xorg=nvidia&apos; boot option to the ISO (for booting on a system with an NVIDIA card).</source>
        <translation>ISO に「xorg=nvidia」という起動オプションを追加する（NVIDIA カード搭載のシステムで起動する場合）。</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="163"/>
        <source>Optional suffix for a monthly snapshot; only valid together with --month.</source>
        <translation>月次スナップショット用オプションのサフィックスは、--month オプションと組み合わせて使用する場合にのみ有効です。</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="196"/>
        <source>A single suffix positional argument is only valid together with --month.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="255"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>root ユーザとしてログインしているようです。このプログラムを使用するには、一度ログアウトして通常のユーザとしてログインしてください。</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="270"/>
        <source>version:</source>
        <translation>バージョン:</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="266"/>
        <source>You must run this program with sudo or pkexec.</source>
        <translation>このプログラムは、sudo または pkexec で実行する必要があります。</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="235"/>
        <source>MX Snapshot</source>
        <translation>MX スナップショット</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="257"/>
        <location filename="../src/main.cpp" line="343"/>
        <location filename="../src/settings.cpp" line="770"/>
        <location filename="../src/settings.cpp" line="779"/>
        <location filename="../src/settings.cpp" line="1396"/>
        <location filename="../src/settings.cpp" line="1506"/>
        <source>Error</source>
        <translation>エラー</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="300"/>
        <source>Fatal error:</source>
        <translation>致命的エラー:</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="302"/>
        <source>Fatal error: unknown exception</source>
        <translation>致命的エラー: 不明な例外です</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="342"/>
        <location filename="../src/settings.cpp" line="778"/>
        <source>Current kernel doesn&apos;t support Squashfs, cannot continue.</source>
        <translation>現在のカーネルは Squashfs をサポートしてないので続行できません。</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="261"/>
        <source>Exception during initialization: %1</source>
        <translation>初期化中に例外が発生しました: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="216"/>
        <source>Pending Arch bind-root cleanup state but installed-to-live-arch is missing: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="264"/>
        <source>Unknown exception during initialization</source>
        <translation>初期化中に不明な例外が発生しました</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="299"/>
        <source>Could not create work directory. </source>
        <translation>作業用ディレクトリを作成できません。</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="382"/>
        <source>No suitable filesystem found for the temp directory. Tried /tmp, /home, and the snapshot directory.</source>
        <translation>一時ディレクトリとして適切なファイルシステムが見つかりません。/tmp、/home、および snapshot ディレクトリは試しました。</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="393"/>
        <source>Could not create temp directory:</source>
        <translation>テンポラリディレクトリを作成できません:</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="394"/>
        <source>Please check that the parent directory exists and is writable:</source>
        <translation>親ディレクトリが存在し、書き込み可能かどうかをチェックしてください:</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="412"/>
        <source>Compression format &apos;%1&apos; is not supported by the current kernel</source>
        <translation>現在のカーネルは、圧縮形式 &apos;%1&apos; をサポートしません</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="418"/>
        <source>Invalid cores setting: %1. Must be between 1 and %2</source>
        <translation>無効なコア数設定: %1。1 から %2 の範囲にしてください</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="427"/>
        <source>Invalid throttle setting: %1. Must be between 0 and 99</source>
        <translation>スロットルの設定が不適切です: %1。0～99 の範囲で指定してください。</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="433"/>
        <source>Snapshot directory cannot be empty</source>
        <translation>スナップショットディレクトリは空にできません</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="441"/>
        <source>Snapshot name cannot be empty</source>
        <translation>スナップショット名は空欄にできません</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="447"/>
        <source>Snapshot name contains invalid characters: %1</source>
        <translation>スナップショット名に次の無効な文字が含まれています: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="453"/>
        <source>Kernel version cannot be empty</source>
        <translation>カーネルのバージョンは空欄にできません</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="458"/>
        <source>Kernel file not found: /boot/vmlinuz-%1</source>
        <translation>カーネルファイルが見つかりません: /boot/vmlinuz-%1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="465"/>
        <source>Kernel %1 doesn&apos;t support Squashfs</source>
        <translation>カーネル %1 は Squashfs をサポートしません</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="496"/>
        <source>Exclusion file does not exist: %1</source>
        <translation>除外ファイルは存在しません: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="505"/>
        <source>Unbalanced quotes in exclusion list</source>
        <translation>除外リスト内の引用符がおかしいです</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="530"/>
        <source>Insufficient free space: %1 KiB available, minimum %2 KiB required</source>
        <translation>十分な空き容量がありません: %1 KiB が利用可能で、最小は %2 KiB 必要です</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="537"/>
        <source>Insufficient free space in work directory: %1 KiB available, minimum %2 KiB required</source>
        <translation>作業用ディレクトリ内の空き容量が不足です: %1 KiB の空き、最低 %2 KiB が必要</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="552"/>
        <source>Failed to determine number of CPU cores</source>
        <translation>CPU コア数の判定ができません</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="558"/>
        <source>Configuration file does not exist: %1</source>
        <translation>設定ファイルが存在しません: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="559"/>
        <source>Using default settings</source>
        <translation>既定の設定を使用する</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="561"/>
        <source>Cannot read configuration file: %1</source>
        <translation>設定ファイルを読み込めません: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="562"/>
        <source>Error: %1</source>
        <translation>エラー: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="572"/>
        <source>Required tool not found: %1</source>
        <translation>必要なツールが見つかりません: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="581"/>
        <source>Required directory not found: %1</source>
        <translation>指定のディレクトリが見つかりません: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="600"/>
        <source>Initialization Error</source>
        <translation>初期化エラー</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="601"/>
        <source>Failed to initialize application settings:

%1</source>
        <translation>アプリケーション設定の初期化に失敗しました:

%1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="768"/>
        <source>Could not find a usable kernel</source>
        <translation>使用可能なカーネルが見つかりません</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="769"/>
        <source>Searched for kernel files in /boot/ but none were found or accessible.</source>
        <translation>/boot/ ディレクトリ内でカーネルファイルを検索しましたが、見つからなかったかアクセス不可でした。</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="791"/>
        <source>No users found in the system</source>
        <translation>システム内にユーザーが見つかりません</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="794"/>
        <source>Failed to determine system information</source>
        <translation>システム情報が取得できません</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="964"/>
        <source>Used space on / (root): </source>
        <translation>/ (root) の空き容量: </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="980"/>
        <source>estimated</source>
        <translation>推定</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="987"/>
        <source>Used space on /home: </source>
        <translation>/home の空き容量: </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1048"/>
        <source>Free space on %1, where snapshot folder is placed: </source>
        <translation>スナップショットを作成するフォルダがある場所の空き容量 %1：</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1052"/>
        <source>The free space should be sufficient to hold the compressed data from / and /home

      If necessary, you can create more available space
      by removing previous snapshots and saved copies:
      %1 snapshots are taking up %2 of disk space.
</source>
        <translation>/ および /home の圧縮データを保管するには、十分な空き容量がないといけません。必要に応じて、以前生成したスナップショットや保存したコピーを削除することで空き容量を増やすことができます:　スナップショット %1 は空き容量の %2 を消費しています。</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1199"/>
        <source>Error reading system configuration file: %1</source>
        <translation>システム設定ファイルの読み込みエラー: %1</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1208"/>
        <source>Error accessing user configuration</source>
        <translation>ユーザ設定へのアクセス中にエラーが発生しました</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1260"/>
        <source>Could not copy exclusion file from %1 to %2</source>
        <translation>除外ファイルを %1 から %2 へコピーできませんでした</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1283"/>
        <source>Unsupported compression &apos;%1&apos; in configuration, using zstd.</source>
        <translation>非サポートの圧縮形式「%1」が指定されているので、代わりに zstd を使用します。</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1293"/>
        <source>Invalid stored cores setting (%1). Using detected CPU count: %2</source>
        <translation>保存したコア設定は (%1) は無効です。検出した CPU 数 %2 を使用します。</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1303"/>
        <source>Invalid stored throttle setting (%1). Using 0.</source>
        <translation>指定したスロットル設定 (%1) が無効です。代わりに 0 を使用します。</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1394"/>
        <location filename="../src/settings.cpp" line="1504"/>
        <source>Output file %1 already exists. Please use another file name, or delete the existent file.</source>
        <translation>出力ファイル名 %1 はすでに存在します。別の名前を使用するか、すでにあるそのファイルを削除してください。</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="73"/>
        <source>Could not load %1</source>
        <translation>%1 を読み込めませんでした</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>License</source>
        <translation>ライセンス</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <location filename="../src/about.cpp" line="107"/>
        <source>Changelog</source>
        <translation>更新履歴</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="98"/>
        <source>Cancel</source>
        <translation>キャンセル</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="119"/>
        <source>Could not load changelog.</source>
        <translation>更新履歴を読み込めませんでした。</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="53"/>
        <location filename="../src/about.cpp" line="122"/>
        <source>&amp;Close</source>
        <translation>閉じる(&amp;C)</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="78"/>
        <source>No diff output available.</source>
        <translation>差分出力は利用不可です。</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="91"/>
        <source>Could not open default exclusion file at %1.</source>
        <translation>%1 にある既定の除外ファイルを開くことができません。</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="97"/>
        <source>Could not create exclusion file directory at %1.</source>
        <translation>%1 に除外ファイルのディレクトリを作成できません。</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="106"/>
        <source>Could not prepare exclusion file at %1.</source>
        <translation>%1 に除外ファイルを作成できません。</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="123"/>
        <source>Could not read default exclusion file at %1.</source>
        <translation>%1 にある既定のの除外ファイルを読み込めません。</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="131"/>
        <source>Could not write exclusion file at %1.</source>
        <translation>%1 に除外ファイルを書き込むことができません。</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="113"/>
        <source>Could not backup existing exclusion file to %1.</source>
        <translation>既存の除外ファイルを %1 へバックアップできません。</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="139"/>
        <source>Could not copy default exclusion file from %1 to %2.</source>
        <translation>既定の除外ファイルを %1 から %2 へコピーできません。</translation>
    </message>
</context>
<context>
    <name>Work</name>
    <message>
        <location filename="../src/work.cpp" line="247"/>
        <source>Cleaning...</source>
        <translation>クリーニング中...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="278"/>
        <location filename="../src/work.cpp" line="1060"/>
        <source>Done</source>
        <translation>完了</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="292"/>
        <source>Interrupted or failed to complete</source>
        <translation>中断されたか、または完了できませんでした</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="303"/>
        <location filename="../src/work.cpp" line="360"/>
        <location filename="../src/work.cpp" line="564"/>
        <location filename="../src/work.cpp" line="572"/>
        <location filename="../src/work.cpp" line="607"/>
        <location filename="../src/work.cpp" line="650"/>
        <location filename="../src/work.cpp" line="678"/>
        <location filename="../src/work.cpp" line="692"/>
        <location filename="../src/work.cpp" line="706"/>
        <location filename="../src/work.cpp" line="714"/>
        <location filename="../src/work.cpp" line="720"/>
        <location filename="../src/work.cpp" line="728"/>
        <location filename="../src/work.cpp" line="777"/>
        <location filename="../src/work.cpp" line="793"/>
        <location filename="../src/work.cpp" line="854"/>
        <location filename="../src/work.cpp" line="869"/>
        <location filename="../src/work.cpp" line="877"/>
        <location filename="../src/work.cpp" line="888"/>
        <location filename="../src/work.cpp" line="896"/>
        <location filename="../src/work.cpp" line="1013"/>
        <location filename="../src/work.cpp" line="1030"/>
        <location filename="../src/work.cpp" line="1043"/>
        <location filename="../src/work.cpp" line="1051"/>
        <location filename="../src/work.cpp" line="1107"/>
        <location filename="../src/work.cpp" line="1398"/>
        <location filename="../src/work.cpp" line="1406"/>
        <location filename="../src/work.cpp" line="1420"/>
        <location filename="../src/work.cpp" line="1459"/>
        <location filename="../src/work.cpp" line="1509"/>
        <location filename="../src/work.cpp" line="1533"/>
        <source>Error</source>
        <translation>エラー</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="304"/>
        <source>Administrator access was not granted; the snapshot cannot continue.</source>
        <translation>管理者権限が付与されなかったので、スナップショットの処理は続行できません。</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="361"/>
        <source>There&apos;s not enough free space on your target disk, you need at least %1</source>
        <translation>作成するディスクに十分な空き領域がありません。最低でも %1 必要です</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="364"/>
        <source>You have %1 free space on %2</source>
        <translation>%2 に %1 の空き領域があります</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="367"/>
        <source>If you are sure you have enough free space rerun the program with -o/--override-size option</source>
        <translation>充分な空き容量があると分かっているのであれば、-o/--override-size オプションを付けてプログラムを再実行してください。</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="545"/>
        <source>Copying the new-iso filesystem...</source>
        <translation>新たな iso ファイルシステムをコピー中...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="564"/>
        <source>ISO template not found: </source>
        <translation>ISO template が見つかりません: </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="572"/>
        <location filename="../src/work.cpp" line="692"/>
        <source>Could not extract the ISO template: </source>
        <translation>ISO template を抽出できません:</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="600"/>
        <source>Arch ISO template is missing boot/ or efi/ directories.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="603"/>
        <source>Detected boot/ or efi/ under the work directory root; the template may have been extracted to the wrong location.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="606"/>
        <source>Template: %1</source>
        <translation>テンプレート: %1</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="642"/>
        <source>Stale archiso initramfs detected, rebuilding...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="644"/>
        <source>Found /boot/archiso.img built for kernel %1, but the selected kernel is %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="648"/>
        <source>Rebuilding /boot/archiso.img failed. Please rebuild it manually or remove the stale file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="660"/>
        <source>No /boot/archiso.img found, attempting to create one...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="665"/>
        <location filename="../src/work.cpp" line="1097"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="666"/>
        <source>Could not create /boot/archiso.img (is the &apos;archiso&apos; package installed?). Falling back to the regular initramfs — the resulting ISO will likely fail to boot (&quot;Failed to start Switch Root&quot;).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="678"/>
        <source>Could not find an initramfs image to use.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="707"/>
        <source>--grub-mbr option specified but boot/grub/i386-pc/eltorito.img is missing from iso-template</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="715"/>
        <source>Could not copy the template initrd: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="721"/>
        <source>Could not copy the kernel: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="729"/>
        <location filename="../src/work.cpp" line="794"/>
        <location filename="../src/work.cpp" line="878"/>
        <location filename="../src/work.cpp" line="897"/>
        <source>Could not create the checksum for %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="737"/>
        <source>Could not create temp directory. </source>
        <translation>temp ディレクトリを作成できませんでした。</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="778"/>
        <source>Could not copy the kernel modules or programs into the initrd.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="844"/>
        <source>Squashing filesystem...</source>
        <translation>ファイルシステムに Squash を適用中...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="855"/>
        <source>Could not create linuxfs file, please check /var/log/%1.log</source>
        <translation>linuxfs ファイルを作成できませんでした。/var/log/%1.log をチェックしてください。</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="870"/>
        <location filename="../src/work.cpp" line="889"/>
        <source>Could not move %1 to the ISO directory.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1004"/>
        <source>Creating CD/DVD image file...</source>
        <translation>CD/DVD イメージファイルを生成中...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1014"/>
        <source>Could not create ISO file, please check whether you have enough space on the destination partition.</source>
        <translation>ISOファイルを作成できませんでした。パーティションに十分な空き容量があるかご確認ください。</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1024"/>
        <source>Making hybrid iso</source>
        <translation>ハイブリット ISO を作成中</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1031"/>
        <source>Could not make the ISO hybrid; it would not boot correctly from USB.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1044"/>
        <location filename="../src/work.cpp" line="1052"/>
        <source>Could not create the %1 checksum for the ISO.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1065"/>
        <source>Success</source>
        <translation>成功</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1066"/>
        <source>MX Snapshot completed successfully!</source>
        <translation>MX スナップショットの作成に成功しました！</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1067"/>
        <source>Snapshot took %1 to finish.</source>
        <translation>スナップショットの作成が完了するまで %1 かかりました。</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1068"/>
        <source>Thanks for using MX Snapshot, run MX Live USB Maker next!</source>
        <translation>MX スナップショットをご利用いただきありがとうございました。続いて MX Live USB メーカ を起動してください！</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1083"/>
        <location filename="../src/work.cpp" line="1104"/>
        <source>Installing </source>
        <translation>インストール中</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1094"/>
        <source>paru not found; cannot install %1 from the AUR.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1098"/>
        <source>Could not install %1; continuing without the installer.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1107"/>
        <source>Could not install </source>
        <translation>インストールできません</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1117"/>
        <source>Calculating checksum...</source>
        <translation>チェックサムの計算中...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1168"/>
        <source>Building new initrd...</source>
        <translation>新しい initrd を構築中...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1271"/>
        <source>Rebuilding initramfs with: mkinitcpio %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1398"/>
        <location filename="../src/work.cpp" line="1420"/>
        <source>Could not create the package list: </source>
        <translation>パッケージ一覧を作成できませんでした:</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1407"/>
        <source>Could not create working directory. </source>
        <translation>作業用ディレクトリを作成できませんでした。</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1460"/>
        <source>Could not prepare a safe bind-root overlay. Snapshot cannot continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1510"/>
        <location filename="../src/work.cpp" line="1534"/>
        <source>Could not prepare the snapshot bind-root environment.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1870"/>
        <source>Calculating total size of excluded files...</source>
        <translation>除外するファイルの合計サイズを計算中です...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1897"/>
        <source>Calculating size of root...</source>
        <translation>root のサイズを計算中です...</translation>
    </message>
</context>
</TS>