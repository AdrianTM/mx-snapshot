<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="cs">
<context>
    <name>Batchprocessing</name>
    <message>
        <location filename="../src/batchprocessing.cpp" line="53"/>
        <source>Error</source>
        <translation>Chyba</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="54"/>
        <source>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</source>
        <translation>Současné jádro nepodporuje vybraný algoritmus komprese, prosím upravte konfigurační soubor a vyberte jiný algoritmus.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="101"/>
        <source>The program will pause the build and open the boot menu in your text editor.</source>
        <translation>Program teď pozastaví sestavování obrazu, v textovém editoru otevře bootovací menu.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="114"/>
        <source>The boot-menu editor failed; the snapshot cannot continue with potentially unedited files.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="131"/>
        <source>Administrator access was not granted; the snapshot cannot continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="258"/>
        <source>Detected newer exclusion file at %1 compared to %2. Prompting for action.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="264"/>
        <source>s</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'show diff'</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="265"/>
        <source>u</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'use updated default'</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="266"/>
        <source>k</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'keep custom (update timestamp)'</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="267"/>
        <source>q</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'quit'</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="269"/>
        <source>show diff</source>
        <comment>CLI excludes prompt option label</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="270"/>
        <source>use updated default</source>
        <comment>CLI excludes prompt option label</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="271"/>
        <source>keep custom (update timestamp)</source>
        <comment>CLI excludes prompt option label</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="272"/>
        <source>quit</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>Konec</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="275"/>
        <source>[%1]%2  [%3]%4  [%5]%6  [%7]%8: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="280"/>
        <source>The exclusion file at %1 is newer than your configured file at %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="296"/>
        <source>Reverted to updated default exclusion file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="313"/>
        <source>No input available to answer the exclusion file prompt; aborting without creating a snapshot.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="316"/>
        <source>Leaving custom exclusion file unchanged.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="327"/>
        <source>Invalid choice. Please select again.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="121"/>
        <source>No elevation tool found (pkexec/gksu/sudo).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="212"/>
        <source>Failed to start command: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="283"/>
        <source>Administrator access was not granted (authentication cancelled or denied).</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <location filename="../src/mainwindow.cpp" line="396"/>
        <location filename="../src/mainwindow.cpp" line="944"/>
        <source>MX Snapshot</source>
        <translation>MX Snapshot</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="33"/>
        <source>Optional customization</source>
        <translation>Další nastavení</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="65"/>
        <source>Release version:</source>
        <translation>Verze:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="79"/>
        <source>Boot options:</source>
        <translation>Možnosti zavaděče:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="86"/>
        <source>Live kernel:</source>
        <translation>Živé jádro:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="93"/>
        <source>Project name:</source>
        <translation>Název projektu:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="100"/>
        <source>Release date:</source>
        <translation>Datum vydání:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="107"/>
        <source>Release codename:</source>
        <translation>Kódové jméno:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="133"/>
        <source>Current date</source>
        <translation>Aktuální datum</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="172"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Snapshot is a utility that creates a bootable image (ISO) of your working system that you can use for storage or distribution. You can continue working with undemanding applications while it is running.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Snapshot je program pro tvorbu bootovacích obrazů (ISO) z Vašeho funkčího systému, které můžete použít jako zálohu nebo pro distribuci. V průběhu tvorby obrazu můžete pracovat s méně náročnými aplikacemi.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="182"/>
        <source>Used space on / (root) and /home partitions:</source>
        <translation>Zabrané místo na discích / (root) a /home:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="192"/>
        <source>Location and ISO name</source>
        <translation>Umístnění a název ISO</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="219"/>
        <source>Snapshot location:</source>
        <translation>Umístnění obrazu:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="226"/>
        <source>Select a different snapshot directory</source>
        <translation>Vyberte jinou složku</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="236"/>
        <location filename="../src/mainwindow.cpp" line="644"/>
        <source>Snapshot name:</source>
        <translation>Název obrazu:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="360"/>
        <source>Type of snapshot:</source>
        <translation>Typ obrazu:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="367"/>
        <source>Preserving accounts (for personal backup)</source>
        <translation>Zachovat uživatelské účty (pro osobní zálohu)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This option will reset &amp;quot;demo&amp;quot; and &amp;quot;root&amp;quot; passwords to the MX Linux defaults and will not copy any personal accounts created.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Tato volba zresetuje &amp;quot;demo&amp;quot; a &amp;quot;root&amp;quot; hesla na výrobní nastavení MX Linux a nepřenese žádné účty uživatelů.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="380"/>
        <source>Resetting accounts (for distribution to others)</source>
        <translation>Resetovat uživatelské účty (pro distribuci jiným)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="451"/>
        <source>You can also exclude certain directories by ticking the common choices below, or by clicking on the button to directly edit /etc/mx-snapshot-exclude.list.</source>
        <translation>Můžete vyřadit některé složky zaškrtnutím voleb zobrazených níže, nebo kliknutím na tlačítko a přímo upravit soubor /etc/mx-snapshot-exclude.list.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="496"/>
        <source>sha512</source>
        <translation>sha512</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="519"/>
        <source>Throttle the I/O input rate by the given percentage.</source>
        <translation>Omezí vstupní rychlost I/O o zadané procento.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="525"/>
        <source>I/O throttle:</source>
        <translation>Omezení I/O:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="532"/>
        <source>Calculate checksums:</source>
        <translation>Vypočítat kontrolní součty:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="539"/>
        <source>ISO compression scheme:</source>
        <translation>Schéma komprese ISO:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="546"/>
        <source>Number of CPU cores to use:</source>
        <translation>Počet jader CPU, která se mají použít:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="553"/>
        <source>md5</source>
        <translation>md5</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="563"/>
        <source>Options:</source>
        <translation>Možnosti:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="610"/>
        <source>Edit Exclusion File</source>
        <translation>Editovat soubor výjimek</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="626"/>
        <location filename="../src/mainwindow.cpp" line="969"/>
        <source>Remove Custom Exclusion File</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="679"/>
        <source>Pictures</source>
        <translation>Obrázky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="686"/>
        <source>Videos</source>
        <translation>Videa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="693"/>
        <source>All of the above</source>
        <translation>Všechno co je výš</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="700"/>
        <source>exclude network configurations</source>
        <translation>nezahrnout konfiguraci sítí</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="703"/>
        <source>Networks</source>
        <translation>Sítě</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="710"/>
        <source>Downloads</source>
        <translation>Stažené soubory</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="717"/>
        <source>Desktop</source>
        <translation>Pracovní plocha</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="724"/>
        <source>Documents</source>
        <translation>Dokumenty</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="731"/>
        <source>Flatpaks</source>
        <translation>Flatpaky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="738"/>
        <source>Music</source>
        <translation>Hudba</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="881"/>
        <source>About this application</source>
        <translation>O této aplikaci</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="884"/>
        <source>About...</source>
        <translation>O programu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="890"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1005"/>
        <source>Next</source>
        <translation>Další</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="906"/>
        <source>Display help </source>
        <translation>Zobrazit nápovědu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="909"/>
        <source>Help</source>
        <translation>Nápověda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="915"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1030"/>
        <source>Quit application</source>
        <translation>Ukončit aplikaci</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1033"/>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1039"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="989"/>
        <source>Back</source>
        <translation>Zpět</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="358"/>
        <source>Select Release Date</source>
        <translation>Vybrat datum vydání</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="402"/>
        <source>fastest, worst compression</source>
        <translation>nejrychlejší, nejnižší komprese</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="402"/>
        <source>fast, worse compression</source>
        <translation>rychlý, nízká komprese</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="403"/>
        <source>slow, better compression</source>
        <translation>pomalý, lepší komprese</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="403"/>
        <source>best compromise</source>
        <translation>Nejlepší kompromis</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="404"/>
        <source>slowest, best compression</source>
        <translation>nejpomalejší, nejvyšší komprese</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="433"/>
        <source>Free space on %1, where snapshot folder is placed: </source>
        <translation>Volné místo na %1, kam bude obraz umístněn:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="436"/>
        <source>The free space should be sufficient to hold the compressed data from / and /home

      If necessary, you can create more available space by removing previous snapshots and saved copies: %1 snapshots are taking up %2 of disk space.</source>
        <translation>Volné místo by mělo být dostatečné pro uložení komprimovaných dat z / a /home.

V případě potřeby můžete vytvořit více volného místa odstraněním předchozích snímků a uložených kopií: %1  snímků zabírá %2 místa na disku.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="448"/>
        <location filename="../src/mainwindow.cpp" line="449"/>
        <source>Installing </source>
        <translation>Instalace</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="587"/>
        <source>Please wait.</source>
        <translation>Prosím vyčkejte.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="589"/>
        <source>Please wait. Calculating used disk space...</source>
        <translation>Prosím vyčkejte. Propočítávání použitého místa na disku...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="275"/>
        <location filename="../src/mainwindow.cpp" line="489"/>
        <location filename="../src/mainwindow.cpp" line="623"/>
        <location filename="../src/mainwindow.cpp" line="630"/>
        <location filename="../src/mainwindow.cpp" line="712"/>
        <location filename="../src/mainwindow.cpp" line="723"/>
        <location filename="../src/mainwindow.cpp" line="748"/>
        <location filename="../src/mainwindow.cpp" line="1034"/>
        <source>Error</source>
        <translation>Chyba</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="175"/>
        <location filename="../src/mainwindow.cpp" line="211"/>
        <source>Updated Exclusion List</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="178"/>
        <source>The exclusion file at %1 is newer than your configured file at %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="180"/>
        <source>Review the changes below. Keep your custom file or replace it with the updated default.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="186"/>
        <source>Show Differences</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="192"/>
        <source>Keep Custom</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="198"/>
        <source>Use Updated Default</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="490"/>
        <source>Administrator access was not granted; the snapshot cannot continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="522"/>
        <source>Done</source>
        <translation>Hotovo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="624"/>
        <source>Output file %1 already exists. Please use another file name, or delete the existent file.</source>
        <translation>Výstupní soubor %1 již existuje. Prosím vyberte jiný název, nebo smažte stávající soubor.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="631"/>
        <source>Insufficient free space. Please select a different snapshot directory or free up space.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="635"/>
        <source>Settings</source>
        <translation>Nastavení</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="641"/>
        <source>Snapshot will use the following settings:</source>
        <translation>Snapshot použije následující nastavení:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="643"/>
        <source>- Snapshot directory:</source>
        <translation>- Složka Obrazu:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="644"/>
        <source>- Kernel to be used:</source>
        <translation>- Verze jádra:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="668"/>
        <location filename="../src/mainwindow.cpp" line="677"/>
        <source>NVIDIA Detected</source>
        <translation>Detekována NVIDIA</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="669"/>
        <source>This computer uses an NVIDIA graphics card. Are you planning to use the resulting ISO on the same computer or another computer with an NVIDIA card?</source>
        <translation>Tento počítač používá grafickou kartu NVIDIA. Plánujete použít výsledné ISO na stejném počítači nebo na jiném počítači s kartou NVIDIA?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="673"/>
        <source>NVIDIA Selected</source>
        <translation>Vybrána NVIDIA</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="674"/>
        <source>Note: If you use the resulting ISO on a computer without an NVIDIA card, you will likely need to remove &apos;xorg=nvidia&apos; from the boot options.</source>
        <translation>Poznámka: Pokud výsledné ISO použijete v počítači bez karty NVIDIA, bude pravděpodobně nutné z možností spouštění odstranit &apos;xorg=nvidia&apos;.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="678"/>
        <source>Note: If you use the resulting ISO on a computer with an NVIDIA card, you may need to add &apos;xorg=nvidia&apos; to the boot options.</source>
        <translation>Poznámka: Pokud výsledný soubor ISO použijete v počítači s kartou NVIDIA, bude možná nutné do spouštěcích voleb přidat &apos;xorg=nvidia&apos;.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="276"/>
        <location filename="../src/mainwindow.cpp" line="713"/>
        <source>Could not replace the exclusion file with the updated default.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="724"/>
        <source>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</source>
        <translation>Současné jádro nepodporuje vybraný algoritmus komprese, prosím upravte konfigurační soubor a vyberte jiný algoritmus.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="744"/>
        <source>Cancelled</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="745"/>
        <source>Administrator access is required to create a snapshot.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="746"/>
        <source>The operation was cancelled. Select Next when you are ready to try again.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="749"/>
        <source>Could not create the snapshot or work directory.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="762"/>
        <source>Final chance</source>
        <translation>Poslední šance</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="764"/>
        <source>Snapshot now has all the information it needs to create an ISO from your running system.</source>
        <translation>Obraz sesbíral všechny potřebné informace k vytvoření ISO z běžícího systému.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="765"/>
        <source>It will take some time to finish, depending on the size of the installed system and the capacity of your computer.</source>
        <translation>Nějakou chvilku to zabere, závisí to od velikosti instalovaného systému a výkonu Vašeho počítače.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="767"/>
        <source>OK to start?</source>
        <translation>Začít?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="824"/>
        <location filename="../src/mainwindow.cpp" line="771"/>
        <source>Shutdown computer when done.</source>
        <translation>Po dokončení vypnout počítač.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="805"/>
        <source>Output</source>
        <translation>Výstup</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="849"/>
        <source>Close</source>
        <translation>Zavřít</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="924"/>
        <source>Edit Boot Menu</source>
        <translation>Upravit nabídku zavaděče</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="925"/>
        <source>The program will now pause to allow you to edit any files in the work directory. Select Yes to edit the boot menu or select No to bypass this step and continue creating the snapshot.</source>
        <translation>Program se teď pozastaví a umožní Vám upravit soubory v pracovní složce. Zvolte ANO pro editaci nabídky zavaděče, volbou NE přeskočíte tento krok a přejděte k tvorbě obrazu. </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="970"/>
        <source>Revert the exclusion list to the default file? This will overwrite your current exclusions.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1002"/>
        <source>About %1</source>
        <translation>O programu %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1004"/>
        <source>Version: </source>
        <translation>Verze:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1005"/>
        <source>Program for creating a live-CD from the running system for MX Linux</source>
        <translation>Program pro tvorbu LIVE CD z běžícího systému MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1007"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Vlastnická práva (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1009"/>
        <source>%1 License</source>
        <translation>Licence %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1022"/>
        <source>%1 Help</source>
        <translation>Nápověda %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1027"/>
        <source>Select Snapshot Directory</source>
        <translation>Vyberte složku pro umístnění obrazu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1035"/>
        <source>Insufficient free space in the selected directory. Please choose a different location.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1079"/>
        <source>Confirmation</source>
        <translation>Potvrzení</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1079"/>
        <source>Are you sure you want to quit the application?</source>
        <translation>Jste si jistí, že chcete ukončit aplikaci? </translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/main.cpp" line="109"/>
        <source>Tool used for creating a live-CD from the running system</source>
        <translation>Program pro tvorbu LIVE CD z běžícího systému</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>Use CLI only</source>
        <translation>Použít pouze CLI</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="117"/>
        <source>Number of CPU cores to be used.</source>
        <translation>Počet jader CPU, která mají být použita.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="118"/>
        <source>Output directory</source>
        <translation>Cílová složka</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="119"/>
        <source>Output filename</source>
        <translation>Název cílového souboru</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="121"/>
        <source>Name a different kernel to use other than the default running kernel, use format returned by &apos;uname -r&apos;</source>
        <translation>Uveďte verzi jádra, které se má použít navíc s právě používaným. Použijte formát, který se objeví po zadání příkazu  &apos;uname -r&apos;</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="123"/>
        <source>Or the full path: %1</source>
        <translation>Nebo celé umístnění: %1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="126"/>
        <source>Compression level options.</source>
        <translation>Volby úrovně komprese.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="127"/>
        <source>Use quotes: &quot;-Xcompression-level &lt;level&gt;&quot;, or &quot;-Xalgorithm &lt;algorithm&gt;&quot;, or &quot;-Xhc&quot;, see mksquashfs man page</source>
        <translation>Použijte: &quot;-Xcompression-level &lt;level&gt;&quot;, or &quot;-Xalgorithm &lt;algorithm&gt;&quot;, or &quot;-Xhc&quot;, viz mksquashfs manuál</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="131"/>
        <source>Create a monthly snapshot, add &apos;Month&apos; name in the ISO name, skip used space calculation</source>
        <translation>Pro vytvoření měsíční zálohy přidejte do názvu ISO souboru název aktuálního měsíce a zrušte kontrolu volného místa</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="132"/>
        <source>This option sets reset-accounts and compression to defaults, arguments changing those items will be ignored</source>
        <translation>Tahle volba nastavení zresetuje uživatelské účty a kompresi na předvolené hodnoty, argumenty určují které položky budou ingnorovány.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="134"/>
        <source>Optionally specify a suffix to add to the month name (e.g., &apos;1&apos; for &apos;July.1&apos;)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="135"/>
        <source>Don&apos;t calculate checksums for resulting ISO file</source>
        <translation>Pro výsledný ISO soubor nepočítat kontrolní součty</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="136"/>
        <source>Skip calculating free space to see if the resulting ISO will fit</source>
        <translation>Vynechat propocet volného místa</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="137"/>
        <source>Option to fix issue with calculating checksums on preempt_rt kernels</source>
        <translation>Možnost opravit problém s propočtem kontrolních součtů na preempt_rt jádrech</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="138"/>
        <source>Resetting accounts (for distribution to others)</source>
        <translation>Resetovat uživatelské účty (pro distribuci jiným)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="139"/>
        <source>Calculate checksums for resulting ISO file</source>
        <translation>Pro výsledný ISO soubor propočítat kontrolní součty</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="141"/>
        <source>Throttle the I/O input rate by the given percentage. This can be used to reduce the I/O and CPU consumption of Mksquashfs.</source>
        <translation>Omezí vstupní rychlost I/O o zadané procento. Toto lze použít ke snížení I/O a spotřeby procesoru Mksquashfs.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="144"/>
        <source>Work directory</source>
        <translation>Pracovní adresář</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="146"/>
        <source>Exclude main folders, valid choices: </source>
        <translation>Nezahrnout hlavní složky, platné volby:</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="148"/>
        <source>Use the option one time for each item you want to exclude</source>
        <translation>Použijte tuto volbu pro každou položku, kterou chcete vynechat.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="151"/>
        <source>Compression format, valid choices: </source>
        <translation>Formát komprese, platné volby:</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="153"/>
        <source>Shutdown computer when done.</source>
        <translation>Po dokončení vypnout počítač.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="154"/>
        <source>Use grub for legacy mbr iso boot instead of isolinux/syslinux.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="155"/>
        <source>Add the &apos;xorg=nvidia&apos; boot option to the ISO (for booting on a system with an NVIDIA card).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="163"/>
        <source>Optional suffix for a monthly snapshot; only valid together with --month.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="196"/>
        <source>A single suffix positional argument is only valid together with --month.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="255"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Spuštěno pod účtem root-a, odhlašte se a přihlašte jako bězný uživatel.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="270"/>
        <source>version:</source>
        <translation>verze:</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="266"/>
        <source>You must run this program with sudo or pkexec.</source>
        <translation>Tento program musíte spustit s příkazem sudo nebo pkexec.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="235"/>
        <source>MX Snapshot</source>
        <translation>MX Snapshot</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="770"/>
        <location filename="../src/settings.cpp" line="779"/>
        <location filename="../src/settings.cpp" line="1396"/>
        <location filename="../src/settings.cpp" line="1506"/>
        <location filename="../src/main.cpp" line="257"/>
        <location filename="../src/main.cpp" line="343"/>
        <source>Error</source>
        <translation>Chyba</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="300"/>
        <source>Fatal error:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="302"/>
        <source>Fatal error: unknown exception</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="778"/>
        <location filename="../src/main.cpp" line="342"/>
        <source>Current kernel doesn&apos;t support Squashfs, cannot continue.</source>
        <translation>Současné jádro nepodporuje Squashfs, nelze pokračovat.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="261"/>
        <source>Exception during initialization: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="216"/>
        <source>Pending Arch bind-root cleanup state but installed-to-live-arch is missing: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="264"/>
        <source>Unknown exception during initialization</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="299"/>
        <source>Could not create work directory. </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="382"/>
        <source>No suitable filesystem found for the temp directory. Tried /tmp, /home, and the snapshot directory.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="393"/>
        <source>Could not create temp directory:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="394"/>
        <source>Please check that the parent directory exists and is writable:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="412"/>
        <source>Compression format &apos;%1&apos; is not supported by the current kernel</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="418"/>
        <source>Invalid cores setting: %1. Must be between 1 and %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="427"/>
        <source>Invalid throttle setting: %1. Must be between 0 and 99</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="433"/>
        <source>Snapshot directory cannot be empty</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="441"/>
        <source>Snapshot name cannot be empty</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="447"/>
        <source>Snapshot name contains invalid characters: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="453"/>
        <source>Kernel version cannot be empty</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="458"/>
        <source>Kernel file not found: /boot/vmlinuz-%1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="465"/>
        <source>Kernel %1 doesn&apos;t support Squashfs</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="496"/>
        <source>Exclusion file does not exist: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="505"/>
        <source>Unbalanced quotes in exclusion list</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="530"/>
        <source>Insufficient free space: %1 KiB available, minimum %2 KiB required</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="537"/>
        <source>Insufficient free space in work directory: %1 KiB available, minimum %2 KiB required</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="552"/>
        <source>Failed to determine number of CPU cores</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="558"/>
        <source>Configuration file does not exist: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="559"/>
        <source>Using default settings</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="561"/>
        <source>Cannot read configuration file: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="562"/>
        <source>Error: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="572"/>
        <source>Required tool not found: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="581"/>
        <source>Required directory not found: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="600"/>
        <source>Initialization Error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="601"/>
        <source>Failed to initialize application settings:

%1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="768"/>
        <source>Could not find a usable kernel</source>
        <translation>Nepovedlo se najít použitelné jádro</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="769"/>
        <source>Searched for kernel files in /boot/ but none were found or accessible.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="791"/>
        <source>No users found in the system</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="794"/>
        <source>Failed to determine system information</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="964"/>
        <source>Used space on / (root): </source>
        <translation>Zabrané místo na disku / (root):</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="980"/>
        <source>estimated</source>
        <translation>odhad</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="987"/>
        <source>Used space on /home: </source>
        <translation>Zabrané místo na disku /home: </translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1048"/>
        <source>Free space on %1, where snapshot folder is placed: </source>
        <translation>Volné místo na %1, kde je snapshot umístněn:</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1052"/>
        <source>The free space should be sufficient to hold the compressed data from / and /home

      If necessary, you can create more available space
      by removing previous snapshots and saved copies:
      %1 snapshots are taking up %2 of disk space.
</source>
        <translation>Velikost volného místa na disku by měla postačovat pro umístnění zkomprimovaného obsahu z / a /home

      Ak je to nevyhnutné můžete vytvořit víc místa smazáním
      předchozích snapshotů a uložeých kopií systému:
      %1 snapshoty zabírají %2 místa na disku.
</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1199"/>
        <source>Error reading system configuration file: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1208"/>
        <source>Error accessing user configuration</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1260"/>
        <source>Could not copy exclusion file from %1 to %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1283"/>
        <source>Unsupported compression &apos;%1&apos; in configuration, using zstd.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1293"/>
        <source>Invalid stored cores setting (%1). Using detected CPU count: %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1303"/>
        <source>Invalid stored throttle setting (%1). Using 0.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1394"/>
        <location filename="../src/settings.cpp" line="1504"/>
        <source>Output file %1 already exists. Please use another file name, or delete the existent file.</source>
        <translation>Výstupní soubor %1 již existuje. Prosím vyberte jiný název, nebo vymažte stávající soubor.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="73"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>License</source>
        <translation>Licence</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <location filename="../src/about.cpp" line="107"/>
        <source>Changelog</source>
        <translation>Protokol změn</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="98"/>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="119"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="53"/>
        <location filename="../src/about.cpp" line="122"/>
        <source>&amp;Close</source>
        <translation>&amp;Zavřít</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="78"/>
        <source>No diff output available.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="91"/>
        <source>Could not open default exclusion file at %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="97"/>
        <source>Could not create exclusion file directory at %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="106"/>
        <source>Could not prepare exclusion file at %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="123"/>
        <source>Could not read default exclusion file at %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="131"/>
        <source>Could not write exclusion file at %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="113"/>
        <source>Could not backup existing exclusion file to %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="139"/>
        <source>Could not copy default exclusion file from %1 to %2.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Work</name>
    <message>
        <location filename="../src/work.cpp" line="312"/>
        <source>Cleaning...</source>
        <translation>Čištění...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="343"/>
        <location filename="../src/work.cpp" line="1125"/>
        <source>Done</source>
        <translation>Hotovo</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="357"/>
        <source>Interrupted or failed to complete</source>
        <translation>Přerušeno anebo dokončení zlyhalo</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="368"/>
        <location filename="../src/work.cpp" line="425"/>
        <location filename="../src/work.cpp" line="629"/>
        <location filename="../src/work.cpp" line="637"/>
        <location filename="../src/work.cpp" line="672"/>
        <location filename="../src/work.cpp" line="715"/>
        <location filename="../src/work.cpp" line="743"/>
        <location filename="../src/work.cpp" line="757"/>
        <location filename="../src/work.cpp" line="771"/>
        <location filename="../src/work.cpp" line="779"/>
        <location filename="../src/work.cpp" line="785"/>
        <location filename="../src/work.cpp" line="793"/>
        <location filename="../src/work.cpp" line="842"/>
        <location filename="../src/work.cpp" line="858"/>
        <location filename="../src/work.cpp" line="919"/>
        <location filename="../src/work.cpp" line="934"/>
        <location filename="../src/work.cpp" line="942"/>
        <location filename="../src/work.cpp" line="953"/>
        <location filename="../src/work.cpp" line="961"/>
        <location filename="../src/work.cpp" line="1078"/>
        <location filename="../src/work.cpp" line="1095"/>
        <location filename="../src/work.cpp" line="1108"/>
        <location filename="../src/work.cpp" line="1116"/>
        <location filename="../src/work.cpp" line="1172"/>
        <location filename="../src/work.cpp" line="1463"/>
        <location filename="../src/work.cpp" line="1471"/>
        <location filename="../src/work.cpp" line="1485"/>
        <location filename="../src/work.cpp" line="1524"/>
        <location filename="../src/work.cpp" line="1574"/>
        <location filename="../src/work.cpp" line="1598"/>
        <source>Error</source>
        <translation>Chyba</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="369"/>
        <source>Administrator access was not granted; the snapshot cannot continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="426"/>
        <source>There&apos;s not enough free space on your target disk, you need at least %1</source>
        <translation>Na vybraném disku není dostatek volného místa, je potřeba nejméně %1</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="429"/>
        <source>You have %1 free space on %2</source>
        <translation>Máte %1 volného místa na %2</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="432"/>
        <source>If you are sure you have enough free space rerun the program with -o/--override-size option</source>
        <translation>Pokud jste si jistí, že máte dostatek volného místa, tak spusťte program znovu a použijte volbu -o/--override-size</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="610"/>
        <source>Copying the new-iso filesystem...</source>
        <translation>Kopírování nového ISO souborového systému...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="629"/>
        <source>ISO template not found: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="637"/>
        <location filename="../src/work.cpp" line="757"/>
        <source>Could not extract the ISO template: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="665"/>
        <source>Arch ISO template is missing boot/ or efi/ directories.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="668"/>
        <source>Detected boot/ or efi/ under the work directory root; the template may have been extracted to the wrong location.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="671"/>
        <source>Template: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="707"/>
        <source>Stale archiso initramfs detected, rebuilding...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="709"/>
        <source>Found /boot/archiso.img built for kernel %1, but the selected kernel is %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="713"/>
        <source>Rebuilding /boot/archiso.img failed. Please rebuild it manually or remove the stale file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="725"/>
        <source>No /boot/archiso.img found, attempting to create one...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="730"/>
        <location filename="../src/work.cpp" line="1162"/>
        <source>Warning</source>
        <translation>Varování</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="731"/>
        <source>Could not create /boot/archiso.img (is the &apos;archiso&apos; package installed?). Falling back to the regular initramfs — the resulting ISO will likely fail to boot (&quot;Failed to start Switch Root&quot;).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="743"/>
        <source>Could not find an initramfs image to use.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="772"/>
        <source>--grub-mbr option specified but boot/grub/i386-pc/eltorito.img is missing from iso-template</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="780"/>
        <source>Could not copy the template initrd: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="786"/>
        <source>Could not copy the kernel: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="794"/>
        <location filename="../src/work.cpp" line="859"/>
        <location filename="../src/work.cpp" line="943"/>
        <location filename="../src/work.cpp" line="962"/>
        <source>Could not create the checksum for %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="802"/>
        <source>Could not create temp directory. </source>
        <translation>Nebylo možné vytvořít dočasnou složku.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="843"/>
        <source>Could not copy the kernel modules or programs into the initrd.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="909"/>
        <source>Squashing filesystem...</source>
        <translation>Rušení souborového systému...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="920"/>
        <source>Could not create linuxfs file, please check /var/log/%1.log</source>
        <translation>Nelze vytvořit soubor linuxfs, zkontrolujte prosím /var/log/%1.log</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="935"/>
        <location filename="../src/work.cpp" line="954"/>
        <source>Could not move %1 to the ISO directory.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1069"/>
        <source>Creating CD/DVD image file...</source>
        <translation>Vytváření obrazu CD/DVD... </translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1079"/>
        <source>Could not create ISO file, please check whether you have enough space on the destination partition.</source>
        <translation>Nelze vytvořit ISO soubor, prosím zkontrolujte zdali je dostatek místa na vybraném oddílu.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1089"/>
        <source>Making hybrid iso</source>
        <translation>Vytváření hybridního ISO</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1096"/>
        <source>Could not make the ISO hybrid; it would not boot correctly from USB.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1109"/>
        <location filename="../src/work.cpp" line="1117"/>
        <source>Could not create the %1 checksum for the ISO.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1130"/>
        <source>Success</source>
        <translation>Úspěch!</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1131"/>
        <source>MX Snapshot completed successfully!</source>
        <translation>MX Snapshot úspěšně dokončen!</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1132"/>
        <source>Snapshot took %1 to finish.</source>
        <translation>Obraz dokončen za %1.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1133"/>
        <source>Thanks for using MX Snapshot, run MX Live USB Maker next!</source>
        <translation>Díky za použití MX Snapshot, zkuste taky MX Tvůrce Live-USB!</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1148"/>
        <location filename="../src/work.cpp" line="1169"/>
        <source>Installing </source>
        <translation>Instalace</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1159"/>
        <source>paru not found; cannot install %1 from the AUR.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1163"/>
        <source>Could not install %1; continuing without the installer.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1172"/>
        <source>Could not install </source>
        <translation>Nelze nainstalovat</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1182"/>
        <source>Calculating checksum...</source>
        <translation>Počítání kontrolních součtů...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1233"/>
        <source>Building new initrd...</source>
        <translation>Vytváření nového initrd...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1336"/>
        <source>Rebuilding initramfs with: mkinitcpio %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1463"/>
        <location filename="../src/work.cpp" line="1485"/>
        <source>Could not create the package list: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1472"/>
        <source>Could not create working directory. </source>
        <translation>Nebylo možné vytvořít pracovní složku.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1525"/>
        <source>Could not prepare a safe bind-root overlay. Snapshot cannot continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1575"/>
        <location filename="../src/work.cpp" line="1599"/>
        <source>Could not prepare the snapshot bind-root environment.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1938"/>
        <source>Calculating total size of excluded files...</source>
        <translation>Výpočet celkové velikosti vyloučených souborů...</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1965"/>
        <source>Calculating size of root...</source>
        <translation>Výpoćet velikosti root...</translation>
    </message>
</context>
</TS>