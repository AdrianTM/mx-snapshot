inline const QString VERSION {"26.07.6"};
